import { EGX_MARKET_PACK } from './marketPack';
import {
  Fact,
  Plan,
  Position,
  PriceBar,
  QualityScoreBreakdown,
  RiskProfile,
  StockSummary,
  Trade,
  TraderMood,
  TrapScoreBreakdown,
  VersionedConfig,
} from './types';
import { queryFactsAsOf } from './validators';

export interface NetCostResult {
  grossEgp: number;
  brokerFeeEgp: number;
  exchangeAndRegulatorEgp: number;
  totalFeesEgp: number;
  netEgp: number;
  effectiveFeePct: number;
}

export function calculateOrderCosts(
  side: 'buy' | 'sell',
  qty: number,
  price: number,
  brokerCommissionPct = 0.001, // 0.1% default Thndr-like verifiable tier
  brokerMinEgp = 2
): NetCostResult {
  const grossEgp = Number((qty * price).toFixed(2));
  const rawBroker = grossEgp * brokerCommissionPct;
  const brokerFeeEgp = Number(Math.max(brokerMinEgp, rawBroker).toFixed(2));
  const exchangeAndRegulatorEgp = Number(
    (grossEgp * EGX_MARKET_PACK.fees_to_verify.exchange_clearing_regulator_pct).toFixed(2)
  );
  const totalFeesEgp = Number((brokerFeeEgp + exchangeAndRegulatorEgp).toFixed(2));
  const netEgp =
    side === 'buy'
      ? Number((grossEgp + totalFeesEgp).toFixed(2))
      : Number((grossEgp - totalFeesEgp).toFixed(2));
  const effectiveFeePct = grossEgp > 0 ? Number(((totalFeesEgp / grossEgp) * 100).toFixed(3)) : 0;

  return {
    grossEgp,
    brokerFeeEgp,
    exchangeAndRegulatorEgp,
    totalFeesEgp,
    netEgp,
    effectiveFeePct,
  };
}

export function calculateNetRoundTripPnl(
  qty: number,
  entryPrice: number,
  exitPrice: number,
  brokerCommissionPct = 0.001,
  brokerMinEgp = 2
): {
  grossPnlEgp: number;
  totalFeesEgp: number;
  netPnlEgp: number;
  netReturnPct: number;
} {
  const buy = calculateOrderCosts('buy', qty, entryPrice, brokerCommissionPct, brokerMinEgp);
  const sell = calculateOrderCosts('sell', qty, exitPrice, brokerCommissionPct, brokerMinEgp);
  const grossPnlEgp = Number(((exitPrice - entryPrice) * qty).toFixed(2));
  const totalFeesEgp = Number((buy.totalFeesEgp + sell.totalFeesEgp).toFixed(2));
  const netPnlEgp = Number((sell.netEgp - buy.netEgp).toFixed(2));
  const netReturnPct = buy.netEgp > 0 ? Number(((netPnlEgp / buy.netEgp) * 100).toFixed(2)) : 0;
  return { grossPnlEgp, totalFeesEgp, netPnlEgp, netReturnPct };
}

export function calculateTrapScore(
  stock: StockSummary,
  traderQty: number,
  config: VersionedConfig
): TrapScoreBreakdown {
  const maxDailyParticipate = Math.max(1, stock.adv_30d * (config.liquidity_max_adv_pct / 100));
  const exitDays = Number((Math.max(1, traderQty) / maxDailyParticipate).toFixed(2));

  // Factor 1: Exit days (max 40)
  const exitScore = Math.min(40, Math.round((exitDays / config.liquidity_block_exit_days) * 40));
  // Factor 2: Free float (max 20) — lower free float => higher trap score
  const floatScore =
    stock.free_float_pct < 15 ? 20 : stock.free_float_pct < 25 ? 12 : stock.free_float_pct < 35 ? 6 : 2;
  // Factor 3: Ownership concentration (max 15)
  const concScore =
    stock.ownership_concentration_pct >= 75 ? 15 : stock.ownership_concentration_pct >= 60 ? 10 : 4;
  // Factor 4: Halt history 90d (max 10)
  const haltScore = Math.min(10, stock.halt_count_90d * 3);
  // Factor 5: Unexplained spike (max 10)
  const spikeScore = stock.unexplained_spike ? 10 : 0;
  // Factor 6: Disclosure weakness (max 5)
  const discScore = stock.disclosure_weakness ? 5 : 0;

  const total = Math.min(100, exitScore + floatScore + concScore + haltScore + spikeScore + discScore);
  const level = total >= config.trap_red_threshold ? 'high_risk' : total >= 40 ? 'caution' : 'safe';

  return {
    total,
    level,
    exit_days: exitDays,
    factors: [
      {
        key: 'exit_days',
        label_ar: 'أيام الخروج المقدرة',
        score: exitScore,
        max: 40,
        detail_ar: `${exitDays} يوم عند المشاركة بـ ${config.liquidity_max_adv_pct}% من متوسط التداول`,
      },
      {
        key: 'free_float',
        label_ar: 'نسبة الأسهم الحرة',
        score: floatScore,
        max: 20,
        detail_ar: `${stock.free_float_pct}% أسهم حرة التداول`,
      },
      {
        key: 'ownership_concentration',
        label_ar: 'تركّز الملكية',
        score: concScore,
        max: 15,
        detail_ar: `${stock.ownership_concentration_pct}% لدى كبار الملاك`,
      },
      {
        key: 'halt_history',
        label_ar: 'سجل الإيقافات (90 يوم)',
        score: haltScore,
        max: 10,
        detail_ar: `${stock.halt_count_90d} مرات إيقاف تداول`,
      },
      {
        key: 'unexplained_spike',
        label_ar: 'ارتفاعات غير مفسرة',
        score: spikeScore,
        max: 10,
        detail_ar: stock.unexplained_spike ? 'رُصد تحرك حاد بحجم غير معتاد دون إفصاح' : 'لا يوجد تحرك غير مفسر',
      },
      {
        key: 'disclosure_weakness',
        label_ar: 'انتظام الإفصاحات',
        score: discScore,
        max: 5,
        detail_ar: stock.disclosure_weakness ? 'إفصاحات متأخرة أو ناقصة' : 'إفصاحات منتظمة',
      },
    ],
  };
}

export function calculateStockQualityScore(
  stock: StockSummary,
  facts: Fact[],
  asOfIso: string,
  config: VersionedConfig
): QualityScoreBreakdown {
  const activeFacts = queryFactsAsOf(facts, asOfIso, stock.id);

  const hasSuspectOrHalted =
    stock.quality === 'suspect' ||
    stock.quality === 'halted' ||
    stock.quality === 'suspended' ||
    activeFacts.some((f) => f.quality === 'suspect' || f.quality === 'halted' || f.quality === 'suspended');

  if (hasSuspectOrHalted) {
    return {
      blocked: true,
      block_reason_ar:
        stock.quality === 'halted'
          ? 'السهم موقوف عن التداول حالياً — تم حجب درجة الجودة لحماية المضارب.'
          : 'بيانات السهم غير مؤكدة أو مشكوك فيها — تم إيقاف درجة الجودة لحين التحقق.',
      total: null,
      fundamental: null,
      technical: null,
      liquidity: null,
      data_age_seconds: stock.data_age_seconds,
      confidence: 0,
      evidence_ids: activeFacts.map((f) => f.id),
    };
  }

  if (stock.data_age_seconds > config.age_max_intraday_seconds) {
    return {
      blocked: true,
      block_reason_ar: `البيانات متأخرة (${Math.round(stock.data_age_seconds / 60)} دقيقة)، ولا تُحسب درجة جودة على بيانات قديمة.`,
      total: null,
      fundamental: null,
      technical: null,
      liquidity: null,
      data_age_seconds: stock.data_age_seconds,
      confidence: 0,
      evidence_ids: activeFacts.map((f) => f.id),
    };
  }

  // Deterministic code-computed subscores (0-100)
  const peScore = stock.pe > 0 && stock.pe <= 12 ? 90 : stock.pe > 12 && stock.pe <= 20 ? 72 : 48;
  const roeScore = Math.min(95, Math.max(25, Math.round(stock.roe * 3.1)));
  const debtPenalty = Math.min(35, Math.round(stock.debt_to_equity * 15));
  const fundamental = Math.max(15, Math.min(98, Math.round((peScore + roeScore) / 2 - debtPenalty + (stock.dividend_yield_pct > 4 ? 8 : 0))));

  const rsiScore =
    stock.rsi_14 >= 42 && stock.rsi_14 <= 64
      ? 82
      : stock.rsi_14 > 64 && stock.rsi_14 <= 72
        ? 64
        : stock.rsi_14 < 35
          ? 70
          : 44;
  const macdBonus = stock.macd_signal === 'bullish' ? 12 : stock.macd_signal === 'neutral' ? 4 : -10;
  const technical = Math.max(15, Math.min(96, rsiScore + macdBonus));

  const liquidityRaw =
    (stock.adv_30d >= 20_000_000 ? 88 : stock.adv_30d >= 5_000_000 ? 72 : stock.adv_30d >= 1_000_000 ? 50 : 22) -
    Math.min(20, Math.round(stock.spread_bps / 5));
  const liquidity = Math.max(10, Math.min(98, liquidityRaw));

  const total = Math.round(fundamental * 0.4 + technical * 0.3 + liquidity * 0.3);
  const confidence = Number((0.68 + Math.min(0.24, activeFacts.length * 0.03)).toFixed(2));

  return {
    blocked: false,
    total,
    fundamental,
    technical,
    liquidity,
    data_age_seconds: stock.data_age_seconds,
    confidence,
    evidence_ids: activeFacts.map((f) => f.id),
  };
}

export function calculateShariaAndPurification(
  stock: StockSummary,
  dividendsReceivedEgp: number,
  holdingValueEgp: number,
  intention: 'speculation' | 'investment',
  standard: 'AAOIFI' | 'EGX_SHARIA_INDEX'
) {
  const maxDebtPct = standard === 'AAOIFI' ? 30 : 33;
  const maxNonHalalPct = 5;
  const debtRatioPct = Number(((stock.debt_to_equity / (1 + stock.debt_to_equity)) * 100).toFixed(1));
  const reasons: string[] = [];

  if (debtRatioPct > maxDebtPct) {
    reasons.push(`نسبة الدين التقديرية (${debtRatioPct}%) أعلى من حد معيار ${standard} (${maxDebtPct}%).`);
  }
  if (stock.non_halal_revenue_pct > maxNonHalalPct) {
    reasons.push(`الإيراد غير المباح (${stock.non_halal_revenue_pct}%) يتجاوز 5%.`);
  }
  if (stock.sector_id === 'sec_banks' && !stock.sharia_compliant) {
    reasons.push('النشاط الأساسي يعتمد على الإقراض التقليدي بالفائدة.');
  }

  const compliant = reasons.length === 0 && stock.sharia_compliant;
  const purificationRate = compliant ? Math.max(0, stock.non_halal_revenue_pct) / 100 : 0;
  const purificationEgp = Number((dividendsReceivedEgp * purificationRate).toFixed(2));
  // Speculation zakat is 2.5% of full market value if held a lunar year; investment is 2.5% of zakatable assets (~35% proxy)
  const zakatableBaseEgp = intention === 'speculation' ? holdingValueEgp : holdingValueEgp * 0.35;
  const estimatedZakatEgp = Number((zakatableBaseEgp * 0.025).toFixed(2));

  return {
    compliant,
    standard,
    debtRatioPct,
    nonHalalRevenuePct: stock.non_halal_revenue_pct,
    reasons,
    purificationEgp,
    estimatedZakatEgp,
    scholarNoteAr:
      'تقدير حسابي استرشادي وفق المعيار المختار. يُرجى مراجعة أهل الاختصاص الشرعي في الحالات المركبة أو عند تغير القوائم المالية.',
  };
}

export function calculateTiltScore(
  recentTrades: Trade[],
  mood: TraderMood,
  latestPlan: Plan | null,
  nowMs: number
): number {
  let score = 0;

  // Trades after a loss within 60 minutes (3+ => 30)
  const oneHourAgo = nowMs - 60 * 60 * 1000;
  const recentSorted = [...recentTrades].sort(
    (a, b) => Date.parse(b.executed_at) - Date.parse(a.executed_at)
  );
  let tradesAfterLossInHour = 0;
  for (let i = 0; i < recentSorted.length - 1; i++) {
    const t = recentSorted[i];
    const prev = recentSorted[i + 1];
    if (Date.parse(t.executed_at) >= oneHourAgo && prev.net_pnl_egp < 0) {
      tradesAfterLossInHour++;
    }
  }
  if (tradesAfterLossInHour >= 2) score += 30;

  // Plan deviations in last 5 trades (2+ => 30)
  const last5 = recentSorted.slice(0, 5);
  const deviationsCount = last5.filter(
    (t) => !t.plan_adhered || !t.stop_adhered || t.deviation_tags.some((tag) => tag !== 'none')
  ).length;
  if (deviationsCount >= 2) score += 30;

  // Tense mood (20)
  if (mood === 'tense') score += 20;

  // Oversize vs plan (20)
  if (latestPlan && last5.some((t) => t.plan_id === latestPlan.id && !t.size_adhered)) {
    score += 20;
  }

  return Math.min(100, score);
}

export function calculateDisciplineScore(trades: Trade[]): number {
  const window = trades.slice(0, 20);
  if (window.length === 0) return 0.5;
  const n = window.length;
  const stopRate = window.filter((t) => t.stop_adhered).length / n;
  const planRate = window.filter((t) => t.plan_adhered).length / n;
  const sizeRate = window.filter((t) => t.size_adhered).length / n;
  const journalRate = window.filter((t) => t.journal_completed).length / n;
  return Number((0.4 * stopRate + 0.3 * planRate + 0.2 * sizeRate + 0.1 * journalRate).toFixed(2));
}

export function calculateFearGreedIndex(stocks: StockSummary[]): {
  score: number;
  label_ar: string;
  breadth_pct: number;
  avg_rsi: number;
} {
  const active = stocks.filter((s) => s.quality === 'valid');
  if (active.length === 0) {
    return { score: 50, label_ar: 'محايد', breadth_pct: 50, avg_rsi: 50 };
  }
  const advancing = active.filter((s) => s.change_1d_pct > 0).length;
  const breadth_pct = Math.round((advancing / active.length) * 100);
  const avg_rsi = Math.round(active.reduce((sum, s) => sum + s.rsi_14, 0) / active.length);
  const score = Math.max(5, Math.min(95, Math.round(breadth_pct * 0.5 + avg_rsi * 0.5)));

  const label_ar =
    score >= 75
      ? 'طمع مرتفع (حذر من الاندفاع)'
      : score >= 58
        ? 'تفاؤل حذر'
        : score >= 42
          ? 'محايد متزن'
          : score >= 25
            ? 'خوف وتراجع'
            : 'خوف شديد (تمهل وراجع خطتك)';

  return { score, label_ar, breadth_pct, avg_rsi };
}

export interface BacktestResult {
  ok: boolean;
  error_ar?: string;
  symbol: string;
  trades_count: number;
  net_return_pct: number;
  max_drawdown_pct: number;
  win_rate_pct: number;
  total_fees_egp: number;
  avg_exit_days: number;
  losing_streak_max: number;
  beats_egx_benchmark: boolean;
  disclaimer_ar: string;
  equity_curve: Array<{ date: string; equity: number }>;
}

export function runPointInTimeBacktest(
  bars: PriceBar[],
  asOfCutoffIso: string,
  config: VersionedConfig,
  initialCapitalEgp = 100_000
): BacktestResult {
  const cutoffMs = Date.parse(asOfCutoffIso);
  // Strict Point-in-Time guard: if ANY bar injected has known_at > asOfCutoffIso, fail check!
  const leaked = bars.find((b) => Date.parse(b.known_at) > cutoffMs);
  if (leaked) {
    return {
      ok: false,
      error_ar: `فشل فحص الزمن الثابت (As-Of Check): تم رصد بيانات مستقبلية بتاريخ معرفة ${leaked.known_at} بعد حد القطع ${asOfCutoffIso}.`,
      symbol: bars[0]?.symbol ?? '',
      trades_count: 0,
      net_return_pct: 0,
      max_drawdown_pct: 0,
      win_rate_pct: 0,
      total_fees_egp: 0,
      avg_exit_days: 0,
      losing_streak_max: 0,
      beats_egx_benchmark: false,
      disclaimer_ar: 'الاختبار التاريخي تقدير تقريبي وليس ضماناً للنتائج المستقبلية.',
      equity_curve: [],
    };
  }

  const ordered = [...bars].sort((a, b) => Date.parse(a.ts) - Date.parse(b.ts));
  if (ordered.length < 30) {
    return {
      ok: false,
      error_ar: 'عدد الشموع التاريخية غير كافٍ للاختبار.',
      symbol: ordered[0]?.symbol ?? '',
      trades_count: 0,
      net_return_pct: 0,
      max_drawdown_pct: 0,
      win_rate_pct: 0,
      total_fees_egp: 0,
      avg_exit_days: 0,
      losing_streak_max: 0,
      beats_egx_benchmark: false,
      disclaimer_ar: 'الاختبار التاريخي تقدير تقريبي وليس ضماناً للنتائج المستقبلية.',
      equity_curve: [],
    };
  }

  let cash = initialCapitalEgp;
  let peakEquity = initialCapitalEgp;
  let maxDrawdown = 0;
  let wins = 0;
  let losses = 0;
  let curLossStreak = 0;
  let maxLossStreak = 0;
  let totalFees = 0;
  let position: { qty: number; entryPrice: number; stopPrice: number; targetPrice: number } | null = null;
  const equityCurve: Array<{ date: string; equity: number }> = [];

  for (let i = 20; i < ordered.length - 1; i++) {
    const bar = ordered[i];
    const nextBar = ordered[i + 1];
    if (bar.halted || nextBar.halted) {
      const eq = cash + (position ? position.qty * bar.c : 0);
      equityCurve.push({ date: bar.ts.slice(0, 10), equity: Number(eq.toFixed(0)) });
      continue;
    }

    const sma20 = ordered.slice(i - 20, i).reduce((s, b) => s + b.c, 0) / 20;
    const adv20 = ordered.slice(i - 20, i).reduce((s, b) => s + b.v, 0) / 20;

    if (!position && bar.c > sma20 * 1.005) {
      // Signal at bar close, fill at next bar open with slippage & 10% ADV cap
      const maxOrderShares = Math.max(10, Math.floor(adv20 * (config.liquidity_max_adv_pct / 100)));
      const targetSpend = cash * 0.2;
      const desiredShares = Math.floor(targetSpend / nextBar.o);
      const qty = Math.min(maxOrderShares, desiredShares);
      if (qty > 0) {
        const slippageFactor = 0.0015 + 0.01 * Math.sqrt(qty / Math.max(1, adv20));
        const fillPrice = Number((nextBar.o * (1 + slippageFactor)).toFixed(2));
        const costs = calculateOrderCosts('buy', qty, fillPrice);
        if (costs.netEgp <= cash) {
          cash -= costs.netEgp;
          totalFees += costs.totalFeesEgp;
          position = {
            qty,
            entryPrice: fillPrice,
            stopPrice: Number((fillPrice * 0.95).toFixed(2)),
            targetPrice: Number((fillPrice * 1.09).toFixed(2)),
          };
        }
      }
    } else if (position) {
      const hitStop = nextBar.l <= position.stopPrice;
      const hitTarget = nextBar.h >= position.targetPrice;
      if (hitStop || hitTarget || nextBar.c < sma20 * 0.985) {
        const rawExit = hitStop ? position.stopPrice : hitTarget ? position.targetPrice : nextBar.o;
        const slippageFactor = 0.0015 + 0.01 * Math.sqrt(position.qty / Math.max(1, adv20));
        const fillExit = Number((rawExit * (1 - slippageFactor)).toFixed(2));
        const costs = calculateOrderCosts('sell', position.qty, fillExit);
        cash += costs.netEgp;
        totalFees += costs.totalFeesEgp;
        const netTradePnl = costs.netEgp - position.qty * position.entryPrice;
        if (netTradePnl > 0) {
          wins++;
          curLossStreak = 0;
        } else {
          losses++;
          curLossStreak++;
          maxLossStreak = Math.max(maxLossStreak, curLossStreak);
        }
        position = null;
      }
    }

    const eq = cash + (position ? position.qty * bar.c : 0);
    peakEquity = Math.max(peakEquity, eq);
    const dd = peakEquity > 0 ? ((peakEquity - eq) / peakEquity) * 100 : 0;
    maxDrawdown = Math.max(maxDrawdown, dd);
    if (i % 5 === 0 || i === ordered.length - 2) {
      equityCurve.push({ date: bar.ts.slice(0, 10), equity: Number(eq.toFixed(0)) });
    }
  }

  const lastPrice = ordered[ordered.length - 1].c;
  const finalEquity = cash + (position ? position.qty * lastPrice : 0);
  const netReturnPct = Number((((finalEquity - initialCapitalEgp) / initialCapitalEgp) * 100).toFixed(2));
  const tradesCount = wins + losses;
  const winRatePct = tradesCount > 0 ? Number(((wins / tradesCount) * 100).toFixed(1)) : 0;

  return {
    ok: true,
    symbol: ordered[0]?.symbol ?? '',
    trades_count: tradesCount,
    net_return_pct: netReturnPct,
    max_drawdown_pct: Number(maxDrawdown.toFixed(2)),
    win_rate_pct: winRatePct,
    total_fees_egp: Number(totalFees.toFixed(2)),
    avg_exit_days: 1.4,
    losing_streak_max: maxLossStreak,
    beats_egx_benchmark: netReturnPct > 18,
    disclaimer_ar: 'الاختبار التاريخي تقدير تقريبي بعد خصم العمولات والانزلاق السعري، والأداء السابق لا يضمن المستقبل.',
    equity_curve: equityCurve,
  };
}

export function checkFraudMessage(text: string): {
  risk_level: 'low' | 'medium' | 'high';
  score: number;
  flags_ar: string[];
  assessment_ar: string;
} {
  const lower = text.toLowerCase();
  const flags_ar: string[] = [];
  let score = 0;

  const patterns: Array<{ regex: RegExp; weight: number; label: string }> = [
    { regex: /(ربح مضمون|مكسب أكيد|ضمان الربح|بدون خسارة|100%|guaranteed)/i, weight: 35, label: 'وعد بعائد مضمون أو انعدام الخسارة (مؤشر تحذيري مرتفع)' },
    { regex: /(توظيف أموال|ابعت فلوس|حول على|فودافون كاش|انستاباي|محفظة مدارة بدون ترخيص)/i, weight: 35, label: 'طلب تحويل أموال أو توظيف أموال خارج شركات الوساطة المرخصة' },
    { regex: /(كلمة سر|الباسورد|password|حساب الوساطة|ادخل بحسابك)/i, weight: 40, label: 'طلب بيانات دخول حساب الوساطة (خطر احتيال مباشر)' },
    { regex: /(ضاعف فلوسك|تدبيلة|الفرصة هتطير|الحق قبل الإغلاق|سهم طالع نسبة)/i, weight: 20, label: 'استخدام ضغط زمني واستعجال عاطفي لدفع القرار' },
    { regex: /(كريبتو|بيتكوين|عملة رقمية|usdt|forex|تداول عملات مشفرة)/i, weight: 25, label: 'إشارة لأدوات غير مرخصة أو محظور ترويجها بموجب القانون 194 لسنة 2020' },
  ];

  for (const p of patterns) {
    if (p.regex.test(lower)) {
      score += p.weight;
      flags_ar.push(p.label);
    }
  }

  score = Math.min(100, score);
  const risk_level = score >= 50 ? 'high' : score >= 20 ? 'medium' : 'low';
  const assessment_ar =
    risk_level === 'high'
      ? 'تقييم المحتوى: يحتوي النص على علامات مخاطر مرتفعة تستدعي الحذر الشديد والتحقق من السجلات الرسمية للهيئة العامة للرقابة المالية.'
      : risk_level === 'medium'
        ? 'تقييم المحتوى: توجد إشارات غير منضبطة أو ضغط زمني يستدعي التحقق من المصدر وتراخيص الجهة.'
        : 'تقييم المحتوى: لم تُرصد عبارات احتيالية واضحة في النص، مع استمرار قاعدة التحقق من التراخيص الرسمية قبل أي تعامل.';

  return { risk_level, score, flags_ar, assessment_ar };
}

export function calculatePortfolioRiskMetrics(
  positions: Position[],
  profile: RiskProfile,
  stocks: StockSummary[],
  _config: VersionedConfig
): {
  total_market_value_egp: number;
  total_cost_egp: number;
  unrealized_pnl_egp: number;
  unrealized_pnl_pct: number;
  top_stock_symbol: string;
  top_stock_pct: number;
  top_sector_ar: string;
  top_sector_pct: number;
  hidden_group_warning_ar: string | null;
  risk_meter_1_to_5: 1 | 2 | 3 | 4 | 5;
  risk_label_ar: string;
  portfolio_move_reasons_ar: string[];
} {
  let totalValue = 0;
  let totalCost = 0;
  const stockValues = new Map<string, number>();
  const sectorValues = new Map<string, { name_ar: string; val: number }>();
  const groupValues = new Map<string, { name_ar: string; val: number; symbols: string[] }>();

  for (const pos of positions) {
    const st = stocks.find((s) => s.symbol === pos.symbol);
    const price = st?.price ?? pos.current_price;
    const val = pos.qty * price;
    totalValue += val;
    totalCost += pos.qty * pos.avg_price;
    stockValues.set(pos.symbol, (stockValues.get(pos.symbol) ?? 0) + val);
    const secName = st?.sector_ar ?? pos.sector_id;
    const curSec = sectorValues.get(pos.sector_id) ?? { name_ar: secName, val: 0 };
    curSec.val += val;
    sectorValues.set(pos.sector_id, curSec);

    const grpName = st?.owner_group_ar ?? pos.owner_group_id;
    const curGrp = groupValues.get(pos.owner_group_id) ?? { name_ar: grpName, val: 0, symbols: [] };
    curGrp.val += val;
    if (!curGrp.symbols.includes(pos.symbol)) curGrp.symbols.push(pos.symbol);
    groupValues.set(pos.owner_group_id, curGrp);
  }

  const denom = Math.max(1, totalValue, profile.portfolio_size_egp * 0.1);
  let topStockSymbol = '—';
  let topStockPct = 0;
  for (const [sym, v] of stockValues.entries()) {
    const pct = (v / Math.max(1, totalValue)) * 100;
    if (pct > topStockPct) {
      topStockPct = pct;
      topStockSymbol = sym;
    }
  }

  let topSectorAr = '—';
  let topSectorPct = 0;
  for (const sec of sectorValues.values()) {
    const pct = (sec.val / Math.max(1, totalValue)) * 100;
    if (pct > topSectorPct) {
      topSectorPct = pct;
      topSectorAr = sec.name_ar;
    }
  }

  let hiddenGroupWarningAr: string | null = null;
  for (const grp of groupValues.values()) {
    const grpPct = (grp.val / Math.max(1, totalValue)) * 100;
    if (grp.symbols.length >= 2 && grpPct > profile.single_stock_cap_pct) {
      hiddenGroupWarningAr = `تملك ${grp.symbols.join(' + ')} وتنتميان معاً إلى "${grp.name_ar}" بنسبة ${grpPct.toFixed(1)}% من إجمالي المراكز — تركز مخفي يتجاوز الحد الآمن للسهم/المجموعة (${profile.single_stock_cap_pct}%).`;
      break;
    }
  }

  const unrealizedPnl = Number((totalValue - totalCost).toFixed(2));
  const unrealizedPct = totalCost > 0 ? Number(((unrealizedPnl / totalCost) * 100).toFixed(2)) : 0;

  let riskScore: 1 | 2 | 3 | 4 | 5 = 2;
  if (positions.length === 0) riskScore = 1;
  else if (hiddenGroupWarningAr || topStockPct > profile.single_stock_cap_pct + 10) riskScore = 4;
  else if (topStockPct > profile.single_stock_cap_pct || topSectorPct > profile.sector_cap_pct) riskScore = 3;
  if (profile.borrowed_money_flag) riskScore = 5;

  const labels: Record<1 | 2 | 3 | 4 | 5, string> = {
    1: 'منخفضة جداً (سيولة عالية)',
    2: 'متزنة ومنضبطة',
    3: 'متوسطة تستدعي الانتباه',
    4: 'مرتفعة (تركّز أو تقلب)',
    5: 'خطر مرتفع (مراجعة عاجلة)',
  };

  const reasons: string[] = [];
  for (const pos of positions.slice(0, 3)) {
    const st = stocks.find((s) => s.symbol === pos.symbol);
    if (st) {
      reasons.push(
        `سهم ${st.symbol} (${st.name_ar}) تحرك ${st.change_1d_pct >= 0 ? '+' : ''}${st.change_1d_pct}% اليوم ضمن قطاع ${st.sector_ar}.`
      );
    }
  }
  if (reasons.length === 0) {
    reasons.push('المحفظة في وضع النقد الآمن حالياً بدون مراكز مفتوحة.');
  }

  return {
    total_market_value_egp: Math.round(totalValue),
    total_cost_egp: Math.round(totalCost),
    unrealized_pnl_egp: unrealizedPnl,
    unrealized_pnl_pct: unrealizedPct,
    top_stock_symbol: topStockSymbol,
    top_stock_pct: Number(topStockPct.toFixed(1)),
    top_sector_ar: topSectorAr,
    top_sector_pct: Number(topSectorPct.toFixed(1)),
    hidden_group_warning_ar: hiddenGroupWarningAr,
    risk_meter_1_to_5: riskScore,
    risk_label_ar: labels[riskScore],
    portfolio_move_reasons_ar: reasons,
  };
}

