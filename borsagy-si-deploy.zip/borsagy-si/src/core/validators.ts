import crypto from 'node:crypto';
import { BANNED_PHRASES } from './marketPack';
import { Claim, EvidenceRef, Fact } from './types';

export interface ValidationResult {
  ok: boolean;
  errors: string[];
}

export function validateClaim(
  claim: Partial<Claim>,
  factsById?: Map<string, Fact>
): ValidationResult {
  const errors: string[] = [];

  if (!claim.agent) errors.push('missing_agent');
  if (!claim.subject) errors.push('missing_subject');
  if (!claim.predicate) errors.push('missing_predicate');
  if (claim.value === undefined || claim.value === null) errors.push('missing_value');

  if (!claim.evidence || !Array.isArray(claim.evidence) || claim.evidence.length === 0) {
    errors.push('empty_evidence');
  }

  if (
    !claim.interval ||
    !Array.isArray(claim.interval) ||
    claim.interval.length !== 2 ||
    Number.isNaN(claim.interval[0]) ||
    Number.isNaN(claim.interval[1])
  ) {
    errors.push('missing_or_invalid_interval');
  }

  if (!claim.valid_from || !claim.valid_to || !claim.known_at) {
    errors.push('missing_bitemporal_timestamps');
  }

  if (
    typeof claim.confidence !== 'number' ||
    Number.isNaN(claim.confidence) ||
    claim.confidence < 0 ||
    claim.confidence > 1
  ) {
    errors.push('invalid_confidence');
  }

  if (factsById && claim.evidence) {
    for (const factId of claim.evidence) {
      const fact = factsById.get(factId);
      if (!fact) {
        errors.push(`unknown_fact:${factId}`);
      } else if (fact.quality === 'suspended' || fact.quality === 'halted' || fact.quality === 'suspect') {
        errors.push(`invalid_fact_quality:${factId}:${fact.quality}`);
      }
    }
  }

  return { ok: errors.length === 0, errors };
}

export function queryFactsAsOf(
  facts: Fact[],
  asOfIso: string,
  entityId?: string,
  predicate?: string
): Fact[] {
  const asOfMs = Date.parse(asOfIso);
  if (Number.isNaN(asOfMs)) return [];

  const eligible = facts.filter((f) => {
    if (entityId && f.entity_id !== entityId) return false;
    if (predicate && f.predicate !== predicate) return false;
    const knownMs = Date.parse(f.known_at);
    const validFromMs = Date.parse(f.valid_from);
    const validToMs = f.valid_to ? Date.parse(f.valid_to) : Infinity;
    return knownMs <= asOfMs && validFromMs <= asOfMs && asOfMs <= validToMs;
  });

  const supersededIds = new Set<string>();
  for (const f of eligible) {
    if (f.supersedes) {
      supersededIds.add(f.supersedes);
    }
  }

  return eligible.filter((f) => !supersededIds.has(f.id));
}

function normalizeArabicDigits(input: string): string {
  const arabicDigits = '٠١٢٣٤٥٦٧٨٩';
  return input
    .replace(/[٠-٩]/g, (d) => String(arabicDigits.indexOf(d)))
    .replace(/٫/g, '.')
    .replace(/٬/g, '');
}

export function extractNumericTokens(text: string): number[] {
  const normalized = normalizeArabicDigits(text);
  const matches = normalized.match(/(?<![A-Za-z])\d+(?:\.\d+)?(?![A-Za-z])/g);
  if (!matches) return [];
  return matches.map((m) => Number(m)).filter((n) => !Number.isNaN(n));
}

export function countArabicSentences(text: string): number {
  const parts = text
    .split(/[.!؟\n]+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 0);
  return parts.length;
}

export function checkComplianceCopy(
  textAr: string,
  numbersMap: Record<string, EvidenceRef>,
  options: { maxSentences?: number; requireDisclaimer?: boolean; disclaimerText?: string } = {}
): ValidationResult {
  const errors: string[] = [];
  const lower = textAr.toLowerCase();

  for (const phrase of BANNED_PHRASES) {
    if (lower.includes(phrase.toLowerCase())) {
      errors.push(`banned_phrase:${phrase}`);
    }
  }

  const allowedNums: number[] = [];
  for (const ref of Object.values(numbersMap)) {
    if (typeof ref.value === 'number' && !Number.isNaN(ref.value)) {
      allowedNums.push(ref.value);
    } else if (typeof ref.value === 'string') {
      allowedNums.push(...extractNumericTokens(ref.value));
    }
  }

  const foundNums = extractNumericTokens(textAr);
  for (const num of foundNums) {
    const matched = allowedNums.some((allowed) => Math.abs(allowed - num) < 0.001);
    if (!matched) {
      errors.push(`untraced_number:${num}`);
    }
  }

  const maxSentences = options.maxSentences ?? 3;
  if (maxSentences > 0 && countArabicSentences(textAr) > maxSentences) {
    errors.push('exceeds_max_sentences');
  }

  if (options.requireDisclaimer && (!options.disclaimerText || options.disclaimerText.trim().length < 20)) {
    errors.push('missing_disclaimer');
  }

  return { ok: errors.length === 0, errors };
}

export function fillTemplateStrict(
  template: string,
  slots: Record<string, string | number>
): { ok: boolean; text: string; missing: string[] } {
  const missing: string[] = [];
  const text = template.replace(/\{([a-zA-Z0-9_]+)\}/g, (_match, key: string) => {
    const val = slots[key];
    if (val === undefined || val === null || val === '') {
      missing.push(key);
      return `{${key}}`;
    }
    return String(val);
  });
  return { ok: missing.length === 0, text, missing };
}

export function computeSealHash(payload: Record<string, unknown>, prevSealHash: string): string {
  const canonical = JSON.stringify({ ...payload, prevSealHash });
  return crypto.createHash('sha256').update(canonical).digest('hex');
}
