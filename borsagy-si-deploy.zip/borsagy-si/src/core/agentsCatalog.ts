import { SHORT_DISCLAIMER_AR } from './marketPack';
import {
  calculateShariaAndPurification,
  calculateStockQualityScore,
  calculateTrapScore,
  runPointInTimeBacktest,
} from './deterministicServices';
import {
  AgentDefinition,
  AgentGroupKey,
  Fact,
  RiskProfile,
  StockSummary,
  SubscriptionPlan,
  SubscriptionTierId,
  TraderState,
  VersionedConfig,
} from './types';

export const AGENT_GROUPS: Array<{
  key: AgentGroupKey;
  code_ar: string;
  title_ar: string;
  range_label: string;
}> = [
  { key: 'data', code_ar: 'أ', title_ar: 'البيانات والتحليل الأساسي والفني', range_label: '١–١٠' },
  { key: 'decision', code_ar: 'ب', title_ar: 'القرار والاختبار والمخاطر', range_label: '١١–١٧' },
  { key: 'interaction', code_ar: 'ج', title_ar: 'التفاعل مع المضارب', range_label: '١٨–٢٣' },
  { key: 'governance', code_ar: 'د', title_ar: 'الحوكمة والثقة وضمان الجودة', range_label: '٢٤–٢٧' },
  { key: 'unique', code_ar: 'هـ', title_ar: 'الأفكار الفريدة (السوق المصري)', range_label: '٢٨–٣٨' },
  { key: 'safety', code_ar: 'و', title_ar: 'الحماية والثقة والانضباط النفسي', range_label: '٣٩–٤٤' },
  { key: 'advanced', code_ar: 'ز', title_ar: 'الأفكار المتقدمة والهوية المحاسبية', range_label: '٤٥–٥٨' },
  { key: 'global', code_ar: 'ح', title_ar: 'الدراسة العالمية ومنصات التنفيذ', range_label: '٥٩–٦٧' },
  { key: 'crypto_derived_egx', code_ar: 'ط', title_ar: 'الأفكار المستلهمة (للأسهم المصرية فقط)', range_label: '٦٨–٧٤' },
  { key: 'second_inquiry', code_ar: 'ي', title_ar: 'أدوات التحقق والمعايرة والبيانات المفتوحة', range_label: '٧٥–٨٢' },
  { key: 'brokerage', code_ar: 'ك', title_ar: 'اختيار ومراقبة شركات الوساطة', range_label: '٨٣–٨٤' },
];

export const TIER_ORDER: Record<SubscriptionTierId, number> = {
  free: 0,
  plus: 1,
  pro: 2,
  b2b: 3,
};

export function isAgentUnlockedForTier(agentTier: SubscriptionTierId, userTier: SubscriptionTierId): boolean {
  return TIER_ORDER[userTier] >= TIER_ORDER[agentTier];
}

export const SUBSCRIPTION_PLANS: SubscriptionPlan[] = [
  {
    id: 'free',
    name_ar: 'المجانية',
    name_en: 'Free',
    tagline_ar: 'بداية آمنة وتعلم منضبط بدون اشتراك أو إعلانات',
    monthly_egp: 0,
    annual_egp: 0,
    billing_note_ar: 'مجاناً للأبد — لا بطاقة بنكية ولا رسوم خفية',
    data_feed_ar: 'بيانات متأخرة ومؤشرات مرجعية يومية',
    agent_limit_label_ar: '٣٣ وكيلاً أساسياً للأمان والتعلم والفحص الأولي',
    highlights_ar: [
      'بطاقات هوية الأسهم وجودة البيانات ومقياس الفخ الأساسي',
      'أكاديمية بورصجي ومقياس المخاطر (1–5) وكاشف الاحتيال والتوصيات',
      'استعراض السجل المنشور المختوم بـ SHA-256 وقائمة «اختر شركتك» المحايدة',
      'حد يومي مبسط للموجز والإشعارات الهادئة',
    ],
    compliance_note_ar: 'متوافق مع مسار PATH_A (تعليم وتحليل فقط بدون توصيات شخصية مخصصة).',
  },
  {
    id: 'plus',
    name_ar: 'بلس',
    name_en: 'Plus',
    tagline_ar: 'للمتداول المنضبط: عقود الصفقات والمقارنة بالتضخم والذهب',
    monthly_egp: 249,
    annual_egp: 2490,
    billing_note_ar: 'نطاق الاستعداد للدفع المحلي (WTP) — خصم شهرين في الدفع السنوي',
    badge_ar: 'الأكثر ملاءمة للأفراد',
    data_feed_ar: 'بيانات محدثة دورياً + مقارنة الدولار والذهب والشهادات',
    agent_limit_label_ar: '٦٢ وكيلاً (تشمل الانضباط والعقود والتطهير الشرعي)',
    highlights_ar: [
      'عقود الصفقات الإلزامية قبل الدخول + مراقب الفرضية بعد الشراء',
      'تحليل الصافي بعد العمولات والضرائب + المقارنة بالذهب والتضخم',
      'حارس الذعر والفجوة السلوكية وتكلفة كسر القواعد بالجنيه',
      'نظام رخصة بورصجي وحاسبة الزكاة وتطهير الكوبونات',
    ],
    compliance_note_ar: 'أوضاع المرافق والناصح تخضع لإطار الترخيص المفعّل (PATH_B/C) ولا تنفذ أي أمر نيابة عنك.',
    recommended: true,
  },
  {
    id: 'pro',
    name_ar: 'برو',
    name_en: 'Pro',
    tagline_ar: 'القوة الكاملة لـ 81 وكيلاً فردياً والاختبار التاريخي المباشر',
    monthly_egp: 699,
    annual_egp: 6990,
    billing_note_ar: 'يغطي تكلفة تغذية الأسعار الحية (150–400 ج.م/مستخدم) + جميع وكلاء الأفراد',
    badge_ar: 'احترافي متكامل',
    data_feed_ar: 'بيانات سوق حية (Live Feed Sync) + كشف التركز الخفي للمجموعات',
    agent_limit_label_ar: '٨١ وكيلاً للأفراد + واجهة API/MCP للقراءة فقط',
    highlights_ar: [
      'محرك الاختبار التاريخي Point-in-Time بدون تسريب مستقبلي',
      'مختبر الضغط والسيناريوهات + الصحة المحاسبية + كاشف الحركات المشبوهة',
      'قارئ كشوف حسابات الوسطاء المتعددين (CSV/نص بدون كلمات مرور)',
      'السلال الموضوعية + محامي الشيطان الكامل + منشئ الاستراتيجيات بالمنطق',
    ],
    compliance_note_ar: 'التنفيذ يظل بيدك عبر «مجهّز الأوامر» فقط بدون ربط تنفيذ آلي على حساب الوساطة.',
  },
  {
    id: 'b2b',
    name_ar: 'المؤسسات والوسطاء (B2B)',
    name_en: 'Enterprise & Brokers',
    tagline_ar: 'جميع الوكلاء الـ 84 + بوابة علاقات المستثمرين وOpen Data',
    monthly_egp: 18000,
    annual_egp: 180000,
    billing_note_ar: 'تعاقد مؤسسي سنوي يبدأ من 18,000 ج.م/شهرياً حسب عدد المحافظ',
    badge_ar: 'كل الوكلاء (84)',
    data_feed_ar: 'تغذية EGID / ICE مؤسسية + تغذية إفصاحات مهيكلة API & MCP',
    agent_limit_label_ar: 'جميع الوكلاء الـ ٨٤ كاملة مع نشر White-Label',
    highlights_ar: [
      'بوابة علاقات المستثمرين للشركات المدرجة (وكيل #38)',
      'بيانات الإفصاح المنظمة وOpen Data / MCP للمؤسسات والمحللين (#67، #82)',
      'تشغيل مخصص لشركات الوساطة (White-Label) مع سجل تدقيق وحوكمة مستقلة',
      'لوحة حوكمة SLA، مختبر النماذج الجماعي (Shadow Mode)، ومعايرة Brier مخصصة',
    ],
    compliance_note_ar: 'يشترط توقيع اتفاقية ترخيص بيانات السوق والتكامل التنظيمي قبل التشغيل التجاري.',
  },
];

type RawAgentSeed = [
  number,
  string,
  string,
  string,
  AgentGroupKey,
  string,
  string,
  string,
  SubscriptionTierId,
  string,
  AgentDefinition['mode'],
  number,
];

const GROUP_TITLES: Record<AgentGroupKey, string> = Object.fromEntries(
  AGENT_GROUPS.map((g) => [g.key, `${g.code_ar}. ${g.title_ar}`])
) as Record<AgentGroupKey, string>;

// All 84 Agents from Borsagy Full v6 Complete (Sections 16 & Appendix) + v4 Consolidation Mapping (p.46)
const RAW_84_AGENTS: RawAgentSeed[] = [
  // Group أ: البيانات والتحليل (1–10)
  [1, 'data_quality', 'جودة البيانات وتوحيد الكيانات', 'Data Quality & Entity Resolution', 'data', 'الأسعار الخام، الإفصاحات، المصادر', 'حقيقة الجودة (صالح/مشكوك/موقوف) وعمر البيانات', 'يمنع التوصية عند تعطل أو تأخر التغذية', 'free', 'data_quality', 'deterministic', 0.97],
  [2, 'fundamental', 'التحليل الأساسي', 'Fundamental Analysis Agent', 'data', 'القوائم المالية، مضاعفات القطاع', 'الدرجة الأساسية ونسب P/E وROE والمديونية', 'تقييم القيمة الجوهرية ومقارنة القطاع', 'free', 'fundamental', 'deterministic', 0.76],
  [3, 'technical', 'التحليل الفني', 'Technical Analysis Agent', 'data', 'سلاسل OHLCV التاريخية', 'الاتجاه، مستويات الدعم والمقاومة، RSI وMACD', 'نطاقات الحركة الفنية بدون تنبؤ قطعي', 'free', 'technical', 'deterministic', 0.72],
  [4, 'liquidity', 'السيولة (جوهري لمصر)', 'EGX Liquidity & Exit Days Agent', 'data', 'حجم التداول 30 يوم (ADV)، الأسهم الحرة، السبريد', 'عدد أيام الخروج وتصنيف سهولة التخارج', 'حماية من أسهم السيولة الضعيفة', 'free', 'risk_sizing', 'deterministic', 0.95],
  [5, 'news_disclosures', 'الأخبار والإفصاحات', 'Arabic Disclosures & News NLP', 'data', 'إفصاحات البورصة والأخبار الاقتصادية', 'تصنيف الحدث والاتجاه وملخص 3 جمل', 'استخراج مهيكَل يخضع للمراجعة عند التعارض', 'plus', 'news_nlp', 'ai_judgment', 0.81],
  [6, 'sentiment', 'المشاعر', 'Market Sentiment Agent', 'data', 'نبرة الإفصاحات والزخم العام للسوق', 'درجة تفاؤل أو حذر السوق القطاعية', 'إشارة مساعدة بلا انحياز دعائي', 'plus', 'news_nlp', 'ai_judgment', 0.70],
  [7, 'macro_sectors', 'الاقتصاد الكلي والقطاعات', 'Macro & Sector Linkages', 'data', 'سعر الفائدة، الدولار، التضخم، شبكة القطاعات', 'أثر التغير الكلي على البنوك والعقارات والصناعة', 'تقدير الأثر مع فترة التأخير (Lag Days)', 'plus', 'macro', 'hybrid', 0.74],
  [8, 'flows_institutional', 'التدفقات (أجانب/عرب/مصريون)', 'Investor Flows & Foreign Mix', 'data', 'صافي تعاملات المؤسسات والأفراد والأجانب', 'اتجاه السيولة المؤسسية مقابل التجزئة', 'كشف اتجاهات الدخول والخروج المؤسسي', 'pro', 'technical', 'deterministic', 0.77],
  [9, 'corporate_actions', 'أحداث الشركات', 'Corporate Actions Tracker', 'data', 'توزيعات الكوبونات، زيادات رأس المال، التجزئة', 'تواريخ الحق والآثار السعرية المعدلة', 'منع الخلط بين هبوط التوزيع وهبوط الأداء', 'free', 'data_quality', 'deterministic', 0.96],
  [10, 'sharia_screening', 'الفحص الشرعي الأساسي', 'Sharia Index & Screening', 'data', 'نسب الديون والإيرادات غير التشغيلية، معيار AAOIFI', 'حالة التوافق الشرعي ونسبة الإيراد المختلط', 'فلتر شرعي قابل للتحقق ومستند على مصادر', 'free', 'fundamental', 'deterministic', 0.94],

  // Group ب: القرار (11–17)
  [11, 'screener', 'الماسح (Screener)', 'EGX Opportunity Screener', 'decision', 'كل الأسهم وخصائص الجودة والسيولة والشرعية', 'قائمة مرشحة مرتبة وفق قواعد المستثمر', 'ترشيح محكوم بفلاتر المخاطر الصارمة', 'free', 'portfolio', 'deterministic', 0.82],
  [12, 'entry_exit', 'نقاط الدخول والخروج', 'Entry, Stop & Target Planner', 'decision', 'الدعم والمقاومة والتذبذب التاريخي ATR', 'نطاق دخول + وقف خسارة حقيقي + أهداف', 'لا يخرج أي مستوى بدون وقف خسارة إلزامي', 'plus', 'technical', 'deterministic', 0.75],
  [13, 'risk_sizing', 'المخاطر وحجم الصفقة (مالك القيود)', 'Risk & Position Sizing Owner', 'decision', 'محفظة المضارب، الحدود الشخصية، التذبذب', 'أقصى حجم صفقة (أسهم وجنيه) وأقصى خسارة', 'يمتلك حق المنع الصلب (Hard Veto)', 'free', 'risk_sizing', 'deterministic', 0.98],
  [14, 'portfolio_builder', 'بناء المحفظة', 'Portfolio Allocation & Correlation', 'decision', 'المراكز المفتوحة والقطاعات والمجموعات المالكة', 'توزيع متوازن وكشف التركز المخفي', 'منع تكرار المخاطر تحت أسماء شركات مختلفة', 'plus', 'portfolio', 'deterministic', 0.88],
  [15, 'backtester_pit', 'الاختبار التاريخي (Point-in-Time)', 'Point-in-Time Backtester', 'decision', 'الشموع والسجل المعرفي known_at <= T', 'العائد الصافي وأقصى تراجع بعد العمولات', 'يرفض آلياً أي حقائق مستقبلية (Anti-Lookahead)', 'pro', 'calibration', 'deterministic', 0.93],
  [16, 'stress_simulator', 'الضغط والمحاكاة', 'Stress & Drawdown Simulator', 'decision', 'تشكيلة المحفظة وسيناريوهات هبوط EGX/FX', 'تقدير أثر صدمة 10%–20% على إجمالي المحفظة', 'اختبار مرونة المحفظة قبل حدوث الأزمات', 'pro', 'macro', 'deterministic', 0.89],
  [17, 'coordinator', 'المنسّق الموحد', 'Central Advice Coordinator', 'decision', 'ادعاءات الوكلاء + سجل المعايرة Brier', 'درجة موحدة ونسبة اتفاق وأعلام التعارض', 'يحوّل حالة انخفاض الثقة أو التعارض إلى امتناع', 'free', 'coordinator', 'hybrid', 0.84],

  // Group ج: التفاعل مع المضارب (18–23)
  [18, 'onboarding_agent', 'التعارف وبناء ملف المخاطر', 'Onboarding & Risk Profiling', 'interaction', 'الخبرة، رأس المال القابل للخسارة، الهدف', 'ملف مخاطر محكم وسقوف إلزامية للمبتدئ', 'يمنع التوصيات ذات المخاطرة مع الأموال المقترضة', 'free', 'companion', 'deterministic', 0.95],
  [19, 'trader_matcher', 'مطابقة المضارب والأفق الزمني', 'Trader Style & Horizon Matcher', 'interaction', 'أفق الاستثمار، المزاج، الالتزام بالوقت', 'مواءمة وضع مدير المحفظة أو الناصح', 'يربط كل متداول بالإيقاع المناسب له', 'plus', 'companion', 'deterministic', 0.86],
  [20, 'companion', 'المرافق (الرسائل الموجزة)', 'Personalized Arabic Companion', 'interaction', 'المسودة المتحققة والادعاءات المختومة', 'صياغة لا تتجاوز 3 جمل بلهجة واضحة وهادئة', 'ممنوع اختراع أي رقم خارج خريطة الأدلة', 'free', 'companion', 'ai_judgment', 0.91],
  [21, 'behavior_discipline', 'السلوك والانضباط', 'Behavior & Impulse Analyzer', 'interaction', 'سجل الصفقات والخطط والتوقيتات', 'وسوم الانحراف (تسرع/انتقام) وتكلفة كسر القواعد', 'يكشف فاتورة الانفعال بالأرقام الحقيقية', 'plus', 'behavior', 'deterministic', 0.90],
  [22, 'education_agent', 'التعليم التفاعلي', 'EGX Interactive Academy', 'interaction', 'أسئلة المستثمر ومصطلحات السوق', 'دروس 3 دقائق وأمثلة مصرية واضحة', 'تعليم عملي بلا حشو أو تعقيد نظري', 'free', 'education', 'ai_judgment', 0.94],
  [23, 'reports_brief', 'التقارير والملخصات', 'Daily & Weekly Executive Brief', 'interaction', 'مؤشرات المحفظة وحركات السوق والقرارات', 'موجز يومي في 3 دقائق دون إغراق', 'يركّز على أسباب حركة المحفظة قبل أي إجراء', 'free', 'companion', 'deterministic', 0.89],

  // Group د: الحوكمة والثقة (24–27)
  [24, 'compliance_gate', 'الامتثال والحوكمة', 'Compliance & Policy Gate', 'governance', 'مسودة النص، الأرقام، قائمة الحظر التنظيمي', 'قبول / حجب مع سجل الأسباب والإخلاء', 'آخر بوابة قبل العرض: لا ضمانات ولا أرقام بلا دليل', 'free', 'compliance', 'deterministic', 1.0],
  [25, 'track_record_agent', 'سجل الأداء المنشور', 'Sealed Public Track Record', 'governance', 'كل النصائح والنتائج (ربح/خسارة/امتناع)', 'سلسلة تجزئة SHA-256 غير قابلة للتزوير', 'ينشر الإخفاقات والامتناعات بنفس شفافية الأرباح', 'free', 'calibration', 'deterministic', 0.99],
  [26, 'qa_monitor', 'المراقب (ضمان الجودة)', 'Quality Assurance Auditor', 'governance', 'دقة الروابط السبع بين النص والبيانات', 'تنبيه فوري للمشرفين أو إيقاف النصيحة', 'مراقبة صامتة تمنع أي تسرب أو تناقض', 'pro', 'red_team', 'deterministic', 0.96],
  [27, 'support_community', 'الدعم والمجتمع الآمن', 'Safe Community & Support Desk', 'governance', 'استفسارات المستخدمين وإبلاغات الأخطاء', 'حلول إجرائية دون تقديم وعود أو نصائح مدفوعة', 'دعم سريع يحفظ خصوصية الحساب', 'plus', 'education', 'hybrid', 0.88],

  // Group هـ: الأفكار الفريدة للسوق المصري (28–38)
  [28, 'net_costs', 'التكاليف والصافي', 'Net-After-Fees Return Engine', 'unique', 'عمولة الوسيط + رسوم البورصة والرقابة والمقاصة', 'نقطة التعادل والعائد الصافي الحقيقي بالجنيه', 'يكشف أثر تكرار المضاربة على صافي الربح', 'plus', 'risk_sizing', 'deterministic', 0.99],
  [29, 'asset_inflation_compare', 'مقارنة الأصول والتضخم', 'Asset & Inflation Benchmark', 'unique', 'عائد الشهادات، أذون الخزانة، التضخم، الدولار، الذهب', 'مقارنة العائد الحقيقي للمحفظة أمام البدائل الآمنة', 'يمنع وهم الربح الاسمي تحت تضخم مرتفع', 'plus', 'macro', 'deterministic', 0.95],
  [30, 'monetary_calendar', 'التقويم والسياسة النقدية', 'CBE & EGX Event Calendar', 'unique', 'اجتماعات المركزي، نتائج الأعمال، أوقات التداول ورمضان', 'جدول تنبيهات استباقي لأيام التقلب العالية', 'يربط جلسات EGX ومزادات الإغلاق بوضوح', 'plus', 'macro', 'deterministic', 0.92],
  [31, 'ipo_ma_tracker', 'الطروحات والاستحواذات', 'IPO & M&A Evaluation Tracker', 'unique', 'نشرات الطرح العام وعروض الشراء الإجباري', 'ملخص شروط الطرح والتقييم وموعد الاستحقاق', 'تغطية محايدة للطروحات الجديدة في السوق', 'pro', 'news_nlp', 'hybrid', 0.80],
  [32, 'rumor_advice_checker', 'فاحص التوصيات والشائعات', 'Rumor & Tip Verifier', 'unique', 'نصوص الإعلانات والتوصيات المنتشرة', 'فحص مؤشرات التضليل والوعود الوهمية والضغط النفسي', 'متاح للجميع مجاناً لحماية المستثمرين الأفراد', 'free', 'compliance', 'deterministic', 0.96],
  [33, 'suspicious_moves', 'كاشف الحركات المشبوهة', 'Unexplained Volume & Spike Detector', 'unique', 'قفزات السعر والحجم غير المصحوبة بإفصاح', 'إدراج للمراجعة البشرية ورفع مقياس الفخ', 'يمنع ملاحقة أسهم المضاربات الوهمية', 'pro', 'data_quality', 'deterministic', 0.91],
  [34, 'statement_reader', 'قارئ كشف الوساطة', 'Broker Statement Parser (CSV/Text)', 'unique', 'ملف CSV أو نص كشف حساب من الوسيط', 'استيراد المراكز آلياً مع خيار مسح الملف الخام فوراً', 'بديل آمن تماماً لطلب كلمات مرور الوسطاء', 'pro', 'portfolio', 'deterministic', 0.95],
  [35, 'black_box_explainer', 'الصندوق الأسود للقرار', 'Decision Audit & Replay Box', 'unique', 'لقطة الأنطولوجيا الكاملة لحظة صدور النصيحة', 'شجرة استدلال من 3 مستويات: لماذا صدر هذا القرار؟', 'شفافية رقمية لكل رقم وعامل مؤثر', 'plus', 'coordinator', 'deterministic', 0.98],
  [36, 'paper_competitions', 'المحاكاة والتدريب المنضبط', 'Paper Sandbox & Contests', 'unique', 'محفظة افتراضية بأموال تجريبية وأسعار حقيقية', 'مؤشر التزام بالخطة والمخاطر وليس العائد المتهور فقط', 'تدريب آمن قبل المخاطرة برأس المال الفعلي', 'free', 'behavior', 'deterministic', 0.90],
  [37, 'dialect_voice', 'الصوت واللهجة', 'Dialect Adaptation (EG / Gulf / Levant)', 'unique', 'تفضيل اللهجة وشكل الأرقام (غربية/هندية)', 'ضبط الخطاب دون تغيير الحقائق أو الصرامة', 'خطاب مصري أو خليجي أو شامي واضح ومريح', 'free', 'companion', 'ai_judgment', 0.93],
  [38, 'ir_portal_b2b', 'علاقات المستثمرين (B2B)', 'Listed Company IR Portal', 'unique', 'إفصاحات الشركة المدرجة وتساؤلات المستثمرين', 'لوحة B2B موثقة لنشر الإفصاحات المنظمة', 'ربط مباشر مع الشركات المدرجة للبيانات الرسمية', 'b2b', 'news_nlp', 'api_service', 0.90],

  // Group و: الحماية والثقة (39–44)
  [39, 'portfolio_guardian', 'حارس المحفظة', 'Daily & Weekly Drawdown Guardian', 'safety', 'الخسارة اليومية والأسبوعية وعدد الخسائر المتتالية', 'إيقاف وقائي تلقائي (HALT) وفترة تهدئة 24 ساعة', 'يحميك من الانهيار السريع في جلسات سيئة', 'free', 'risk_sizing', 'deterministic', 0.99],
  [40, 'anti_fraud', 'مكافحة الاحتيال', 'Anti-Scam & Fraud Shield', 'safety', 'رسائل الواتساب/التليجرام وروابط الاشتراك المشبوهة', 'تصنيف خطورة (منخفض/متوسط/عالي) وشرح الأعلام', 'يكشف الوعود المضمونة ومجموعات التلاعب', 'free', 'compliance', 'deterministic', 0.97],
  [41, 'crisis_mode', 'وضع الأزمة', 'Crisis Mode Protector', 'safety', 'هبوط المؤشر >=3% أو إيقاف >=5 أسهم كبرى أو التفعيل اليدوي', 'تجميد الإشارات الهجومية وتفعيل شريط التهدئة', 'أولوية قصوى لحفظ رأس المال عند الصدمات', 'free', 'risk_sizing', 'deterministic', 1.0],
  [42, 'wellbeing_tilt', 'الرفاهية والانضباط النفسي', 'Mental Wellbeing & Tilt Monitor', 'safety', 'سرعة الصفقات بعد الخسارة، حالة المزاج، ساعات الهدوء', 'حساب مؤشر الانفعال Tilt (0–100) وتنبيه المراقب الموثوق بموافقتك', 'تكنولوجيا محترمة لسلامة المتداول النفسية', 'plus', 'behavior', 'deterministic', 0.92],
  [43, 'security_privacy', 'الأمن والخصوصية وسيادة البيانات', 'Zero-Custody & Cascade Deletion', 'safety', 'طلب التصدير JSON أو الحذف الشامل /api/me', 'حذف نهائي متسلسل لكل بيانات المستخدم وما اشتُق منها', 'البيانات ملكك وحدك بلا بيع أو تتبع خفي', 'free', 'compliance', 'deterministic', 1.0],
  [44, 'conflict_transparency', 'الشفافية وتضارب المصالح', 'Conflict of Interest Firewall', 'safety', 'إعلانات الوسطاء، الإحالات، ميثاق الأمان الـ 10', 'منع الإعلانات والترتيب المدفوع وتوثيق الحياد', 'اختبار مستمر لاستقلالية القرار والوسيط', 'free', 'compliance', 'deterministic', 1.0],

  // Group ز: الأفكار المتقدمة (45–58)
  [45, 'devils_advocate', 'محامي الشيطان', 'Devil’s Advocate & Counter-Thesis', 'advanced', 'كل صفقة مقترحة والأدلة السلبية المعاكسة', 'سرد أقوى حجتين ضد الدخول قبل التوقيع', 'يمنع التحيز التأكيدي (Confirmation Bias)', 'plus', 'red_team', 'hybrid', 0.89],
  [46, 'trade_contract', 'عقد الصفقة', 'Pre-Trade Contract Binder', 'advanced', 'السبب، سعر الدخول، وقف الخسارة، الأهداف، أسوأ سيناريو', 'توقيع رقمي ملزم أخلاقياً قبل فتح أي مركز', 'لا صفقة بلا خطة مكتوبة وموقعة', 'plus', 'behavior', 'deterministic', 0.96],
  [47, 'behavioral_gap', 'الفجوة السلوكية والمزاج', 'Behavioral Gap Estimator', 'advanced', 'عائد الالتزام بالخطة مقابل العائد الفعلي بعد الكسر', 'تكلفة كسر القواعد بالجنيه والنسبة المئوية', 'يحوّل الانضباط إلى قيمة مالية ملموسة', 'plus', 'behavior', 'deterministic', 0.94],
  [48, 'borsagy_licence', 'رخصة بورصجي', 'Progressive Investor Licence', 'advanced', 'النتائج السلوكية، التزام وقف الخسارة، عدد الصفقات المنضبطة', 'تدرج المستويات (1←2←3) وأهلية الترقية الآمنة', 'فتح صلاحيات أوسع فقط عند إثبات الانضباط', 'plus', 'behavior', 'deterministic', 0.93],
  [49, 'stock_id_card', 'بطاقة هوية السهم', 'One-Page Stock ID Card', 'advanced', 'النشاط، مصادر الإيراد، المخاطر الرئيسية، التوافق الشرعي', 'بطاقة تعريف واضحة بالعربية في دقيقة واحدة', 'تعرف ماذا تشتري قبل أن تنظر للرسم البياني', 'free', 'fundamental', 'deterministic', 0.95],
  [50, 'accounting_health', 'الصحة المحاسبية', 'Accounting Quality & Red Flags', 'advanced', 'نمو الأرباح مقابل التدفق النقدي، الديون، التحفظات', 'إنذار مبكر للفجوات المحاسبية وارتفاع الاستدانة', 'مقتبس من منهجيات فحص الجودة المالية', 'pro', 'fundamental', 'deterministic', 0.86],
  [51, 'ownership_graph', 'الملكية والعلاقات', 'Ownership & Group Knowledge Graph', 'advanced', 'صلات الملاك الكبار والمجموعات والقطاعات في الأنطولوجيا', 'رسم تركز المجموعة المالكة المخفي في المحفظة', 'يكشف أن سهمين مختلفين يتبعان نفس المجموعة', 'plus', 'portfolio', 'deterministic', 0.97],
  [52, 'historical_precedents', 'السوابق التاريخية', 'Historical Precedent Matcher', 'advanced', 'دورات السوق السابقة، أزمات الصرف، توزيعات مماثلة', 'كيف تصرف السهم والقطاع في ظروف مشابهة؟', 'سياق تاريخي بعيداً عن التهويل أو التفاؤل المفرط', 'pro', 'macro', 'deterministic', 0.78],
  [53, 'diversification_corr', 'التنويع والارتباط', 'Correlation & Effective Positions', 'advanced', 'ارتباط الأسهم خلال أزمات السيولة والتذبذب', 'حساب عدد المراكز الفعلي مقابل الظاهري', 'يحذر عندما تصبح 5 أسهم وكأنها مركز واحد', 'plus', 'portfolio', 'deterministic', 0.91],
  [54, 'expectation_calibration', 'ضبط التوقعات', 'Expectation Reality Check', 'advanced', 'الهدف المتوقع من المستثمر ومضاعف المخاطرة للعائد', 'تصحيح التوقعات غير الواقعية مقارنة بسوق EGX', 'بناء خطط بعوائد منطقية ومستدامة', 'plus', 'companion', 'deterministic', 0.89],
  [55, 'crowding_guard', 'ازدحام الصفقة', 'Platform Crowding Guard', 'advanced', 'تركّز توصيات وإشارات المنصة على نفس السهم قليل السيولة', 'تهدئة وإيقاف الاقتراحات عند ازدحام المستخدمين', 'يمنع تحوّل المنصة إلى سبب لضغط السعر', 'pro', 'risk_sizing', 'deterministic', 0.95],
  [56, 'best_alternative', 'البديل الأنسب', 'Lower-Risk / Higher-Liquidity Swap', 'advanced', 'سهم مرفوض للسيولة/التركز + نظرائه في نفس القطاع', 'اقتراح بديل أعلى سيولة وأقل مخاطرة إن وُجد', 'لا يكتفي بالرفض بل يبحث عن خيار أكثر أماناً', 'plus', 'portfolio', 'deterministic', 0.85],
  [57, 'budgeted_alerts', 'التنبيهات والملخصات بميزانية', 'Notification Budgeter & Quiet Hours', 'advanced', 'سقف التنبيهات اليومي (5) وساعات الهدوء الليلية', 'منع الإزعاج ودفع المستثمر لفتح الشاشة بلا داعٍ', 'احترام وقتك وأعصابك قبل الإشعارات', 'free', 'companion', 'deterministic', 0.98],
  [58, 'strategy_builder', 'منشئ الاستراتيجيات', 'No-Code Rule & Backtest Studio', 'advanced', 'قواعد دخول وخروج مخصصة + PIT Backtester', 'بناء استراتيجية واختبارها تاريخياً بلا أكواد', 'صياغة منهجك الخاص واختباره قبل رأس المال', 'pro', 'technical', 'deterministic', 0.84],

  // Group ح: الدراسة العالمية (59–67)
  [59, 'portfolio_move_reason', 'سبب تحرك المحفظة', 'Why Did My Portfolio Move Today?', 'global', 'مساهمة كل مركز وتغير سعر الصرف وأخبار القطاع', 'شرح فوري واضح لسبب تغير القيمة اليومية', 'تفكيك الأرباح والخسائر لمسبباتها الحقيقية', 'free', 'portfolio', 'deterministic', 0.94],
  [60, 'hypothesis_monitor', 'مراقب الفرضية', 'Live Thesis & Invalidation Watcher', 'global', 'سبب الشراء المسجل في عقد الصفقة + الإفصاحات الجديدة', 'تنبيه فوري إذا انتفى السبب الأصلي لدخول السهم', 'يمنع التعلق العاطفي بسهم انتهت فرضيته', 'plus', 'behavior', 'hybrid', 0.88],
  [61, 'order_preparer', 'مجهّز الأوامر (بدون تنفيذ)', 'Order Ticket Preparer', 'global', 'حجم الصفقة المعتمد وسعر الدخول والوقف المحسوب', 'بطاقة أمر واضحة جاهزة للنسخ لشركة وساطتك', 'إعداد منضبط 100% — التنفيذ بيدك وحدك', 'plus', 'risk_sizing', 'deterministic', 0.98],
  [62, 'drift_tagger', 'عداد الانحراف والوسم', 'Rule Drift & Deviation Tagger', 'global', 'الفرق بين سعر التنفيذ الفعلي وسعر خطتك الموقعة', 'تصنيف الخروج (مبكر / بدون وقف / إفراط حجم)', 'تراكم بيانات دقيقة لتحسين جودة قراراتك', 'plus', 'behavior', 'deterministic', 0.93],
  [63, 'thematic_baskets', 'السلال الموضوعية', 'Thematic EGX Baskets Builder', 'global', 'أسهم البتروكيماويات / التصدير / التوزيعات / الشرعية', 'سلال جاهزة موزونة المخاطر والسيولة', 'تنويع موضوعي محسوب لقطاعات البورصة المصرية', 'pro', 'portfolio', 'deterministic', 0.87],
  [64, 'multi_broker_sync', 'التكامل متعدد الوسطاء', 'Multi-Broker Read-Only Aggregator', 'global', 'كشوف CSV من أكثر من شركة وساطة', 'تجميع المراكز في محفظة موحدة لحساب التركز', 'رؤية شاملة دون مشاركة أي كلمة مرور', 'pro', 'portfolio', 'deterministic', 0.94],
  [65, 'performance_attribution', 'تدقيق الأداء والنتائج', 'Performance Attribution (Skill vs Market)', 'global', 'النتائج التاريخية مقارنة بمؤشر EGX30 والقطاع', 'فصل أثر السوق العام عن مهارة الاختيار والتنفيذ', 'تقييم عادل يوضح نقاط القوة والضعف', 'pro', 'calibration', 'deterministic', 0.90],
  [66, 'retail_crowd_mood', 'مزاج المضاربين المنظم', 'Aggregated Investor Mood Telemetry', 'global', 'توزيع حالات التوتر والهدوء ومؤشرات الفومو', 'قياس موجات الحماس المفرط والذعر الجماعي', 'أداة وعي جماعي تقلل الانجراف مع القطيع', 'pro', 'behavior', 'deterministic', 0.85],
  [67, 'developer_api_mcp', 'بوابة المطورين (API وMCP)', 'Read-Only Developer API & MCP', 'global', 'الأنطولوجيا والبيانات المهيكلة وحسابات الجودة', 'واجهات JSON / MCP موثقة للمحللين والمؤسسات', 'قراءة فقط محكومة بمفاتيح وصول وحدود أمان', 'pro', 'data_quality', 'api_service', 0.99],

  // Group ط: الأفكار المستلهمة للأسهم المصرية فقط (68–74 — بدون عملات رقمية)
  [68, 'stock_trap_checker', 'فاحص فخ السهم (Trap Score)', 'EGX Trap & Illiquidity Detector', 'crypto_derived_egx', 'الأسهم الحرة، تركّز الملكية، أيام الخروج، القفزات', 'نتيجة فخ (0–100) وتفكيك تفصيلي لـ 5 عوامل', 'حماية من أسهم التجميع والتصريف ضعيفة السيولة', 'free', 'risk_sizing', 'deterministic', 0.95],
  [69, 'transparency_seal', 'ختم الشفافية (SHA-256)', 'Tamper-Evident Recommendation Seal', 'crypto_derived_egx', 'بيانات التوصية والوقت وتجزئة التوصية السابقة', 'بصمة رقمية SHA-256 متسلسلة لكل توصية', 'إثبات رياضي لعدم التعديل أو الحذف بأثر رجعي', 'free', 'compliance', 'deterministic', 1.0],
  [70, 'verified_traders_optin', 'المضاربون الموثقون (بإذن فقط)', 'Verified Opt-In Performance Feed', 'crypto_derived_egx', 'إحصائيات التزام موثقة لمتطوعين بموافقتهم', 'عرض نماذج انضباط حقيقية بأسماء مستعارة', 'تعلم من الانضباط الحقيقي بدون نسخ صفقات أعمى', 'pro', 'calibration', 'deterministic', 0.92],
  [71, 'whale_block_context', 'سياق الكبار والأحجام الضخمة', 'Block Trade & Major Holder Context', 'crypto_derived_egx', 'تغيرات ملكية المساهمين الكبار والصفقات ذات الحجم الخاص', 'توضيح ما إذا كانت الصفقات داخلية أو إعادة هيكلة', 'قراءة هادئة لتغيرات الملكية بدون شائعات', 'pro', 'news_nlp', 'hybrid', 0.86],
  [72, 'egx_fear_greed', 'مؤشر الخوف والطمع المصري', 'EGX Fear & Greed Index (0–100)', 'crypto_derived_egx', 'نسبة الصاعدة/الهابطة، RSI السوق، حدة التذبذب', 'مؤشر يومي (0–100) يشرح مزاج الجلسة الحالية', 'بوصلة لضبط توقيت الحذر مقابل التفاؤل الزائد', 'free', 'technical', 'deterministic', 0.88],
  [73, 'finfluencer_auditor', 'مدقق القنوات والـ Finfluencers', 'Channel & Finfluencer Claim Auditor', 'crypto_derived_egx', 'سجل التوصيات المنسوبة لقنوات ومنصات خارجية', 'فحص الموضوعية والأدلة ونسبة تحقق الادعاءات', 'يساعد المبتدئ على فرز المحتوى الرصين من الضجيج', 'plus', 'compliance', 'hybrid', 0.90],
  [74, 'dca_planner', 'الشراء الدوري المنظم (DCA)', 'Disciplined Periodic Investing Plan', 'crypto_derived_egx', 'المبلغ الشهري المتاح، السهم/السلة المختارة، العمولات', 'خطة بناء مركز تدريجي على دفعات متباعدة', 'تقليل مخاطر توقيت الدخول الخاطئ بسعر واحد', 'plus', 'portfolio', 'deterministic', 0.94],

  // Group ي: أدوات التحقق والمعايرة والبيانات المفتوحة (75–82)
  [75, 'entity_fra_verifier', 'التحقق من الجهات والتراخيص', 'FRA & Broker Entity Verifier', 'second_inquiry', 'سجل الشركات والكيانات المرخصة بالرقابة المالية', 'تأكيد صفة الجهة المعلنة قبل التعامل معها', 'خط دفاع ضد التطبيقات والجهات غير المرخصة', 'free', 'compliance', 'deterministic', 0.98],
  [76, 'claim_verifier', 'فاحص ادعاءات الأداء', 'Performance Claim Auditor', 'second_inquiry', 'ادعاءات العوائد التاريخية واللقطات المتداولة', 'مطابقة الادعاء مع الحدود والعمولات والواقع التاريخي', 'كشف الأرباح الترويجية منزوعة التكاليف والمخاطر', 'plus', 'compliance', 'deterministic', 0.94],
  [77, 'advanced_sharia_purify', 'الشرعي المتقدم وتطهير الكوبونات', 'Advanced Sharia & Purification Calculator', 'second_inquiry', 'قيمة التوزيعات النقدية + نسبة الإيراد غير المتوافق + حساب الزكاة', 'مبلغ التطهير الدقيق للأسهم وتقدير الزكاة بالجنيه', 'حساب شرعي مفصّل للمستثمر طويل الأجل', 'plus', 'fundamental', 'deterministic', 0.97],
  [78, 'disclosure_simplifier', 'مترجم ومبسّط الإفصاحات', 'Bilingual Disclosure Simplifier', 'second_inquiry', 'النص القانوني والمالي المطوّل لإفصاحات EGX', 'تبسيط في 3 نقاط عربية مفهومة لغير المتخصص', 'ردم الفجوة اللغوية في قراءة القوائم والقرارات', 'plus', 'news_nlp', 'ai_judgment', 0.91],
  [79, 'shadow_model_lab', 'مختبر النماذج الجماعي (Shadow Mode)', 'Shadow Model & A/B Evaluation Lab', 'second_inquiry', 'تشغيل التحديثات على مسار صامت قبل اعتمادها', 'مقارنة دقة النماذج الجديدة قبل التفعيل الرسمي', 'يمنع طرح أي تحديث قبل إثبات كفاءته وأمانه', 'b2b', 'calibration', 'deterministic', 0.95],
  [80, 'brier_calibration', 'المعايرة (Brier Calibration)', 'Confidence & Brier Score Calibrator', 'second_inquiry', 'الثقة المتوقعة مقابل النجاح الفعلي عبر الفئات', 'منحنى المعايرة وتحديث أوزان الوكلاء ديناميكياً', 'يضمن أن ثقة 80% تعني تاريخياً قرابة 80% تحققاً', 'pro', 'calibration', 'deterministic', 0.96],
  [81, 'ethical_nudges', 'التصميم الأخلاقي والإشعار المفيد', 'Calm Ethical UX & Anti-Addiction Gate', 'second_inquiry', 'التوقيت، عدد التنبيهات، نبرة الإشعارات', 'تقليص المحفزات اللحظية لصالح الوضوح والهدوء', 'مصمم لمصلحة محفظتك لا لزيادة نقرات التداول', 'free', 'companion', 'deterministic', 0.99],
  [82, 'structured_open_data', 'بيانات الإفصاح المنظمة (Open Data B2B)', 'Structured EGX Disclosures API', 'second_inquiry', 'أرشيف الإفصاحات المنظمة بصيغة JSON/CSV', 'تزويد المحللين والمؤسسات ببيانات تاريخية نظيفة', 'بيانات منظمة جاهزة للبحث الأكاديمي والمؤسسي', 'b2b', 'data_quality', 'api_service', 0.97],

  // Group ك: شركات الوساطة (83–84)
  [83, 'broker_comparator', '«اختر شركتك» للمقارنة المحايدة', 'Choose Your Broker Neutral Engine', 'brokerage', 'متوسط حجم أمرك، عدد الصفقات الشهرية، الاحتياج للبحوث', 'ترتيب محايد لشركات الوساطة بحصة السوق والرسوم المؤكدة', 'لا عمولة إحالة — ومجرد من أي دعاية مدفوعة', 'free', 'risk_sizing', 'deterministic', 0.98],
  [84, 'broker_fee_monitor', 'مراقب أسعار الوساطة (Verified / TO_COLLECT)', 'Broker Fee Tracker & Verifier', 'brokerage', 'جداول الرسوم الرسمية لشركات الوساطة وتواريخ تحققها', 'تحديث الأسعار المؤكدة وحفظ TO_COLLECT لغير المؤكد', 'يلتزم الصدق: لا يقدّر أو يخمن رسوماً غير موثقة', 'free', 'compliance', 'deterministic', 1.0],
];

export const ALL_84_AGENTS: AgentDefinition[] = RAW_84_AGENTS.map(
  ([
    number,
    id,
    name_ar,
    name_en,
    group_key,
    reads_ar,
    writes_ar,
    output_ar,
    tier,
    v4_consolidated_to,
    mode,
    calibration_hit_rate,
  ]) => ({
    id,
    number,
    name_ar,
    name_en,
    group_key,
    group_ar: GROUP_TITLES[group_key],
    reads_ar,
    writes_ar,
    output_ar,
    tier,
    v4_consolidated_to,
    mode,
    enabled: true,
    calibration_hit_rate,
  })
);

export interface AgentUsageGuide {
  purpose_ar: string;
  how_it_works_ar: string;
  steps_ar: string[];
  example_ar: string;
  caution_ar: string;
  related_route?: { route: 'market' | 'stock' | 'portfolio' | 'discipline' | 'brokers' | 'track_record' | 'academy' | 'onboarding' | 'admin' | 'home'; label_ar: string };
}

export interface AgentExecutionResult {
  agent: AgentDefinition;
  symbol: string;
  as_of: string;
  headline_ar: string;
  summary_ar: string;
  verdict_ar: string;
  metrics: Array<{ label_ar: string; value: string; source_fact_id: string }>;
  cited_fact_ids: string[];
  usage_guide: AgentUsageGuide;
  disclaimer_ar: string;
}

const RELATED_ROUTE_BY_GROUP: Record<AgentGroupKey, AgentUsageGuide['related_route']> = {
  data: { route: 'market', label_ar: 'افتح رادار السوق والأسهم' },
  decision: { route: 'home', label_ar: 'افتح موجز القرار اليومي' },
  interaction: { route: 'discipline', label_ar: 'افتح لوحة الانضباط' },
  governance: { route: 'track_record', label_ar: 'افتح السجل المختوم' },
  unique: { route: 'home', label_ar: 'افتح الموجز والأدوات' },
  safety: { route: 'portfolio', label_ar: 'راجع حدود حماية المحفظة' },
  advanced: { route: 'portfolio', label_ar: 'افتح تحليلات المحفظة' },
  global: { route: 'portfolio', label_ar: 'افتح أدوات المحفظة' },
  crypto_derived_egx: { route: 'market', label_ar: 'فحص أسهم EGX' },
  second_inquiry: { route: 'track_record', label_ar: 'السجل والمعايرة' },
  brokerage: { route: 'brokers', label_ar: 'افتح مقارنة شركات التداول' },
};

export function getAgentUsageGuide(agent: AgentDefinition, symbol = 'COMI', stockNameAr = 'التجاري الدولي'): AgentUsageGuide {
  let related_route = RELATED_ROUTE_BY_GROUP[agent.group_key];
  if (agent.number === 18) related_route = { route: 'onboarding', label_ar: 'ابدأ تقييم المخاطر (٥ خطوات)' };
  else if (agent.number === 22) related_route = { route: 'academy', label_ar: 'افتح أكاديمية بورصجي' };
  else if (agent.number === 24 || agent.number === 26 || agent.number === 79) related_route = { route: 'admin', label_ar: 'افتح لوحة الحوكمة' };
  else if (agent.number === 49 || agent.number <= 4 || agent.number === 68) related_route = { route: 'stock', label_ar: `افتح بطاقة ${symbol}` };

  return {
    purpose_ar: `${agent.output_ar}. يساعدك الوكيل #${agent.number} (${agent.name_ar}) قبل اتخاذ القرار على سهم ${symbol} (${stockNameAr}).`,
    how_it_works_ar: `يقرأ من الأنطولوجيا: (${agent.reads_ar})، ثم يطبّق قواعده التحليلية ليُخرج: (${agent.writes_ar}) مربوطة بمعرفات الحقائق الزمنية.`,
    steps_ar: [
      `اختر السهم المستهدف (مثل ${symbol}) وتأكد أن حالة البيانات سليمة وغير موقوفة.`,
      `اضغط «تشغيل الوكيل على ${symbol}» لقراءة الأرقام المعتمدة ومراجعة معرّفات الحقائق (Fact IDs).`,
      `قارن النتيجة بحدود مخاطرك في المحفظة؛ وإذا ظهر تحذير أو امتناع فالتزم بعدم تجاوز السقف الآمن.`,
    ],
    example_ar: `مثال عملي: عند فحص سهم ${symbol}، يستخدم الوكيل #${agent.number} البيانات الموثقة (${agent.reads_ar}) ليمنحك ملخصاً واضحاً (${agent.writes_ar}) دون أي وعود بالربح.`,
    caution_ar:
      agent.mode === 'ai_judgment' || agent.mode === 'hybrid'
        ? 'هذا الوكيل يعتمد على نماذج تحليل لغوي منضبطة؛ يُراجع دائماً أمام الحقائق الرقمية وسجل الامتثال قبل التصرف.'
        : 'النتيجة حتمية مبنية على آخر حقائق مسجلة؛ أي تأخر أو انقطاع في التغذية يدفع النظام للاحتراز أو الامتناع تلقائياً.',
    related_route,
  };
}

/**
 * Deterministic Ontology-Grounded Execution for ANY of the 84 agents (#1..#84) on a chosen EGX stock.
 * All numbers trace strictly to bitemporal Fact IDs or stock ontology records (zero hallucinated numbers).
 */
export function executeAgentAnalysis(params: {
  agent: AgentDefinition;
  stock: StockSummary;
  facts: Fact[];
  config: VersionedConfig;
  profile?: RiskProfile;
  traderState?: TraderState;
  as_of: string;
}): AgentExecutionResult {
  const { agent, stock, facts, config, profile, traderState, as_of } = params;
  const stockFacts = facts.filter((f) => f.entity_id === stock.id && Date.parse(f.known_at) <= Date.parse(as_of));
  const priceFact = stockFacts.find((f) => f.predicate === 'last_price')?.id ?? `fact_${stock.symbol}_last_price`;
  const advFact = stockFacts.find((f) => f.predicate === 'adv_30d')?.id ?? `fact_${stock.symbol}_adv_30d`;
  const peFact = stockFacts.find((f) => f.predicate === 'pe_ratio')?.id ?? `fact_${stock.symbol}_pe_ratio`;
  const rsiFact = stockFacts.find((f) => f.predicate === 'rsi_14')?.id ?? `fact_${stock.symbol}_rsi_14`;

  const quality = calculateStockQualityScore(stock, facts, as_of, config);
  const portfolioSize = profile?.portfolio_size_egp ?? 100_000;
  const plannedTicket = Math.round(portfolioSize * ((profile?.single_stock_cap_pct ?? 20) / 100));
  const trap = calculateTrapScore(stock, plannedTicket, config);
  const sharia = calculateShariaAndPurification(
    stock,
    stock.price * 100 * (stock.dividend_yield_pct / 100),
    stock.price * 100,
    'investment',
    'AAOIFI'
  );
  const usage_guide = getAgentUsageGuide(agent, stock.symbol, stock.name_ar);
  const cited = Array.from(new Set([priceFact, advFact, peFact, rsiFact, ...(quality.evidence_ids ?? [])]));

  if (agent.group_key === 'data' || agent.number === 77 || agent.number === 49 || agent.number === 50) {
    const isSharia = agent.number === 10 || agent.number === 77;
    if (isSharia) {
      return {
        agent,
        symbol: stock.symbol,
        as_of,
        headline_ar: `نتيجة وكيل #${agent.number}: ${stock.sharia_compliant ? 'متوافق مبدئياً مع الضوابط الشرعية' : 'غير متوافق مع الفحص الشرعي القياسي'}`,
        summary_ar: `فُحص سهم ${stock.symbol} (${stock.name_ar}) بنسبة إيراد غير تشغيلي ${sharia.nonHalalRevenuePct}% ونسبة مديونية ${stock.debt_to_equity}.`,
        verdict_ar: sharia.scholarNoteAr,
        metrics: [
          { label_ar: 'حالة التوافق', value: stock.sharia_compliant ? 'متوافق (AAOIFI)' : 'غير متوافق', source_fact_id: peFact },
          { label_ar: 'الإيراد المختلط', value: `${sharia.nonHalalRevenuePct}%`, source_fact_id: peFact },
          { label_ar: 'تقدير الزكاة لـ 100 سهم', value: `${sharia.estimatedZakatEgp} ج.م`, source_fact_id: priceFact },
        ],
        cited_fact_ids: cited,
        usage_guide,
        disclaimer_ar: SHORT_DISCLAIMER_AR,
      };
    }

    return {
      agent,
      symbol: stock.symbol,
      as_of,
      headline_ar: `تحليل #${agent.number} (${agent.name_ar}) على سهم ${stock.symbol}`,
      summary_ar: quality.blocked
        ? `توقّف الفحص الرقمي للسهم: ${quality.block_reason_ar}`
        : `جودة البيانات سليمة بعمر ${Math.round(stock.data_age_seconds / 60)} دقيقة، والدرجة المجمعة ${quality.total}/100 (أساسي ${quality.fundamental} · فني ${quality.technical} · سيولة ${quality.liquidity}).`,
      verdict_ar: quality.blocked
        ? 'امتنع عن إصدار تقدير رقمي التزاماً بقاعدة جودة البيانات.'
        : `السهم مصنف بمتوسط تداول يومي ${(stock.adv_30d / 1_000_000).toFixed(1)} مليون ج.م وأيام خروج ${trap.exit_days} يوم (P/E ${stock.pe}x · ROE ${stock.roe}%).`,
      metrics: [
        { label_ar: 'السعر المرجعي', value: `${stock.price.toFixed(2)} ج.م`, source_fact_id: priceFact },
        { label_ar: 'متوسط التداول اليومي', value: `${(stock.adv_30d / 1_000_000).toFixed(1)}M`, source_fact_id: advFact },
        { label_ar: 'مؤشر القوة RSI 14', value: `${stock.rsi_14}`, source_fact_id: rsiFact },
      ],
      cited_fact_ids: cited,
      usage_guide,
      disclaimer_ar: SHORT_DISCLAIMER_AR,
    };
  }

  if (agent.group_key === 'decision' || agent.number === 58 || agent.number === 61) {
    if (agent.number === 15 || agent.number === 58) {
      const bt = runPointInTimeBacktest(stock.bars, as_of, config, portfolioSize);
      return {
        agent,
        symbol: stock.symbol,
        as_of,
        headline_ar: `اختبار #${agent.number} التاريخي (Point-in-Time) لسهم ${stock.symbol}`,
        summary_ar: bt.ok
          ? `تم فحص السلسلة التاريخية دون أي تسريب مستقبلي (Anti-Lookahead): صافي العائد ${bt.net_return_pct}% على ${bt.trades_count} صفقات بأقصى تراجع ${bt.max_drawdown_pct}%.`
          : `فشل التحقق الزمني: ${bt.error_ar}`,
        verdict_ar: bt.disclaimer_ar,
        metrics: [
          { label_ar: 'صافي العائد بعد العمولات', value: `${bt.net_return_pct}%`, source_fact_id: priceFact },
          { label_ar: 'أقصى تراجع تاريخي', value: `${bt.max_drawdown_pct}%`, source_fact_id: priceFact },
          { label_ar: 'نسبة الصفقات الرابحة', value: `${bt.win_rate_pct}%`, source_fact_id: advFact },
        ],
        cited_fact_ids: cited,
        usage_guide,
        disclaimer_ar: SHORT_DISCLAIMER_AR,
      };
    }
    const stopPrice = Number((stock.price * 0.95).toFixed(2));
    const maxRiskEgp = Math.round(portfolioSize * ((config.risk_per_trade_standard_pct ?? 1.5) / 100));
    const sharesAllowed = Math.max(1, Math.floor(maxRiskEgp / Math.max(0.1, stock.price - stopPrice)));
    return {
      agent,
      symbol: stock.symbol,
      as_of,
      headline_ar: `تقييم #${agent.number} (${agent.name_ar}) لمركز على ${stock.symbol}`,
      summary_ar: `بافتراض محفظة ${portfolioSize.toLocaleString('en-US')} ج.م ووقف خسارة مقترح عند ${stopPrice} ج.م، الحد الأقصى للكمية داخل قاعدة المخاطر (${config.risk_per_trade_standard_pct}%) هو ${sharesAllowed} سهم.`,
      verdict_ar:
        trap.exit_days > config.liquidity_max_exit_days
          ? `تحذير سيولة: الخروج قد يستغرق ${trap.exit_days} يوم تداول.`
          : 'المركز يقع داخل نطاق السيولة وسقف المخاطر المنصوص عليهما في الإعدادات المعتمدة.',
      metrics: [
        { label_ar: 'سعر الفحص', value: `${stock.price.toFixed(2)} ج.م`, source_fact_id: priceFact },
        { label_ar: 'وقف الخسارة المرجعي (-5%)', value: `${stopPrice} ج.م`, source_fact_id: priceFact },
        { label_ar: 'الكمية داخل حد المخاطرة', value: `${sharesAllowed} سهم`, source_fact_id: advFact },
      ],
      cited_fact_ids: cited,
      usage_guide,
      disclaimer_ar: SHORT_DISCLAIMER_AR,
    };
  }

  if (agent.group_key === 'crypto_derived_egx' || agent.number === 68) {
    return {
      agent,
      symbol: stock.symbol,
      as_of,
      headline_ar: `فحص #${agent.number} (${agent.name_ar}) — أسهم EGX فقط`,
      summary_ar: `سهم ${stock.symbol} سجل مؤشر فخ ${trap.total}/100 (${trap.level === 'safe' ? 'آمن نسبياً' : trap.level === 'caution' ? 'يتطلب حذراً' : 'مرتفع الخطورة'}) مع أسهم حرة ${stock.free_float_pct}% وتركّز ملكية ${stock.ownership_concentration_pct}%.`,
      verdict_ar:
        trap.level === 'high_risk'
          ? 'تحذير قوي: ارتفاع مؤشر الفخ يوجب الامتناع أو تقليص الحجم تماماً.'
          : 'لا توجد إشارة تلاعب حرجة حالياً وفق قواعد السيولة والإفصاح المسجلة.',
      metrics: [
        { label_ar: 'مؤشر فخ السهم', value: `${trap.total} / 100`, source_fact_id: advFact },
        { label_ar: 'نسبة الأسهم الحرة', value: `${stock.free_float_pct}%`, source_fact_id: advFact },
        { label_ar: 'أيام الخروج المقدرة', value: `${trap.exit_days} يوم`, source_fact_id: advFact },
      ],
      cited_fact_ids: cited,
      usage_guide,
      disclaimer_ar: SHORT_DISCLAIMER_AR,
    };
  }

  if (agent.number === 28 || agent.number === 29 || agent.group_key === 'brokerage') {
    const estRoundTripPct = 0.65;
    const breakevenPrice = Number((stock.price * (1 + estRoundTripPct / 100)).toFixed(2));
    return {
      agent,
      symbol: stock.symbol,
      as_of,
      headline_ar: `حساب التكاليف والوساطة #${agent.number}: ${agent.name_ar} (${stock.symbol})`,
      summary_ar: `عند سعر ${stock.price.toFixed(2)} ج.م وبافتراض تكلفة دخول وخروج مجمعة ~${estRoundTripPct}% (عمولة الوسيط + رسوم البورصة والرقابة والمقاصة — TO VERIFY)، نقطة التعادل الحقيقية للسهم هي ${breakevenPrice} ج.م.`,
      verdict_ar: 'تذكير: نعتمد جدول رسوم الوسطاء الموثق (Verified) أو نُظهر TO_COLLECT للبنود غير المؤكدة دون تخمين.',
      metrics: [
        { label_ar: 'سعر السهم الحالي', value: `${stock.price.toFixed(2)} ج.م`, source_fact_id: priceFact },
        { label_ar: 'نقطة التعادل التقديرية', value: `${breakevenPrice} ج.م`, source_fact_id: priceFact },
        { label_ar: 'السبريد (اتساع العرض/الطلب)', value: `${stock.spread_bps} نقطة أساس`, source_fact_id: advFact },
      ],
      cited_fact_ids: cited,
      usage_guide,
      disclaimer_ar: SHORT_DISCLAIMER_AR,
    };
  }

  // Unified factual report for Interaction, Governance, Safety, Unique, Advanced, Global, Second Inquiry
  const modeStatus = traderState?.halted
    ? 'حساب المضارب في وضع إيقاف وقائي (HALT) لحد الخسارة'
    : `وضع التشغيل النشط: ${traderState?.active_mode === 'advisor' ? 'المستشار' : 'مدير المحفظة'} (ثبات انفعالي: ${100 - (traderState?.tilt_score ?? 15)}%)`;

  return {
    agent,
    symbol: stock.symbol,
    as_of,
    headline_ar: `تشغيل #${agent.number}: ${agent.name_ar} — ${stock.symbol}`,
    summary_ar: `${agent.output_ar}. قراءة مباشرة من الأنطولوجيا (${agent.reads_ar}) لصالح مخرج: ${agent.writes_ar}.`,
    verdict_ar: `${modeStatus} · مسار الامتثال: ${config.licence_path} · حالة بيانات ${stock.symbol}: ${stock.quality === 'valid' ? 'سليمة' : 'تتطلب احترازاً'}.`,
    metrics: [
      { label_ar: 'آخر سعر موثق', value: `${stock.price.toFixed(2)} ج.م`, source_fact_id: priceFact },
      { label_ar: 'التغير اليومي', value: `${stock.change_1d_pct >= 0 ? '+' : ''}${stock.change_1d_pct.toFixed(2)}%`, source_fact_id: priceFact },
      { label_ar: 'دقة المعايرة التاريخية للوكيل', value: `${Math.round(agent.calibration_hit_rate * 100)}%`, source_fact_id: rsiFact },
    ],
    cited_fact_ids: cited,
    usage_guide,
    disclaimer_ar: SHORT_DISCLAIMER_AR,
  };
}
