import assert from 'node:assert/strict';
import test from 'node:test';
import {
  ALL_84_AGENTS,
  executeAgentAnalysis,
  isAgentUnlockedForTier,
  SUBSCRIPTION_PLANS,
} from './agentsCatalog';
import { compileHardConstraints, detectAgentConflicts } from './constraints';
import {
  calculateStockQualityScore,
  calculateTiltScore,
  runPointInTimeBacktest,
} from './deterministicServices';
import { INITIAL_CONFIG, SHORT_DISCLAIMER_AR } from './marketPack';
import { runAdvicePipeline } from './pipeline';
import { buildSeedDataset } from './seed';
import { Claim, EvidenceRef, Fact, Source } from './types';
import { checkComplianceCopy, queryFactsAsOf, validateClaim } from './validators';

test('Phase 1: inserting a claim with empty evidence fails', () => {
  const result = validateClaim({
    agent: 'liquidity',
    subject: 'Stock:COMI',
    predicate: 'exit_days',
    value: 1.5,
    interval: [1.0, 2.0],
    confidence: 0.8,
    evidence: [],
    valid_from: '2026-11-25T10:00:00.000Z',
    valid_to: '2026-11-25T15:00:00.000Z',
    known_at: '2026-11-25T10:01:00.000Z',
  });
  assert.equal(result.ok, false);
  assert.ok(result.errors.includes('empty_evidence'));
});

test('Phase 1: querying facts "as of T" never returns rows with known_at > T', () => {
  const facts: Fact[] = [
    {
      id: 'f1',
      entity_id: 'Stock:COMI',
      predicate: 'last_price',
      value: 80,
      kind: 'observed',
      source_id: 'src_demo_feed',
      quality: 'valid',
      valid_from: '2026-11-20T10:00:00.000Z',
      valid_to: null,
      known_at: '2026-11-20T10:01:00.000Z',
    },
    {
      id: 'f2',
      entity_id: 'Stock:COMI',
      predicate: 'last_price',
      value: 84.5,
      kind: 'observed',
      source_id: 'src_demo_feed',
      quality: 'valid',
      valid_from: '2026-11-25T10:00:00.000Z',
      valid_to: null,
      known_at: '2026-11-25T10:01:00.000Z',
      supersedes: 'f1',
    },
  ];

  const asOfPast = queryFactsAsOf(facts, '2026-11-22T12:00:00.000Z', 'Stock:COMI');
  assert.equal(asOfPast.length, 1);
  assert.equal(asOfPast[0].id, 'f1');

  const asOfNow = queryFactsAsOf(facts, '2026-11-25T12:00:00.000Z', 'Stock:COMI');
  assert.equal(asOfNow.length, 1);
  assert.equal(asOfNow[0].id, 'f2');
});

test('Phase 1: a stock with stale/suspect/halted data yields no quality score', () => {
  const seed = buildSeedDataset();
  const asOf = '2026-11-25T12:00:00.000Z';

  const haltedStock = seed.stocks.find((s) => s.symbol === 'DHLT')!;
  const haltedQ = calculateStockQualityScore(haltedStock, seed.facts, asOf, INITIAL_CONFIG);
  assert.equal(haltedQ.blocked, true);
  assert.equal(haltedQ.total, null);

  const staleStock = seed.stocks.find((s) => s.symbol === 'DSTL')!;
  const staleQ = calculateStockQualityScore(staleStock, seed.facts, asOf, INITIAL_CONFIG);
  assert.equal(staleQ.blocked, true);
  assert.equal(staleQ.total, null);
});

test('Phase 2: a plan that breaches concentration cap is vetoed from option space', () => {
  const seed = buildSeedDataset();
  const comi = seed.stocks.find((s) => s.symbol === 'COMI')!;
  const profile = seed.riskProfiles.find((p) => p.trader_id === 'trader_main')!;
  const state = seed.traderStates.find((s) => s.trader_id === 'trader_main')!;
  const positions = seed.positions.filter((p) => p.trader_id === 'trader_main');

  const space = compileHardConstraints({
    stock: comi,
    profile,
    traderState: state,
    positions,
    edges: seed.edges,
    config: INITIAL_CONFIG,
    killSwitches: { global_pause_advice: false, crisis_mode_manual: false, disabled_agents: [], blocked_symbols: [] },
    marketIndexDropPct: 0.4,
    haltedTopStocksCount: 1,
    requestedSizePct: 45, // Exceeds 25% standard cap & 40% absolute max
  });

  assert.equal(space.empty, true);
  assert.ok(space.verdicts.some((v) => v.id === 'concentration_cap' && !v.passed));
});

test('Phase 2: loss limit hit sets HALT and blocks new signals', async () => {
  const seed = buildSeedDataset();
  const tmgh = seed.stocks.find((s) => s.symbol === 'TMGH')!;
  const profile = seed.riskProfiles.find((p) => p.trader_id === 'trader_revenge_tilt')!;
  const state = seed.traderStates.find((s) => s.trader_id === 'trader_revenge_tilt')!;
  const sourcesMap = new Map<string, Source>(seed.sources.map((s) => [s.id, s]));

  const advice = await runAdvicePipeline({
    trader_id: 'trader_revenge_tilt',
    symbol: 'TMGH',
    as_of: '2026-11-25T12:00:00.000Z',
    stock: tmgh,
    facts: seed.facts,
    sources: sourcesMap,
    edges: seed.edges,
    profile,
    traderState: state,
    positions: [],
    config: INITIAL_CONFIG,
    killSwitches: { global_pause_advice: false, crisis_mode_manual: false, disabled_agents: [], blocked_symbols: [] },
    agentWeights: { fundamental: 1, technical: 1, liquidity: 1, macro: 1 },
    prevSealHash: 'GENESIS',
    marketIndexDropPct: 0.2,
    haltedTopStocksCount: 0,
  });

  assert.equal(advice.kind, 'calm_down');
  assert.equal(advice.status, 'abstained');
  assert.ok(advice.constraints_checked.some((v) => v.id === 'personal_loss_limit' && v.action === 'halt'));
});

test('Phase 2: backtest with future data injected fails the as-of check', () => {
  const seed = buildSeedDataset();
  const comi = seed.stocks.find((s) => s.symbol === 'COMI')!;
  const futureInjected = comi.bars.map((b, i) =>
    i === 50 ? { ...b, known_at: '2026-12-31T00:00:00.000Z' } : b
  );
  const res = runPointInTimeBacktest(futureInjected, '2026-11-25T12:00:00.000Z', INITIAL_CONFIG);
  assert.equal(res.ok, false);
  assert.ok(res.error_ar?.includes('As-Of'));
});

test('Phase 2: two opposing claims produce a conflict flag and lower agreement', () => {
  const c1: Claim = {
    id: 'c1',
    agent: 'fundamental',
    subject: 'Stock:COMI',
    predicate: 'fundamental_score',
    value: 88,
    interval: [80, 95],
    confidence: 0.85,
    calibration_version: 'v1',
    model_version: 'v1',
    evidence: ['f1'],
    valid_from: '2026-11-25T10:00:00.000Z',
    valid_to: '2026-11-25T15:00:00.000Z',
    known_at: '2026-11-25T10:00:00.000Z',
    data_age_seconds: 120,
    display_licence: 'displayable',
  };
  const c2: Claim = {
    ...c1,
    id: 'c2',
    agent: 'technical',
    predicate: 'technical_score',
    value: 30,
    interval: [22, 38],
    confidence: 0.8,
  };
  const res = detectAgentConflicts([c1, c2]);
  assert.equal(res.hasConflict, true);
  assert.ok(res.conflictFlags.length >= 1);
  assert.ok(res.agreementScore < 0.75);
});

test('Phase 3: advice text containing an untraced number or banned phrase is blocked', () => {
  const numbers: Record<string, EvidenceRef> = {
    entry: {
      fact_id: 'f1',
      label_ar: 'سعر الدخول',
      value: 58.2,
      source_name: 'DEMO',
      valid_from: '2026-11-25T10:00:00.000Z',
      known_at: '2026-11-25T10:00:00.000Z',
      display_licence: 'displayable',
    },
  };

  const untraced = checkComplianceCopy('دخول عند 58.2 وهدف 99.9 مضمون.', numbers, {
    maxSentences: 3,
    requireDisclaimer: true,
    disclaimerText: SHORT_DISCLAIMER_AR,
  });
  assert.equal(untraced.ok, false);
  assert.ok(untraced.errors.some((e) => e.startsWith('untraced_number:99.9')));
  assert.ok(untraced.errors.some((e) => e.startsWith('banned_phrase')));
});

test('Phase 3: stale data returns abstain, crisis state converts advice to calm_down', async () => {
  const seed = buildSeedDataset();
  const stale = seed.stocks.find((s) => s.symbol === 'DSTL')!;
  const tmgh = seed.stocks.find((s) => s.symbol === 'TMGH')!;
  const profile = seed.riskProfiles.find((p) => p.trader_id === 'trader_disciplined_pro')!;
  const state = seed.traderStates.find((s) => s.trader_id === 'trader_disciplined_pro')!;
  const sourcesMap = new Map<string, Source>(seed.sources.map((s) => [s.id, s]));

  const staleAdvice = await runAdvicePipeline({
    trader_id: 'trader_disciplined_pro',
    symbol: 'DSTL',
    as_of: '2026-11-25T12:00:00.000Z',
    stock: stale,
    facts: seed.facts,
    sources: sourcesMap,
    edges: seed.edges,
    profile,
    traderState: state,
    positions: [],
    config: INITIAL_CONFIG,
    killSwitches: { global_pause_advice: false, crisis_mode_manual: false, disabled_agents: [], blocked_symbols: [] },
    agentWeights: { fundamental: 1, technical: 1, liquidity: 1, macro: 1 },
    prevSealHash: 'GENESIS',
    marketIndexDropPct: 0.1,
    haltedTopStocksCount: 0,
  });
  assert.equal(staleAdvice.kind, 'abstain');
  assert.equal(staleAdvice.status, 'abstained');

  const crisisAdvice = await runAdvicePipeline({
    trader_id: 'trader_disciplined_pro',
    symbol: 'TMGH',
    as_of: '2026-11-25T12:00:00.000Z',
    stock: tmgh,
    facts: seed.facts,
    sources: sourcesMap,
    edges: seed.edges,
    profile,
    traderState: state,
    positions: [],
    config: INITIAL_CONFIG,
    killSwitches: { global_pause_advice: false, crisis_mode_manual: true, disabled_agents: [], blocked_symbols: [] },
    agentWeights: { fundamental: 1, technical: 1, liquidity: 1, macro: 1 },
    prevSealHash: 'GENESIS',
    marketIndexDropPct: -3.5,
    haltedTopStocksCount: 0,
  });
  assert.equal(crisisAdvice.kind, 'calm_down');
});

test('Phase 3: tilt detection triggers above threshold', () => {
  const nowMs = Date.parse('2026-11-25T12:00:00.000Z');
  const trades = [
    {
      id: 't1',
      trader_id: 'x',
      symbol: 'COMI',
      side: 'sell' as const,
      qty: 100,
      entry_price: 80,
      price: 78,
      fees_egp: 20,
      net_pnl_egp: -220,
      net_return_pct: -2.7,
      rule_break_cost_egp: 100,
      executed_at: '2026-11-25T11:50:00.000Z',
      deviation_tags: ['revenge' as const],
      stop_adhered: false,
      plan_adhered: false,
      size_adhered: true,
      journal_completed: false,
    },
    {
      id: 't2',
      trader_id: 'x',
      symbol: 'COMI',
      side: 'sell' as const,
      qty: 100,
      entry_price: 82,
      price: 80,
      fees_egp: 20,
      net_pnl_egp: -220,
      net_return_pct: -2.6,
      rule_break_cost_egp: 100,
      executed_at: '2026-11-25T11:30:00.000Z',
      deviation_tags: ['fomo' as const],
      stop_adhered: false,
      plan_adhered: false,
      size_adhered: true,
      journal_completed: false,
    },
    {
      id: 't3',
      trader_id: 'x',
      symbol: 'COMI',
      side: 'sell' as const,
      qty: 100,
      entry_price: 84,
      price: 82,
      fees_egp: 20,
      net_pnl_egp: -220,
      net_return_pct: -2.5,
      rule_break_cost_egp: 0,
      executed_at: '2026-11-25T11:10:00.000Z',
      deviation_tags: ['none' as const],
      stop_adhered: true,
      plan_adhered: true,
      size_adhered: true,
      journal_completed: true,
    },
  ];

  const tilt = calculateTiltScore(trades, 'tense', null, nowMs);
  assert.ok(tilt >= INITIAL_CONFIG.tilt_threshold, `Expected tilt >= 60, got ${tilt}`);
});

test('Phase 4: full 84-agent catalog contains unique numbers 1..84 across 11 groups', () => {
  assert.equal(ALL_84_AGENTS.length, 84);
  const numbers = new Set(ALL_84_AGENTS.map((a) => a.number));
  const ids = new Set(ALL_84_AGENTS.map((a) => a.id));
  assert.equal(numbers.size, 84);
  assert.equal(ids.size, 84);
  for (let n = 1; n <= 84; n++) {
    assert.ok(numbers.has(n), `Missing agent number ${n}`);
  }
});

test('Phase 4: subscription plans include Free/Plus/Pro/B2B pricing and accurate tier gating', () => {
  assert.equal(SUBSCRIPTION_PLANS.length, 4);
  const free = SUBSCRIPTION_PLANS.find((p) => p.id === 'free')!;
  const plus = SUBSCRIPTION_PLANS.find((p) => p.id === 'plus')!;
  const pro = SUBSCRIPTION_PLANS.find((p) => p.id === 'pro')!;
  const b2b = SUBSCRIPTION_PLANS.find((p) => p.id === 'b2b')!;

  assert.equal(free.monthly_egp, 0);
  assert.ok(plus.monthly_egp > 0 && plus.annual_egp < plus.monthly_egp * 12);
  assert.ok(pro.monthly_egp > plus.monthly_egp);
  assert.ok(b2b.monthly_egp > pro.monthly_egp);
  assert.equal(isAgentUnlockedForTier('free', 'free'), true);
  assert.equal(isAgentUnlockedForTier('pro', 'plus'), false);
  assert.equal(isAgentUnlockedForTier('pro', 'pro'), true);
  assert.equal(isAgentUnlockedForTier('b2b', 'b2b'), true);
});

test('Phase 4: executing all 84 agents on COMI returns Fact-cited output and structured usage_guide', () => {
  const seed = buildSeedDataset();
  const comi = seed.stocks.find((s) => s.symbol === 'COMI')!;
  for (const ag of ALL_84_AGENTS) {
    const res = executeAgentAnalysis({
      agent: ag,
      stock: comi,
      facts: seed.facts,
      config: INITIAL_CONFIG,
      profile: seed.riskProfiles[0],
      traderState: seed.traderStates[0],
      as_of: '2026-11-25T12:00:00.000Z',
    });
    assert.equal(res.symbol, 'COMI');
    assert.ok(res.cited_fact_ids.length > 0, `Agent #${ag.number} missing cited_fact_ids`);
    assert.ok(res.metrics.every((m) => Boolean(m.source_fact_id)), `Agent #${ag.number} missing metric Fact ID`);
    assert.ok(res.usage_guide.purpose_ar.length > 10, `Agent #${ag.number} missing usage guide purpose`);
    assert.ok(res.usage_guide.steps_ar.length >= 3, `Agent #${ag.number} missing 3 usage steps`);
  }
});
