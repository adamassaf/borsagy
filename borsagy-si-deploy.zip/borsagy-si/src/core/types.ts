export type DisplayLicence = 'displayable' | 'internal_only';
export type FactQuality = 'valid' | 'suspect' | 'halted' | 'suspended';
export type FactKind = 'observed' | 'computed' | 'extracted';
export type EntityType =
  | 'stock'
  | 'company'
  | 'sector'
  | 'group'
  | 'broker'
  | 'macro'
  | 'asset';

export type TraderMode = 'manager' | 'advisor' | 'hybrid';
export type ActiveMode = 'manager' | 'advisor';
export type TraderMood = 'calm' | 'tense' | 'excited';
export type ExperienceLevel = 'beginner' | 'active' | 'advanced';
export type LicencePath = 'PATH_A' | 'PATH_B' | 'PATH_C';

export interface Source {
  id: string;
  name: string;
  kind: 'exchange' | 'vendor' | 'disclosure' | 'broker_official' | 'press' | 'computed' | 'demo';
  licence: DisplayLicence;
  licence_valid_to: string;
  url?: string;
}

export interface Entity {
  id: string;
  type: EntityType;
  canonical_name_ar: string;
  canonical_name_en: string;
  symbol?: string;
  attrs: Record<string, unknown>;
}

export interface Fact {
  id: string;
  entity_id: string;
  predicate: string;
  value: number | string | boolean | Record<string, unknown>;
  kind: FactKind;
  source_id: string;
  quality: FactQuality;
  valid_from: string; // ISO timestamp
  valid_to: string | null; // ISO timestamp or null if ongoing
  known_at: string; // ISO timestamp (bitemporal knowledge time)
  supersedes?: string | null;
}

export interface Edge {
  id: string;
  src: string;
  rel:
    | 'belongs_to'
    | 'owned_by_group'
    | 'affected_by'
    | 'holds'
    | 'set_limit'
    | 'executed_with_plan'
    | 'supports'
    | 'weakens'
    | 'sourced_from'
    | 'resulted_in';
  dst: string;
  props: Record<string, unknown>;
  valid_from: string;
  valid_to: string | null;
  known_at: string;
  evidence: string[];
}

export interface Claim {
  id: string;
  agent: string;
  subject: string; // Entity ID e.g. Stock:COMI
  predicate: string;
  value: number | string | Record<string, unknown>;
  interval: [number, number] | null;
  confidence: number; // 0..1
  calibration_version: string;
  model_version: string;
  evidence: string[]; // Fact IDs (non-empty)
  valid_from: string;
  valid_to: string;
  known_at: string;
  data_age_seconds: number;
  display_licence: DisplayLicence;
  invalidated_at?: string | null;
}

export interface EvidenceRef {
  fact_id: string;
  label_ar: string;
  value: number | string;
  source_name: string;
  valid_from: string;
  known_at: string;
  display_licence: DisplayLicence;
}

export type AdviceKind =
  | 'plan'
  | 'signal'
  | 'abstain'
  | 'warn'
  | 'calm_down'
  | 'alternative'
  | 'alert'
  | 'report';

export interface PlanDraft {
  symbol: string;
  stock_name_ar: string;
  entry: number;
  stop: number;
  targets: number[];
  size_pct: number;
  size_egp: number;
  qty: number;
  max_loss_egp: number;
  exit_days: number;
}

export interface Advice {
  id: string;
  kind: AdviceKind;
  trader_id: string;
  symbol?: string;
  mode: ActiveMode;
  text_ar: string; // Max 3 sentences, Egyptian dialect
  numbers: Record<string, EvidenceRef>;
  confidence: number;
  agent_agreement: number;
  data_age_seconds: number;
  claim_ids: string[];
  claims: Claim[];
  plan_draft?: PlanDraft | null;
  red_team_ar?: string;
  conflict_flags: string[];
  constraints_checked: ConstraintVerdict[];
  disclaimer_ar: string;
  as_of: string;
  sealed_at: string;
  seal_hash: string;
  prev_seal_hash: string;
  status: 'active' | 'approved' | 'dismissed' | 'abstained' | 'blocked';
}

export interface ConstraintVerdict {
  id: string;
  kind: 'hard' | 'soft';
  owner: 'risk' | 'compliance' | 'data' | 'licence' | 'crisis';
  passed: boolean;
  action: 'allow' | 'cap' | 'veto' | 'halt' | 'calm_down' | 'warn';
  reason_ar: string;
  detail?: Record<string, unknown>;
}

export type SubscriptionTierId = 'free' | 'plus' | 'pro' | 'b2b';
export type BillingCycle = 'monthly' | 'annual';

export type AgentGroupKey =
  | 'data'
  | 'decision'
  | 'interaction'
  | 'governance'
  | 'unique'
  | 'safety'
  | 'advanced'
  | 'global'
  | 'crypto_derived_egx'
  | 'second_inquiry'
  | 'brokerage';

export interface AgentDefinition {
  id: string;
  number: number; // 1..84
  name_ar: string;
  name_en: string;
  group_key: AgentGroupKey;
  group_ar: string;
  reads_ar: string;
  writes_ar: string;
  output_ar: string;
  tier: SubscriptionTierId;
  v4_consolidated_to: string;
  mode: 'ai_judgment' | 'deterministic' | 'hybrid' | 'api_service';
  enabled: boolean;
  calibration_hit_rate: number;
}

export interface SubscriptionPlan {
  id: SubscriptionTierId;
  name_ar: string;
  name_en: string;
  tagline_ar: string;
  monthly_egp: number;
  annual_egp: number;
  billing_note_ar: string;
  badge_ar?: string;
  data_feed_ar: string;
  agent_limit_label_ar: string;
  highlights_ar: string[];
  compliance_note_ar: string;
  recommended?: boolean;
}

export interface LiveFeedStatus {
  synced: boolean;
  last_sync_at: string | null;
  provider: string;
  live_symbols_count: number;
  total_live_eligible: number;
  usd_egp: number | null;
  gold_24k_egp: number | null;
  gold_21k_egp: number | null;
  egx_index_sample_change_pct: number | null;
  errors: string[];
}

export interface Trader {
  id: string;
  handle: string;
  anonymous: boolean;
  created_at: string;
  dialect: 'egyptian' | 'gulf' | 'levantine';
  numerals: 'western' | 'arabic_indic';
  low_bandwidth: boolean;
  quiet_hours: { start: string; end: string };
  daily_alert_budget: number;
  alerts_sent_today: number;
  trusted_observer?: { name: string; contact: string; consented: boolean } | null;
  subscription_tier?: SubscriptionTierId;
  billing_cycle?: BillingCycle;
}

export interface RiskProfile {
  trader_id: string;
  experience: ExperienceLevel;
  goal: 'income' | 'growth' | 'speculation' | 'learning';
  horizon: 'days' | 'weeks' | 'months' | 'years';
  loss_tolerance_pct: number;
  portfolio_size_egp: number;
  daily_loss_limit_pct: number;
  weekly_loss_limit_pct: number;
  single_stock_cap_pct: number;
  sector_cap_pct: number;
  money_not_to_risk_ack: boolean;
  borrowed_money_flag: boolean;
  max_affordable_loss_egp: number;
  preferred_sharia_only: boolean;
}

export interface TraderState {
  trader_id: string;
  as_of: string;
  mode: TraderMode;
  active_mode: ActiveMode;
  mood: TraderMood;
  tilt_score: number; // 0..100
  discipline_score: number; // 0..1
  loss_streak: number;
  day_pnl_pct: number;
  week_pnl_pct: number;
  halted: boolean;
  halt_until?: string | null;
  upgrade_eligible: boolean;
  license_level: 1 | 2 | 3;
}

export interface Position {
  id: string;
  trader_id: string;
  symbol: string;
  stock_name_ar: string;
  sector_id: string;
  owner_group_id: string;
  qty: number;
  avg_price: number;
  current_price: number;
  opened_at: string;
  closed_at?: string | null;
  plan_id?: string | null;
}

export interface Plan {
  id: string;
  trader_id: string;
  symbol: string;
  reason: string;
  entry: number;
  size_pct: number;
  stop: number;
  targets: number[];
  worst_case: string;
  mood: TraderMood;
  signed_at: string;
  advice_id?: string;
}

export interface Trade {
  id: string;
  trader_id: string;
  plan_id?: string | null;
  advice_id?: string | null;
  symbol: string;
  side: 'buy' | 'sell';
  qty: number;
  entry_price: number;
  price: number;
  fees_egp: number;
  net_pnl_egp: number;
  net_return_pct: number;
  rule_break_cost_egp: number;
  executed_at: string;
  closed_at?: string | null;
  cause?: 'market' | 'analysis' | 'execution' | 'luck';
  deviation_tags: Array<'early_exit' | 'no_stop' | 'oversize' | 'revenge' | 'fomo' | 'none'>;
  stop_adhered: boolean;
  plan_adhered: boolean;
  size_adhered: boolean;
  journal_completed: boolean;
}

export interface Outcome {
  advice_id: string;
  resolved_at: string;
  symbol: string;
  kind: AdviceKind;
  result: 'win' | 'loss' | 'abstained_correctly' | 'flat';
  net_return_pct: number;
  cause: 'market' | 'analysis' | 'execution' | 'luck';
  predicted_confidence: number;
}

export interface CalibrationRow {
  agent: string;
  bucket: number; // 0..9 (0-10%, 10-20%...)
  n: number;
  hit_rate: number;
  weight: number;
  as_of: string;
}

export interface PriceBar {
  symbol: string;
  ts: string;
  o: number;
  h: number;
  l: number;
  c: number;
  v: number;
  known_at: string;
  source_id: string;
  halted?: boolean;
}

export interface StockSummary {
  id: string;
  symbol: string;
  name_ar: string;
  name_en: string;
  sector_id: string;
  sector_ar: string;
  owner_group_id: string;
  owner_group_ar: string;
  is_demo: boolean;
  price: number;
  prev_close: number;
  change_1h_pct: number;
  change_1d_pct: number;
  change_1w_pct: number;
  change_1m_pct: number;
  volume_today: number;
  adv_30d: number;
  free_float_pct: number;
  ownership_concentration_pct: number;
  pe: number;
  pb: number;
  roe: number;
  debt_to_equity: number;
  dividend_yield_pct: number;
  non_halal_revenue_pct: number;
  sharia_compliant: boolean;
  rsi_14: number;
  macd_signal: 'bullish' | 'neutral' | 'bearish';
  spread_bps: number;
  halt_count_90d: number;
  unexplained_spike: boolean;
  disclosure_weakness: boolean;
  quality: FactQuality;
  data_age_seconds: number;
  last_updated: string;
  business_summary_ar: string;
  revenue_sources_ar: string;
  key_risks_ar: string;
  disclosures: Array<{
    id: string;
    date: string;
    title_ar: string;
    summary_ar: string;
    direction: 'positive' | 'negative' | 'neutral';
    type: 'dividend' | 'capital_increase' | 'results' | 'ownership_change' | 'halt';
  }>;
  bars: PriceBar[];
}

export interface TrapScoreBreakdown {
  total: number; // 0..100
  level: 'safe' | 'caution' | 'high_risk';
  exit_days: number;
  factors: Array<{
    key: string;
    label_ar: string;
    score: number;
    max: number;
    detail_ar: string;
  }>;
}

export interface QualityScoreBreakdown {
  blocked: boolean;
  block_reason_ar?: string;
  total: number | null;
  fundamental: number | null;
  technical: number | null;
  liquidity: number | null;
  data_age_seconds: number;
  confidence: number;
  evidence_ids: string[];
}

export interface VersionedConfig {
  version: number;
  updated_at: string;
  updated_by: string;
  licence_path: LicencePath;
  risk_per_trade_beginner_pct: number;
  risk_per_trade_standard_pct: number;
  risk_per_trade_advanced_pct: number;
  risk_per_trade_hard_max_pct: number;
  single_stock_cap_beginner_pct: number;
  single_stock_cap_standard_pct: number;
  single_stock_cap_advanced_pct: number;
  single_stock_cap_absolute_pct: number;
  sector_cap_beginner_pct: number;
  sector_cap_standard_pct: number;
  sector_cap_advanced_pct: number;
  daily_loss_limit_default_pct: number;
  weekly_loss_limit_default_pct: number;
  daily_loss_cap_beginner_pct: number;
  weekly_loss_cap_beginner_pct: number;
  cool_off_hours: number;
  cool_off_day_loss_trigger_pct: number;
  liquidity_max_adv_pct: number;
  liquidity_max_exit_days: number;
  liquidity_block_exit_days: number;
  age_max_intraday_seconds: number;
  abstain_min_confidence: number;
  abstain_min_agreement: number;
  abstain_max_interval_ratio: number;
  tilt_threshold: number;
  discipline_upgrade_threshold: number;
  discipline_min_trades: number;
  crisis_index_drop_pct: number;
  crisis_halted_top_stocks: number;
  notification_budget_per_day: number;
  trap_red_threshold: number;
  crowding_min_active_users: number;
  crowding_min_stock_holders: number;
}

export interface KillSwitches {
  global_pause_advice: boolean;
  crisis_mode_manual: boolean;
  disabled_agents: string[];
  blocked_symbols: string[];
}

export interface BrokerFeeRow {
  id: string;
  broker_id: string;
  fee_type: 'commission' | 'min_per_order' | 'account_open' | 'custody' | 'margin_rate' | 'subscription';
  value: number | null; // null when TO_COLLECT
  unit: 'pct' | 'egp' | 'pct_per_year' | 'orders_free';
  status: 'verified' | 'to_collect';
  conditions_ar: string;
  source_url: string;
  source_kind: 'official_price_list' | 'call_confirmed' | 'press' | 'unverified';
  verified_on: string;
}

export interface BrokerInfo {
  id: string;
  name_ar: string;
  name_en: string;
  rank_q3_2026: number;
  traded_value_bn_egp: number;
  market_share_pct: number;
  avg_ticket_egp: number | null;
  share_period: string;
  share_source: string;
  best_for_ar: string;
  research_available: boolean;
  margin_supported: boolean;
  app_quality_note_ar: string;
  referral_disclosure_ar: string;
  fees: BrokerFeeRow[];
}

export interface HumanReviewItem {
  id: string;
  created_at: string;
  kind: 'disclosure_disagreement' | 'broker_fee_verify' | 'compliance_borderline' | 'insider_move_flag';
  subject: string;
  summary_ar: string;
  payload: Record<string, unknown>;
  status: 'pending' | 'approved' | 'rejected';
  reviewed_by?: string;
  reviewed_at?: string;
}

export interface AuditLogEntry {
  id: number;
  actor: string;
  action: string;
  subject: string;
  at: string;
  detail: Record<string, unknown>;
}
