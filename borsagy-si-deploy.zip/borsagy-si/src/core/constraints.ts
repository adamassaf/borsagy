import { calculateTrapScore } from './deterministicServices';
import {
  Claim,
  ConstraintVerdict,
  Edge,
  KillSwitches,
  Position,
  RiskProfile,
  StockSummary,
  TraderState,
  VersionedConfig,
} from './types';

export interface ConstraintContext {
  stock: StockSummary;
  profile: RiskProfile;
  traderState: TraderState;
  positions: Position[];
  edges: Edge[];
  config: VersionedConfig;
  killSwitches: KillSwitches;
  marketIndexDropPct: number;
  haltedTopStocksCount: number;
  requestedSizePct?: number;
  proposedEntry?: number;
  proposedStop?: number;
}

export interface CompiledSpace {
  empty: boolean;
  halted: boolean;
  crisis: boolean;
  licenceBlocked: boolean;
  abstainReasons: string[];
  verdicts: ConstraintVerdict[];
  maxAllowedPct: number;
  maxAllowedEgp: number;
  maxAllowedQty: number;
  hiddenConcentrationFlag: boolean;
  hiddenConcentrationDetailAr?: string;
}

export function compileHardConstraints(ctx: ConstraintContext): CompiledSpace {
  const verdicts: ConstraintVerdict[] = [];
  const abstainReasons: string[] = [];

  const {
    stock,
    profile,
    traderState,
    positions,
    config,
    killSwitches,
    marketIndexDropPct,
    haltedTopStocksCount,
  } = ctx;

  let halted = false;
  let crisis = false;
  let licenceBlocked = false;

  // 0. Kill switches
  if (killSwitches.global_pause_advice) {
    verdicts.push({
      id: 'kill_switch_global',
      kind: 'hard',
      owner: 'compliance',
      passed: false,
      action: 'veto',
      reason_ar: 'تم إيقاف الإشارات مؤقتاً من لوحة الحوكمة والأمان.',
    });
    abstainReasons.push('الإشارات متوقفة مؤقتاً من إدارة المنصة للصيانة أو الحماية.');
  }

  if (killSwitches.blocked_symbols.includes(stock.symbol)) {
    verdicts.push({
      id: 'kill_switch_symbol',
      kind: 'hard',
      owner: 'risk',
      passed: false,
      action: 'veto',
      reason_ar: `تم حظر التوصيات على سهم ${stock.symbol} مؤقتاً للمراجعة.`,
    });
    abstainReasons.push(`السهم ${stock.symbol} موقوف مؤقتاً من لجنة المخاطر.`);
  }

  // 1. Crisis state (manual OR index drop >= 3% OR 5+ top stocks halted)
  if (
    killSwitches.crisis_mode_manual ||
    marketIndexDropPct <= -config.crisis_index_drop_pct ||
    haltedTopStocksCount >= config.crisis_halted_top_stocks
  ) {
    crisis = true;
    verdicts.push({
      id: 'crisis_state',
      kind: 'hard',
      owner: 'crisis',
      passed: false,
      action: 'calm_down',
      reason_ar: `وضع الأزمة مفعّل (تراجع المؤشر ${marketIndexDropPct}% أو إيقاف ${haltedTopStocksCount} أسهم قيادية) — تتحول كل الإشارات لرسالة تهدئة ومراجعة.`,
    });
    abstainReasons.push('السوق في حالة تقلب حاد أو وضع أزمة.');
  }

  // 2. Personal loss limit (day or week)
  const dayLossReached = traderState.day_pnl_pct <= -profile.daily_loss_limit_pct;
  const weekLossReached = traderState.week_pnl_pct <= -profile.weekly_loss_limit_pct;
  if (traderState.halted || dayLossReached || weekLossReached) {
    halted = true;
    verdicts.push({
      id: 'personal_loss_limit',
      kind: 'hard',
      owner: 'risk',
      passed: false,
      action: 'halt',
      reason_ar: dayLossReached
        ? `بلغت حد الخسارة اليومي (${profile.daily_loss_limit_pct}%) — حالة إيقاف إشارات واستراحة ${config.cool_off_hours} ساعة.`
        : `بلغت حد الخسارة الأسبوعي (${profile.weekly_loss_limit_pct}%) — تم تفعيل الاستراحة الإجبارية.`,
    });
    abstainReasons.push('تم بلوغ حد الخسارة الشخصي.');
  }

  // 3. Data quality & staleness
  if (stock.quality === 'suspect' || stock.quality === 'halted' || stock.quality === 'suspended') {
    verdicts.push({
      id: 'data_quality',
      kind: 'hard',
      owner: 'data',
      passed: false,
      action: 'veto',
      reason_ar:
        stock.quality === 'halted'
          ? `السهم ${stock.symbol} موقوف عن التداول حالياً.`
          : `بيانات السهم ${stock.symbol} مشكوك فيها أو غير مؤكدة.`,
    });
    abstainReasons.push(`جودة بيانات ${stock.symbol} لا تسمح بإصدار خطة.`);
  } else if (stock.data_age_seconds > config.age_max_intraday_seconds) {
    verdicts.push({
      id: 'stale_data',
      kind: 'hard',
      owner: 'data',
      passed: false,
      action: 'veto',
      reason_ar: `بيانات السهم متأخرة (${Math.round(stock.data_age_seconds / 60)} دقيقة > الحد المسموح).`,
    });
    abstainReasons.push(`بيانات السهم متأخرة عن الحد المسموح.`);
  } else {
    verdicts.push({
      id: 'data_quality',
      kind: 'hard',
      owner: 'data',
      passed: true,
      action: 'allow',
      reason_ar: 'البيانات صالحة ومحدّثة ضمن النطاق المسموح.',
    });
  }

  // 4. Licence Path Gate (Path A = info/education/discipline only, no personal buy/sell advice)
  if (config.licence_path === 'PATH_A') {
    licenceBlocked = true;
    verdicts.push({
      id: 'licence_path',
      kind: 'hard',
      owner: 'licence',
      passed: false,
      action: 'veto',
      reason_ar:
        'المنصة تعمل حالياً في المسار (أ): معلومات وتعليم وأدوات انضباط فقط دون توصيات شراء أو بيع شخصية لحين استكمال المسار التنظيمي.',
    });
    abstainReasons.push('المسار التنظيمي الحالي مقتصر على المعلومات والتعليم فقط.');
  } else {
    verdicts.push({
      id: 'licence_path',
      kind: 'hard',
      owner: 'licence',
      passed: true,
      action: 'allow',
      reason_ar: `وضع العرض مفعّل (${config.licence_path}) مع سجل أدلة مختوم ومراجعة امتثال.`,
    });
  }

  // 5. Money that must not be risked
  if (profile.borrowed_money_flag || !profile.money_not_to_risk_ack) {
    verdicts.push({
      id: 'money_not_to_risk',
      kind: 'hard',
      owner: 'risk',
      passed: false,
      action: 'warn',
      reason_ar:
        'تم تسجيل أن رأس المال قد يشمل التزامات أو أموالاً مقترضة — لا ننصح بالمضاربة بهذه الأموال.',
    });
    abstainReasons.push('رأس المال يحتوي على أموال لا يجوز المخاطرة بها.');
  } else {
    verdicts.push({
      id: 'money_not_to_risk',
      kind: 'hard',
      owner: 'risk',
      passed: true,
      action: 'allow',
      reason_ar: 'تم تأكيد التداول بأموال قابلة لتحمل المخاطرة.',
    });
  }

  // 6. Concentration cap (Single-stock + Sector + Hidden owner-group concentration)
  const totalPortfolio = Math.max(1, profile.portfolio_size_egp);
  const existingStockEgp = positions
    .filter((p) => !p.closed_at && p.symbol === stock.symbol)
    .reduce((sum, p) => sum + p.qty * p.current_price, 0);
  const existingSectorEgp = positions
    .filter((p) => !p.closed_at && p.sector_id === stock.sector_id)
    .reduce((sum, p) => sum + p.qty * p.current_price, 0);
  const existingGroupEgp = positions
    .filter((p) => !p.closed_at && p.owner_group_id === stock.owner_group_id)
    .reduce((sum, p) => sum + p.qty * p.current_price, 0);

  const singleCapPct = Math.min(profile.single_stock_cap_pct, config.single_stock_cap_absolute_pct);
  const sectorCapPct = profile.sector_cap_pct;

  const currentStockPct = (existingStockEgp / totalPortfolio) * 100;
  const currentSectorPct = (existingSectorEgp / totalPortfolio) * 100;
  const currentGroupPct = (existingGroupEgp / totalPortfolio) * 100;

  const roomStockPct = Math.max(0, singleCapPct - currentStockPct);
  const roomSectorPct = Math.max(0, sectorCapPct - currentSectorPct);
  const roomGroupPct = Math.max(0, sectorCapPct - currentGroupPct);

  const sameGroupCount = positions.filter(
    (p) => !p.closed_at && p.owner_group_id === stock.owner_group_id && p.symbol !== stock.symbol
  ).length;
  const hiddenConcentrationFlag = sameGroupCount >= 1;
  const hiddenConcentrationDetailAr = hiddenConcentrationFlag
    ? `تنويه تنويع وهمي: لديك مركز آخر يتبع نفس المجموعة المالكة (${stock.owner_group_ar})، لذا تم احتساب السقف مجمّعاً.`
    : undefined;

  let maxAllowedPct = Math.min(roomStockPct, roomSectorPct, roomGroupPct);

  if (ctx.requestedSizePct && ctx.requestedSizePct + currentStockPct > singleCapPct) {
    verdicts.push({
      id: 'concentration_cap',
      kind: 'hard',
      owner: 'risk',
      passed: false,
      action: 'veto',
      reason_ar: `التركّز المطلوب (${(ctx.requestedSizePct + currentStockPct).toFixed(1)}%) يتجاوز سقف السهم الواحد (${singleCapPct}%).`,
    });
    abstainReasons.push('تجاوز سقف التركّز المسموح في سهم واحد.');
  } else if (maxAllowedPct <= 0.5) {
    verdicts.push({
      id: 'concentration_cap',
      kind: 'hard',
      owner: 'risk',
      passed: false,
      action: 'veto',
      reason_ar: `المحفظة وصلت لسقف التركّز المسموح في السهم أو القطاع (${singleCapPct}% / ${sectorCapPct}%).`,
    });
    abstainReasons.push('وصلت المحفظة للحد الأقصى للتركّز.');
  } else {
    verdicts.push({
      id: 'concentration_cap',
      kind: 'hard',
      owner: 'risk',
      passed: true,
      action: 'allow',
      reason_ar: `سقف التركّز يسمح بحد أقصى ${maxAllowedPct.toFixed(1)}% إضافية.`,
    });
  }

  // 7. Position size formula: size <= (loss_tolerance_pct * portfolio) / stop_distance_pct
  const entry = ctx.proposedEntry ?? stock.price;
  const stop = ctx.proposedStop ?? Number((entry * 0.95).toFixed(2));
  const stopDistPct = Math.max(2, ((entry - stop) / Math.max(0.01, entry)) * 100);
  const effectiveRiskPct = Math.min(profile.loss_tolerance_pct, config.risk_per_trade_hard_max_pct);
  const riskFormulaPct = Number(((effectiveRiskPct / stopDistPct) * 100).toFixed(2));
  maxAllowedPct = Number(Math.max(0, Math.min(maxAllowedPct, riskFormulaPct)).toFixed(2));
  if (hiddenConcentrationFlag) {
    maxAllowedPct = Number((maxAllowedPct * 0.75).toFixed(2));
  }

  verdicts.push({
    id: 'position_size',
    kind: 'hard',
    owner: 'risk',
    passed: maxAllowedPct > 0,
    action: maxAllowedPct > 0 ? 'cap' : 'veto',
    reason_ar: `الحد الأقصى لحجم الصفقة المحسوب بالكود هو ${maxAllowedPct}% من المحفظة بناءً على تحمل خسارة ${effectiveRiskPct}% ومسافة وقف ${stopDistPct.toFixed(1)}%.`,
  });

  // 8. Liquidity trap
  const maxAllowedEgp = Number(((maxAllowedPct / 100) * totalPortfolio).toFixed(2));
  const maxQtyByRisk = Math.floor(maxAllowedEgp / Math.max(0.01, entry));
  const maxDailyParticipate = Math.max(1, stock.adv_30d * (config.liquidity_max_adv_pct / 100));
  const maxQtyByLiquidity = Math.floor(maxDailyParticipate * config.liquidity_max_exit_days);
  const maxAllowedQty = Math.max(0, Math.min(maxQtyByRisk, maxQtyByLiquidity));
  const trap = calculateTrapScore(stock, Math.max(100, maxAllowedQty), config);

  if (trap.exit_days > config.liquidity_block_exit_days || stock.free_float_pct < 10) {
    verdicts.push({
      id: 'liquidity_trap',
      kind: 'hard',
      owner: 'risk',
      passed: false,
      action: 'veto',
      reason_ar: `خطر فخ السيولة: أيام الخروج (${trap.exit_days} يوم) أو الأسهم الحرة (${stock.free_float_pct}%) لا تسمح بدخول آمن.`,
    });
    abstainReasons.push('سيولة السهم لا تكفي للخروج السلس عند الحاجة.');
  } else {
    verdicts.push({
      id: 'liquidity_trap',
      kind: 'hard',
      owner: 'risk',
      passed: true,
      action: maxQtyByRisk > maxQtyByLiquidity ? 'cap' : 'allow',
      reason_ar: `السيولة مقبولة (الخروج المقدر ${trap.exit_days} يوم، درجة الفخ ${trap.total}/100).`,
    });
  }

  const empty = abstainReasons.length > 0 || maxAllowedQty <= 0;
  return {
    empty,
    halted,
    crisis,
    licenceBlocked,
    abstainReasons,
    verdicts,
    maxAllowedPct,
    maxAllowedEgp: Number((maxAllowedQty * entry).toFixed(2)),
    maxAllowedQty,
    hiddenConcentrationFlag,
    hiddenConcentrationDetailAr,
  };
}

export function detectAgentConflicts(claims: Claim[]): {
  hasConflict: boolean;
  conflictFlags: string[];
  agreementScore: number;
} {
  const conflictFlags: string[] = [];
  const directionalClaims = claims.filter(
    (c) => typeof c.value === 'number' && (c.predicate.includes('score') || c.predicate.includes('direction'))
  );

  let disagreementPenalty = 0;
  for (let i = 0; i < directionalClaims.length; i++) {
    for (let j = i + 1; j < directionalClaims.length; j++) {
      const a = directionalClaims[i];
      const b = directionalClaims[j];
      const va = Number(a.value);
      const vb = Number(b.value);
      // If one agent is strongly bullish (>= 68) and another strongly bearish (<= 42)
      if ((va >= 68 && vb <= 42) || (vb >= 68 && va <= 42)) {
        conflictFlags.push(`تعارض بين وكيل (${a.agent}) ووكيل (${b.agent}) على ${a.subject}`);
        disagreementPenalty += 0.25;
      }
    }
  }

  // Check interval spreads and confidence variance
  const confidences = claims.map((c) => c.confidence);
  const meanConf =
    confidences.length > 0 ? confidences.reduce((s, c) => s + c, 0) / confidences.length : 0.5;
  const variance =
    confidences.length > 0
      ? confidences.reduce((s, c) => s + (c - meanConf) ** 2, 0) / confidences.length
      : 0;

  const agreementScore = Number(
    Math.max(0.1, Math.min(0.98, 0.92 - disagreementPenalty - Math.sqrt(variance) * 0.6)).toFixed(2)
  );

  return {
    hasConflict: conflictFlags.length > 0,
    conflictFlags,
    agreementScore,
  };
}
