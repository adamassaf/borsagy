import { ALL_84_AGENTS } from './agentsCatalog';
import { INITIAL_CONFIG, SHORT_DISCLAIMER_AR } from './marketPack';
import {
  Advice,
  AgentDefinition,
  AuditLogEntry,
  BrokerInfo,
  CalibrationRow,
  Edge,
  Entity,
  Fact,
  HumanReviewItem,
  Outcome,
  Plan,
  Position,
  PriceBar,
  RiskProfile,
  Source,
  StockSummary,
  Trade,
  Trader,
  TraderState,
} from './types';
import { computeSealHash } from './validators';

export interface SeedDataset {
  sources: Source[];
  entities: Entity[];
  facts: Fact[];
  edges: Edge[];
  stocks: StockSummary[];
  traders: Trader[];
  riskProfiles: RiskProfile[];
  traderStates: TraderState[];
  positions: Position[];
  plans: Plan[];
  trades: Trade[];
  advices: Advice[];
  outcomes: Outcome[];
  calibrations: CalibrationRow[];
  brokers: BrokerInfo[];
  reviewQueue: HumanReviewItem[];
  auditLogs: AuditLogEntry[];
  academyLessons: Array<{
    id: string;
    title_ar: string;
    summary_ar: string;
    duration_min: number;
    example_ar: string;
    linked_symbol: string;
  }>;
  glossary: Array<{
    term_ar: string;
    term_en: string;
    simple_ar: string;
    egyptian_example_ar: string;
  }>;
  agentsCatalog: AgentDefinition[];
}

const SECTORS = [
  { id: 'sec_banks', ar: 'البنوك والخدمات المالية', en: 'Banks' },
  { id: 'sec_realestate', ar: 'العقارات والإنشاءات', en: 'Real Estate' },
  { id: 'sec_telecom', ar: 'الاتصالات والتكنولوجيا', en: 'Telecom & Tech' },
  { id: 'sec_industry', ar: 'الصناعات والموارد الأساسية', en: 'Basic Resources' },
  { id: 'sec_consumer', ar: 'الأغذية والمشروبات', en: 'Food & Beverage' },
  { id: 'sec_health', ar: 'الرعاية الصحية والأدوية', en: 'Healthcare' },
  { id: 'sec_energy', ar: 'الطاقة والبتروكيماويات', en: 'Energy' },
  { id: 'sec_shipping', ar: 'النقل والخدمات اللوجستية', en: 'Logistics' },
];

const OWNER_GROUPS = [
  { id: 'grp_alpha', ar: 'مجموعة النيل القابضة (تجريبي)' },
  { id: 'grp_beta', ar: 'مجموعة القاهرة للاستثمار (تجريبي)' },
  { id: 'grp_gamma', ar: 'المجموعة الوطنية للأصول (تجريبي)' },
  { id: 'grp_delta', ar: 'تحالف الدلتا الصناعي (تجريبي)' },
  { id: 'grp_epsilon', ar: 'مجموعة البحر الأحمر (تجريبي)' },
  { id: 'grp_zeta', ar: 'شركاء الصعيد للتنمية (تجريبي)' },
];

// Deterministic PRNG for reproducible demo data
function mulberry32(seed: number) {
  return function () {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const STOCK_TEMPLATES: Array<{
  symbol: string;
  name_ar: string;
  name_en: string;
  sectorIdx: number;
  groupIdx: number;
  basePrice: number;
  adv: number;
  freeFloat: number;
  conc: number;
  pe: number;
  pb: number;
  roe: number;
  debt: number;
  div: number;
  sharia: boolean;
  nonHalalPct: number;
  special?: 'halted' | 'stale' | 'illiquid' | 'spike';
}> = [
  { symbol: 'COMI', name_ar: 'التجاري الدولي (تجريبي)', name_en: 'CIB Demo', sectorIdx: 0, groupIdx: 0, basePrice: 84.5, adv: 145_000_000, freeFloat: 52, conc: 48, pe: 8.4, pb: 1.9, roe: 28.5, debt: 0.35, div: 3.8, sharia: false, nonHalalPct: 72 },
  { symbol: 'TMGH', name_ar: 'طلعت مصطفى (تجريبي)', name_en: 'TMG Demo', sectorIdx: 1, groupIdx: 1, basePrice: 58.2, adv: 112_000_000, freeFloat: 41, conc: 59, pe: 11.2, pb: 1.6, roe: 21.4, debt: 0.45, div: 1.9, sharia: true, nonHalalPct: 1.2 },
  { symbol: 'EFID', name_ar: 'إيديتا للأغذية (تجريبي)', name_en: 'Edita Demo', sectorIdx: 4, groupIdx: 2, basePrice: 29.4, adv: 36_000_000, freeFloat: 34, conc: 66, pe: 10.6, pb: 2.8, roe: 26.2, debt: 0.40, div: 4.1, sharia: true, nonHalalPct: 0.4 },
  { symbol: 'HRHO', name_ar: 'إي إف جي القابضة (تجريبي)', name_en: 'EFG Holding Demo', sectorIdx: 0, groupIdx: 0, basePrice: 22.8, adv: 74_000_000, freeFloat: 48, conc: 52, pe: 9.8, pb: 1.2, roe: 17.5, debt: 0.65, div: 2.5, sharia: false, nonHalalPct: 48 },
  { symbol: 'ETEL', name_ar: 'المصرية للاتصالات (تجريبي)', name_en: 'Telecom Egypt Demo', sectorIdx: 2, groupIdx: 2, basePrice: 37.9, adv: 58_000_000, freeFloat: 20, conc: 80, pe: 7.9, pb: 0.9, roe: 19.2, debt: 0.72, div: 4.5, sharia: true, nonHalalPct: 2.1 },
  { symbol: 'ABUK', name_ar: 'أبو قير للأسمدة (تجريبي)', name_en: 'Abu Qir Demo', sectorIdx: 6, groupIdx: 3, basePrice: 63.0, adv: 68_000_000, freeFloat: 28, conc: 72, pe: 6.9, pb: 1.7, roe: 29.0, debt: 0.12, div: 7.2, sharia: true, nonHalalPct: 0.8 },
  { symbol: 'SWDY', name_ar: 'السويدي إليكتريك (تجريبي)', name_en: 'Elsewedy Demo', sectorIdx: 3, groupIdx: 3, basePrice: 49.5, adv: 84_000_000, freeFloat: 31, conc: 69, pe: 8.7, pb: 1.8, roe: 24.8, debt: 0.52, div: 2.9, sharia: true, nonHalalPct: 1.5 },
  { symbol: 'FWRY', name_ar: 'فوري للمدفوعات (تجريبي)', name_en: 'Fawry Demo', sectorIdx: 2, groupIdx: 4, basePrice: 8.65, adv: 62_000_000, freeFloat: 44, conc: 56, pe: 18.4, pb: 3.9, roe: 22.0, debt: 0.25, div: 0.0, sharia: true, nonHalalPct: 2.9 },
  { symbol: 'ORAS', name_ar: 'أوراسكوم للإنشاء (تجريبي)', name_en: 'Orascom Const Demo', sectorIdx: 1, groupIdx: 1, basePrice: 246.0, adv: 29_000_000, freeFloat: 36, conc: 64, pe: 7.4, pb: 1.1, roe: 20.5, debt: 0.42, div: 5.4, sharia: true, nonHalalPct: 1.1 },
  { symbol: 'ESRS', name_ar: 'حديد عز (تجريبي)', name_en: 'Ezz Steel Demo', sectorIdx: 3, groupIdx: 3, basePrice: 91.2, adv: 51_000_000, freeFloat: 32, conc: 68, pe: 9.1, pb: 1.5, roe: 19.0, debt: 0.95, div: 1.5, sharia: false, nonHalalPct: 8.5 },
  { symbol: 'ISPH', name_ar: 'ابن سينا فارما (تجريبي)', name_en: 'Ibnsina Demo', sectorIdx: 5, groupIdx: 5, basePrice: 4.32, adv: 24_000_000, freeFloat: 49, conc: 51, pe: 13.5, pb: 1.4, roe: 15.8, debt: 0.85, div: 1.2, sharia: true, nonHalalPct: 1.0 },
  { symbol: 'JUFO', name_ar: 'جهينة للصناعات (تجريبي)', name_en: 'Juhayna Demo', sectorIdx: 4, groupIdx: 2, basePrice: 24.7, adv: 27_000_000, freeFloat: 29, conc: 71, pe: 11.8, pb: 2.2, roe: 23.1, debt: 0.38, div: 3.4, sharia: true, nonHalalPct: 0.5 },
  { symbol: 'MFPC', name_ar: 'موبكو للأسمدة (تجريبي)', name_en: 'MOPCO Demo', sectorIdx: 6, groupIdx: 3, basePrice: 45.1, adv: 64_000_000, freeFloat: 26, conc: 74, pe: 7.2, pb: 1.9, roe: 27.6, debt: 0.19, div: 6.4, sharia: true, nonHalalPct: 0.7 },
  { symbol: 'ALCN', name_ar: 'الإسكندرية للحاويات (تجريبي)', name_en: 'Alex Containers Demo', sectorIdx: 7, groupIdx: 4, basePrice: 23.4, adv: 33_000_000, freeFloat: 18, conc: 82, pe: 6.5, pb: 2.1, roe: 31.2, debt: 0.08, div: 8.9, sharia: true, nonHalalPct: 0.9 },
  { symbol: 'PHDC', name_ar: 'بالم هيلز (تجريبي)', name_en: 'Palm Hills Demo', sectorIdx: 1, groupIdx: 1, basePrice: 5.84, adv: 41_000_000, freeFloat: 39, conc: 61, pe: 8.8, pb: 1.1, roe: 16.9, debt: 0.58, div: 1.8, sharia: true, nonHalalPct: 2.4 },
  { symbol: 'ADIB', name_ar: 'أبوظبي الإسلامي مصر (تجريبي)', name_en: 'ADIB Egypt Demo', sectorIdx: 0, groupIdx: 0, basePrice: 39.2, adv: 38_000_000, freeFloat: 35, conc: 65, pe: 5.4, pb: 1.3, roe: 29.8, debt: 0.22, div: 4.0, sharia: true, nonHalalPct: 0.3 },
  { symbol: 'CLHO', name_ar: 'كليوباترا للمستشفيات (تجريبي)', name_en: 'Cleopatra Hosp Demo', sectorIdx: 5, groupIdx: 5, basePrice: 7.45, adv: 19_500_000, freeFloat: 38, conc: 62, pe: 14.2, pb: 2.5, roe: 21.0, debt: 0.28, div: 1.1, sharia: true, nonHalalPct: 0.4 },
  { symbol: 'SKPC', name_ar: 'سيدي كرير للبتروكيماويات (تجريبي)', name_en: 'SIDPEC Demo', sectorIdx: 6, groupIdx: 3, basePrice: 21.9, adv: 34_000_000, freeFloat: 24, conc: 76, pe: 7.7, pb: 1.6, roe: 25.0, debt: 0.14, div: 5.8, sharia: true, nonHalalPct: 0.6 },
  { symbol: 'AMOC', name_ar: 'أموك للزيوت المعدنية (تجريبي)', name_en: 'AMOC Demo', sectorIdx: 6, groupIdx: 4, basePrice: 8.95, adv: 28_000_000, freeFloat: 27, conc: 73, pe: 8.1, pb: 1.4, roe: 20.1, debt: 0.15, div: 6.2, sharia: true, nonHalalPct: 0.8 },
  { symbol: 'HELI', name_ar: 'مصر الجديدة للإسكان (تجريبي)', name_en: 'Heliopolis Housing Demo', sectorIdx: 1, groupIdx: 1, basePrice: 10.65, adv: 25_000_000, freeFloat: 27, conc: 73, pe: 12.1, pb: 1.3, roe: 15.2, debt: 0.31, div: 2.0, sharia: true, nonHalalPct: 1.4 },
  { symbol: 'CSAG', name_ar: 'القناة للتوكيلات (تجريبي)', name_en: 'Canal Shipping Demo', sectorIdx: 7, groupIdx: 4, basePrice: 22.1, adv: 14_000_000, freeFloat: 19, conc: 81, pe: 9.2, pb: 2.0, roe: 22.4, debt: 0.11, div: 4.8, sharia: true, nonHalalPct: 0.9 },
  { symbol: 'MASR', name_ar: 'مدينة مصر للإسكان (تجريبي)', name_en: 'Madinet Masr Demo', sectorIdx: 1, groupIdx: 2, basePrice: 4.65, adv: 32_000_000, freeFloat: 42, conc: 58, pe: 7.8, pb: 1.5, roe: 23.0, debt: 0.37, div: 3.6, sharia: true, nonHalalPct: 1.7 },
  { symbol: 'EKHO', name_ar: 'القابضة المصرية الكويتية (تجريبي)', name_en: 'EKH Demo', sectorIdx: 6, groupIdx: 0, basePrice: 36.5, adv: 16_000_000, freeFloat: 44, conc: 56, pe: 9.4, pb: 1.4, roe: 18.4, debt: 0.44, div: 4.7, sharia: true, nonHalalPct: 2.5 },
  { symbol: 'ORWE', name_ar: 'النساجون الشرقيون (تجريبي)', name_en: 'Oriental Weavers Demo', sectorIdx: 3, groupIdx: 5, basePrice: 25.4, adv: 22_000_000, freeFloat: 41, conc: 59, pe: 8.6, pb: 1.3, roe: 21.8, debt: 0.41, div: 5.5, sharia: true, nonHalalPct: 1.2 },
  { symbol: 'OLFI', name_ar: 'عبور لاند (تجريبي)', name_en: 'Obour Land Demo', sectorIdx: 4, groupIdx: 2, basePrice: 17.8, adv: 12_500_000, freeFloat: 33, conc: 67, pe: 9.9, pb: 2.4, roe: 27.0, debt: 0.29, div: 6.1, sharia: true, nonHalalPct: 0.3 },
  { symbol: 'RMDA', name_ar: 'راميدا للأدوية (تجريبي)', name_en: 'Rameda Demo', sectorIdx: 5, groupIdx: 5, basePrice: 3.18, adv: 11_000_000, freeFloat: 46, conc: 54, pe: 12.6, pb: 1.7, roe: 16.4, debt: 0.49, div: 1.5, sharia: true, nonHalalPct: 0.6 },
  { symbol: 'CIEB', name_ar: 'كريدي أجريكول مصر (تجريبي)', name_en: 'Credit Agricole Demo', sectorIdx: 0, groupIdx: 0, basePrice: 20.6, adv: 15_000_000, freeFloat: 31, conc: 69, pe: 5.1, pb: 1.4, roe: 30.1, debt: 0.25, div: 7.4, sharia: false, nonHalalPct: 68 },
  { symbol: 'ARCC', name_ar: 'العربية للأسمنت (تجريبي)', name_en: 'Arabian Cement Demo', sectorIdx: 3, groupIdx: 3, basePrice: 14.3, adv: 9_800_000, freeFloat: 28, conc: 72, pe: 7.9, pb: 1.5, roe: 22.1, debt: 0.32, div: 5.2, sharia: true, nonHalalPct: 0.7 },
  { symbol: 'EXPA', name_ar: 'تنمية الصادرات (تجريبي)', name_en: 'EBank Demo', sectorIdx: 0, groupIdx: 2, basePrice: 18.4, adv: 10_200_000, freeFloat: 29, conc: 71, pe: 4.8, pb: 0.9, roe: 24.5, debt: 0.30, div: 3.1, sharia: false, nonHalalPct: 62 },
  { symbol: 'RAYA', name_ar: 'راية القابضة (تجريبي)', name_en: 'Raya Holding Demo', sectorIdx: 2, groupIdx: 4, basePrice: 3.45, adv: 13_400_000, freeFloat: 43, conc: 57, pe: 14.8, pb: 1.9, roe: 16.2, debt: 0.88, div: 0.8, sharia: false, nonHalalPct: 9.2 },
  { symbol: 'BINV', name_ar: 'بي إنفستمنتس (تجريبي)', name_en: 'B Investments Demo', sectorIdx: 0, groupIdx: 4, basePrice: 23.1, adv: 8_500_000, freeFloat: 51, conc: 49, pe: 6.7, pb: 1.1, roe: 18.9, debt: 0.14, div: 6.8, sharia: true, nonHalalPct: 3.2 },
  { symbol: 'MTIE', name_ar: 'إم إم جروب (تجريبي)', name_en: 'MM Group Demo', sectorIdx: 2, groupIdx: 4, basePrice: 7.82, adv: 17_000_000, freeFloat: 37, conc: 63, pe: 11.4, pb: 2.1, roe: 20.6, debt: 0.39, div: 2.2, sharia: true, nonHalalPct: 1.8 },
  { symbol: 'CICH', name_ar: 'سي آي كابيتال (تجريبي)', name_en: 'CI Capital Demo', sectorIdx: 0, groupIdx: 0, basePrice: 5.95, adv: 11_800_000, freeFloat: 22, conc: 78, pe: 6.8, pb: 1.2, roe: 19.7, debt: 0.78, div: 4.0, sharia: false, nonHalalPct: 55 },
  // Special Test Fixture Stocks (Halted, Stale, Suspicious Spike, and 5 Illiquid names)
  { symbol: 'DHLT', name_ar: 'دلتا الموقوفة (تجريبي)', name_en: 'Delta Halted Demo', sectorIdx: 3, groupIdx: 3, basePrice: 12.4, adv: 4_200_000, freeFloat: 24, conc: 76, pe: 15.0, pb: 1.4, roe: 9.0, debt: 0.65, div: 0, sharia: true, nonHalalPct: 1.0, special: 'halted' },
  { symbol: 'DSTL', name_ar: 'سهم البيانات القديمة (تجريبي)', name_en: 'Stale Feed Demo', sectorIdx: 4, groupIdx: 2, basePrice: 19.1, adv: 6_100_000, freeFloat: 31, conc: 69, pe: 11.1, pb: 1.3, roe: 14.0, debt: 0.42, div: 2.5, sharia: true, nonHalalPct: 0.9, special: 'stale' },
  { symbol: 'DSPK', name_ar: 'الصناعات الصاعدة فجأة (تجريبي)', name_en: 'Spike Alert Demo', sectorIdx: 3, groupIdx: 5, basePrice: 16.8, adv: 950_000, freeFloat: 14, conc: 86, pe: 34.5, pb: 3.4, roe: 6.1, debt: 1.25, div: 0, sharia: true, nonHalalPct: 2.1, special: 'spike' },
  { symbol: 'DILQ1', name_ar: 'الشرقية غير السائلة ١ (تجريبي)', name_en: 'Illiquid One Demo', sectorIdx: 7, groupIdx: 5, basePrice: 42.0, adv: 180_000, freeFloat: 9, conc: 91, pe: 22.0, pb: 2.1, roe: 7.5, debt: 0.82, div: 0, sharia: true, nonHalalPct: 1.5, special: 'illiquid' },
  { symbol: 'DILQ2', name_ar: 'المتحدة للمقاولات ٢ (تجريبي)', name_en: 'Illiquid Two Demo', sectorIdx: 1, groupIdx: 5, basePrice: 31.5, adv: 220_000, freeFloat: 11, conc: 89, pe: 26.0, pb: 1.8, roe: 5.8, debt: 0.94, div: 0, sharia: true, nonHalalPct: 2.2, special: 'illiquid' },
  { symbol: 'DILQ3', name_ar: 'الوادي للغزل ٣ (تجريبي)', name_en: 'Illiquid Three Demo', sectorIdx: 3, groupIdx: 4, basePrice: 14.9, adv: 145_000, freeFloat: 8, conc: 92, pe: 29.0, pb: 1.5, roe: 4.2, debt: 1.15, div: 0, sharia: true, nonHalalPct: 1.1, special: 'illiquid' },
  { symbol: 'DILQ4', name_ar: 'النيل للشحن ٤ (تجريبي)', name_en: 'Illiquid Four Demo', sectorIdx: 7, groupIdx: 4, basePrice: 54.0, adv: 260_000, freeFloat: 12, conc: 88, pe: 19.5, pb: 1.6, roe: 8.4, debt: 0.74, div: 1.0, sharia: true, nonHalalPct: 0.9, special: 'illiquid' },
];

export function buildSeedDataset(): SeedDataset {
  const now = new Date('2026-11-25T12:00:00.000Z');
  const nowIso = now.toISOString();
  const rng = mulberry32(20261125);

  const sources: Source[] = [
    {
      id: 'src_demo_feed',
      name: 'بيانات سوق تجريبية (DEMO EGX Feed)',
      kind: 'demo',
      licence: 'displayable',
      licence_valid_to: '2027-12-31',
    },
    {
      id: 'src_egx_disclosures',
      name: 'نشرات الإفصاح الرسمية (نموذج)',
      kind: 'disclosure',
      licence: 'displayable',
      licence_valid_to: '2027-12-31',
    },
    {
      id: 'src_computed_engine',
      name: 'محرك الحساب الحتمي في بورصجي',
      kind: 'computed',
      licence: 'displayable',
      licence_valid_to: '2027-12-31',
    },
    {
      id: 'src_broker_thndr_support',
      name: 'صفحات دعم ثاندر (عمولة 0.1% + حد أدنى 2 ج)',
      kind: 'broker_official',
      licence: 'displayable',
      licence_valid_to: '2027-06-30',
      url: 'https://support.thndr.app',
    },
    {
      id: 'src_press_q3_2026',
      name: 'تقارير ترتيب شركات الوساطة - الربع الثالث 2026 (شوف نيوز / المال)',
      kind: 'press',
      licence: 'displayable',
      licence_valid_to: '2027-06-30',
    },
  ];

  const entities: Entity[] = [];
  const facts: Fact[] = [];
  const edges: Edge[] = [];
  const stocks: StockSummary[] = [];

  // Sector + Group entities
  for (const s of SECTORS) {
    entities.push({
      id: s.id,
      type: 'sector',
      canonical_name_ar: s.ar,
      canonical_name_en: s.en,
      attrs: {},
    });
  }
  for (const g of OWNER_GROUPS) {
    entities.push({
      id: g.id,
      type: 'group',
      canonical_name_ar: g.ar,
      canonical_name_en: g.id,
      attrs: {},
    });
  }

  const macroEntity: Entity = {
    id: 'macro_cbe_rate',
    type: 'macro',
    canonical_name_ar: 'سعر الفائدة الأساسي (البنك المركزي المصري)',
    canonical_name_en: 'CBE Overnight Rate',
    attrs: { unit: '%' },
  };
  entities.push(macroEntity);

  // Macro affected_by edges
  edges.push({
    id: 'edge_macro_banks',
    src: 'sec_banks',
    rel: 'affected_by',
    dst: 'macro_cbe_rate',
    props: { sign: 1, lag_days: 15, strength: 0.72 },
    valid_from: '2026-01-01T00:00:00.000Z',
    valid_to: null,
    known_at: '2026-01-01T00:00:00.000Z',
    evidence: [],
  });
  edges.push({
    id: 'edge_macro_realestate',
    src: 'sec_realestate',
    rel: 'affected_by',
    dst: 'macro_cbe_rate',
    props: { sign: -1, lag_days: 30, strength: 0.65 },
    valid_from: '2026-01-01T00:00:00.000Z',
    valid_to: null,
    known_at: '2026-01-01T00:00:00.000Z',
    evidence: [],
  });

  // Build 40 synthetic stocks + 180 daily bars + bitemporal facts
  for (let idx = 0; idx < STOCK_TEMPLATES.length; idx++) {
    const tpl = STOCK_TEMPLATES[idx];
    const sector = SECTORS[tpl.sectorIdx];
    const group = OWNER_GROUPS[tpl.groupIdx];
    const stockId = `Stock:${tpl.symbol}`;

    entities.push({
      id: stockId,
      type: 'stock',
      canonical_name_ar: tpl.name_ar,
      canonical_name_en: tpl.name_en,
      symbol: tpl.symbol,
      attrs: { is_demo: true, free_float_pct: tpl.freeFloat },
    });

    edges.push({
      id: `edge_sec_${tpl.symbol}`,
      src: stockId,
      rel: 'belongs_to',
      dst: sector.id,
      props: {},
      valid_from: '2026-01-01T00:00:00.000Z',
      valid_to: null,
      known_at: '2026-01-01T00:00:00.000Z',
      evidence: [],
    });

    edges.push({
      id: `edge_grp_${tpl.symbol}`,
      src: stockId,
      rel: 'owned_by_group',
      dst: group.id,
      props: { concentration_pct: tpl.conc },
      valid_from: '2026-01-01T00:00:00.000Z',
      valid_to: null,
      known_at: '2026-01-01T00:00:00.000Z',
      evidence: [],
    });

    // Generate 180 GBM daily bars
    const bars: PriceBar[] = [];
    let p = tpl.basePrice * (0.82 + rng() * 0.22);
    for (let d = 179; d >= 0; d--) {
      const dayTs = new Date(now.getTime() - d * 24 * 3600_000);
      const drift = tpl.special === 'spike' && d < 3 ? 0.055 : 0.0007;
      const vol = tpl.special === 'illiquid' ? 0.032 : 0.018;
      const shock = (rng() - 0.48) * vol;
      const open = Number(p.toFixed(2));
      const close = Number(Math.max(0.5, open * (1 + drift + shock)).toFixed(2));
      const high = Number((Math.max(open, close) * (1 + rng() * 0.015)).toFixed(2));
      const low = Number((Math.min(open, close) * (1 - rng() * 0.015)).toFixed(2));
      const volumeShares = Math.round((tpl.adv / Math.max(1, close)) * (0.65 + rng() * 0.8));

      bars.push({
        symbol: tpl.symbol,
        ts: dayTs.toISOString(),
        o: open,
        h: high,
        l: low,
        c: close,
        v: volumeShares,
        known_at: dayTs.toISOString(),
        source_id: 'src_demo_feed',
        halted: tpl.special === 'halted' && d === 0,
      });
      p = close;
    }

    const latestBar = bars[bars.length - 1];
    const prevBar = bars[bars.length - 2];
    const weekBar = bars[bars.length - 6];
    const monthBar = bars[bars.length - 22];

    const lastPrice = latestBar.c;
    const change1d = Number((((lastPrice - prevBar.c) / prevBar.c) * 100).toFixed(2));
    const change1h = Number((change1d * (0.35 + rng() * 0.35)).toFixed(2));
    const change1w = Number((((lastPrice - weekBar.c) / weekBar.c) * 100).toFixed(2));
    const change1m = Number((((lastPrice - monthBar.c) / monthBar.c) * 100).toFixed(2));

    const quality =
      tpl.special === 'halted'
        ? 'halted'
        : tpl.special === 'stale'
          ? 'valid'
          : 'valid';
    const dataAgeSeconds =
      tpl.special === 'stale'
        ? 3900 // 65 mins stale (> 20m limit)
        : 180 + Math.floor(rng() * 420); // 3 to 10 min delay

    const lastUpdatedIso = new Date(now.getTime() - dataAgeSeconds * 1000).toISOString();
    const rsi = tpl.special === 'spike' ? 81 : Math.round(34 + rng() * 38);
    const macd = change1w > 1.5 ? 'bullish' : change1w < -1.5 ? 'bearish' : 'neutral';

    // Bitemporal facts for this stock
    const baseFactTime = lastUpdatedIso;
    const stockFactItems: Array<{ predicate: string; value: number | string; kind: Fact['kind'] }> = [
      { predicate: 'last_price', value: lastPrice, kind: 'observed' },
      { predicate: 'adv_30d', value: tpl.adv, kind: 'computed' },
      { predicate: 'pe_ratio', value: tpl.pe, kind: 'computed' },
      { predicate: 'rsi_14', value: rsi, kind: 'computed' },
    ];

    for (const item of stockFactItems) {
      facts.push({
        id: `fact_${tpl.symbol}_${item.predicate}`,
        entity_id: stockId,
        predicate: item.predicate,
        value: item.value,
        kind: item.kind,
        source_id: item.kind === 'observed' ? 'src_demo_feed' : 'src_computed_engine',
        quality,
        valid_from: baseFactTime,
        valid_to: null,
        known_at: baseFactTime,
      });
    }

    stocks.push({
      id: stockId,
      symbol: tpl.symbol,
      name_ar: tpl.name_ar,
      name_en: tpl.name_en,
      sector_id: sector.id,
      sector_ar: sector.ar,
      owner_group_id: group.id,
      owner_group_ar: group.ar,
      is_demo: true,
      price: lastPrice,
      prev_close: prevBar.c,
      change_1h_pct: change1h,
      change_1d_pct: change1d,
      change_1w_pct: change1w,
      change_1m_pct: change1m,
      volume_today: latestBar.v * lastPrice,
      adv_30d: tpl.adv,
      free_float_pct: tpl.freeFloat,
      ownership_concentration_pct: tpl.conc,
      pe: tpl.pe,
      pb: tpl.pb,
      roe: tpl.roe,
      debt_to_equity: tpl.debt,
      dividend_yield_pct: tpl.div,
      non_halal_revenue_pct: tpl.nonHalalPct,
      sharia_compliant: tpl.sharia,
      rsi_14: rsi,
      macd_signal: macd,
      spread_bps: tpl.special === 'illiquid' ? 95 : 18 + Math.floor(rng() * 14),
      halt_count_90d: tpl.special === 'halted' ? 3 : tpl.special === 'illiquid' ? 2 : 0,
      unexplained_spike: tpl.special === 'spike',
      disclosure_weakness: tpl.special === 'illiquid' || tpl.special === 'halted',
      quality,
      data_age_seconds: dataAgeSeconds,
      last_updated: lastUpdatedIso,
      business_summary_ar: `شركة تعمل في قطاع ${sector.ar} ضمن السوق الرئيسي (نموذج تجريبي DEMO للمعاينة والاختبار).`,
      revenue_sources_ar: `تعتمد إيراداتها على التشغيل الأساسي في ${sector.ar} مع توزيع جغرافي محلي وتصديري متوازن.`,
      key_risks_ar:
        tpl.special === 'illiquid'
          ? 'انخفاض السيولة اليومية واتساع الفجوة بين العرض والطلب؛ يستغرق الخروج عدة أيام.'
          : 'تأثر هامش الربحية بتغيرات أسعار الفائدة وسعر الصرف وتكاليف التمويل.',
      disclosures: [
        {
          id: `disc_${tpl.symbol}_1`,
          date: '2026-11-18',
          title_ar:
            tpl.special === 'halted'
              ? 'إيقاف تداول مؤقت لحين ورود بيان توضيحي من الشركة'
              : `ملخص نتائج الأعمال الدورية لـ ${tpl.symbol}`,
          summary_ar:
            tpl.special === 'halted'
              ? 'قررت إدارة البورصة إيقاف التعامل مؤقتاً لحين توضيح أخبار جوهرية متداولة.'
              : `أظهرت القوائم المجمعة نمواً متوازناً في الإيرادات مع عائد على حقوق الملكية ${tpl.roe}% ومضاعف ربحية ${tpl.pe} مرة.`,
          direction: tpl.special === 'halted' ? 'negative' : 'positive',
          type: tpl.special === 'halted' ? 'halt' : 'results',
        },
      ],
      bars,
    });
  }

  // 5 Trader Personas (Section 19)
  const traders: Trader[] = [
    {
      id: 'trader_main',
      handle: 'أحمد (مضارب حذر)',
      anonymous: false,
      created_at: '2026-09-01T08:00:00.000Z',
      dialect: 'egyptian',
      numerals: 'western',
      low_bandwidth: false,
      quiet_hours: { start: '23:00', end: '08:00' },
      daily_alert_budget: 5,
      alerts_sent_today: 2,
      trusted_observer: { name: 'خالد (مراقب موثوق)', contact: 'khaled@example.com', consented: true },
      subscription_tier: 'plus',
      billing_cycle: 'monthly',
    },
    {
      id: 'trader_beginner_debt',
      handle: 'سارة (مبتدئة — تنبيه أموال مقترضة)',
      anonymous: false,
      created_at: '2026-11-10T09:00:00.000Z',
      dialect: 'egyptian',
      numerals: 'western',
      low_bandwidth: false,
      quiet_hours: { start: '22:00', end: '08:00' },
      daily_alert_budget: 5,
      alerts_sent_today: 0,
      trusted_observer: null,
      subscription_tier: 'free',
      billing_cycle: 'monthly',
    },
    {
      id: 'trader_revenge_tilt',
      handle: 'كريم (نمط اندفاع بعد خسارة)',
      anonymous: false,
      created_at: '2026-10-05T10:00:00.000Z',
      dialect: 'egyptian',
      numerals: 'western',
      low_bandwidth: false,
      quiet_hours: { start: '23:00', end: '09:00' },
      daily_alert_budget: 5,
      alerts_sent_today: 4,
      trusted_observer: null,
      subscription_tier: 'plus',
      billing_cycle: 'monthly',
    },
    {
      id: 'trader_disciplined_pro',
      handle: 'طارق (مضارب منضبط — وضع الناصح)',
      anonymous: true,
      created_at: '2026-06-15T08:00:00.000Z',
      dialect: 'egyptian',
      numerals: 'western',
      low_bandwidth: false,
      quiet_hours: { start: '00:00', end: '07:00' },
      daily_alert_budget: 5,
      alerts_sent_today: 1,
      trusted_observer: null,
      subscription_tier: 'pro',
      billing_cycle: 'annual',
    },
  ];

  const riskProfiles: RiskProfile[] = [
    {
      trader_id: 'trader_main',
      experience: 'active',
      goal: 'growth',
      horizon: 'weeks',
      loss_tolerance_pct: 1.5,
      portfolio_size_egp: 150_000,
      daily_loss_limit_pct: 2.0,
      weekly_loss_limit_pct: 5.0,
      single_stock_cap_pct: 25,
      sector_cap_pct: 45,
      money_not_to_risk_ack: true,
      borrowed_money_flag: false,
      max_affordable_loss_egp: 15_000,
      preferred_sharia_only: false,
    },
    {
      trader_id: 'trader_beginner_debt',
      experience: 'beginner',
      goal: 'learning',
      horizon: 'months',
      loss_tolerance_pct: 1.0,
      portfolio_size_egp: 25_000,
      daily_loss_limit_pct: 2.0,
      weekly_loss_limit_pct: 5.0,
      single_stock_cap_pct: 15,
      sector_cap_pct: 35,
      money_not_to_risk_ack: false,
      borrowed_money_flag: true,
      max_affordable_loss_egp: 1_500,
      preferred_sharia_only: true,
    },
    {
      trader_id: 'trader_revenge_tilt',
      experience: 'active',
      goal: 'speculation',
      horizon: 'days',
      loss_tolerance_pct: 1.5,
      portfolio_size_egp: 80_000,
      daily_loss_limit_pct: 2.0,
      weekly_loss_limit_pct: 5.0,
      single_stock_cap_pct: 25,
      sector_cap_pct: 45,
      money_not_to_risk_ack: true,
      borrowed_money_flag: false,
      max_affordable_loss_egp: 8_000,
      preferred_sharia_only: false,
    },
    {
      trader_id: 'trader_disciplined_pro',
      experience: 'advanced',
      goal: 'growth',
      horizon: 'weeks',
      loss_tolerance_pct: 2.0,
      portfolio_size_egp: 420_000,
      daily_loss_limit_pct: 2.5,
      weekly_loss_limit_pct: 6.0,
      single_stock_cap_pct: 35,
      sector_cap_pct: 55,
      money_not_to_risk_ack: true,
      borrowed_money_flag: false,
      max_affordable_loss_egp: 45_000,
      preferred_sharia_only: false,
    },
  ];

  const traderStates: TraderState[] = [
    {
      trader_id: 'trader_main',
      as_of: nowIso,
      mode: 'hybrid',
      active_mode: 'manager',
      mood: 'calm',
      tilt_score: 18,
      discipline_score: 0.74,
      loss_streak: 0,
      day_pnl_pct: 0.65,
      week_pnl_pct: 1.85,
      halted: false,
      upgrade_eligible: false,
      license_level: 2,
    },
    {
      trader_id: 'trader_beginner_debt',
      as_of: nowIso,
      mode: 'manager',
      active_mode: 'manager',
      mood: 'tense',
      tilt_score: 35,
      discipline_score: 0.55,
      loss_streak: 1,
      day_pnl_pct: -0.4,
      week_pnl_pct: -1.1,
      halted: false,
      upgrade_eligible: false,
      license_level: 1,
    },
    {
      trader_id: 'trader_revenge_tilt',
      as_of: nowIso,
      mode: 'hybrid',
      active_mode: 'manager',
      mood: 'tense',
      tilt_score: 74,
      discipline_score: 0.42,
      loss_streak: 3,
      day_pnl_pct: -2.4, // Exceeds 2% daily loss limit -> HALT
      week_pnl_pct: -5.6,
      halted: true,
      halt_until: new Date(now.getTime() + 24 * 3600_000).toISOString(),
      upgrade_eligible: false,
      license_level: 1,
    },
    {
      trader_id: 'trader_disciplined_pro',
      as_of: nowIso,
      mode: 'advisor',
      active_mode: 'advisor',
      mood: 'calm',
      tilt_score: 8,
      discipline_score: 0.89,
      loss_streak: 0,
      day_pnl_pct: 1.1,
      week_pnl_pct: 3.4,
      halted: false,
      upgrade_eligible: true,
      license_level: 3,
    },
  ];

  // Positions for trader_main (includes 2 stocks from grp_alpha -> triggers hidden concentration warning!)
  const comi = stocks.find((s) => s.symbol === 'COMI')!;
  const hrho = stocks.find((s) => s.symbol === 'HRHO')!;
  const tmgh = stocks.find((s) => s.symbol === 'TMGH')!;

  const positions: Position[] = [
    {
      id: 'pos_1',
      trader_id: 'trader_main',
      symbol: 'COMI',
      stock_name_ar: comi.name_ar,
      sector_id: comi.sector_id,
      owner_group_id: comi.owner_group_id, // grp_alpha
      qty: 300,
      avg_price: 81.2,
      current_price: comi.price,
      opened_at: '2026-11-12T10:30:00.000Z',
      plan_id: 'plan_1',
    },
    {
      id: 'pos_2',
      trader_id: 'trader_main',
      symbol: 'HRHO',
      stock_name_ar: hrho.name_ar,
      sector_id: hrho.sector_id,
      owner_group_id: hrho.owner_group_id, // grp_alpha -> hidden concentration!
      qty: 950,
      avg_price: 21.9,
      current_price: hrho.price,
      opened_at: '2026-11-16T11:15:00.000Z',
      plan_id: 'plan_2',
    },
    {
      id: 'pos_3',
      trader_id: 'trader_main',
      symbol: 'TMGH',
      stock_name_ar: tmgh.name_ar,
      sector_id: tmgh.sector_id,
      owner_group_id: tmgh.owner_group_id,
      qty: 400,
      avg_price: 56.5,
      current_price: tmgh.price,
      opened_at: '2026-11-19T12:00:00.000Z',
      plan_id: 'plan_3',
    },
  ];

  const plans: Plan[] = [
    {
      id: 'plan_1',
      trader_id: 'trader_main',
      symbol: 'COMI',
      reason: 'ارتداد من منطقة دعم سيولة عالية مع تحسن العائد على حقوق الملكية',
      entry: 81.2,
      size_pct: 16.5,
      stop: 77.5,
      targets: [88.0, 92.5],
      worst_case: 'خروج آلي عند 77.5 ج بخسارة صافية محسوبة ضمن الحد الشخصي',
      mood: 'calm',
      signed_at: '2026-11-12T10:25:00.000Z',
    },
  ];

  // Historical closed trades including BOTH wins and real losses + rule-break behavioral cost
  const trades: Trade[] = [
    {
      id: 'trd_101',
      trader_id: 'trader_main',
      plan_id: 'plan_1',
      advice_id: 'adv_seed_1',
      symbol: 'ABUK',
      side: 'sell',
      qty: 350,
      entry_price: 59.0,
      price: 63.2,
      fees_egp: 74.2,
      net_pnl_egp: 1395.8,
      net_return_pct: 6.76,
      rule_break_cost_egp: 0,
      executed_at: '2026-11-04T13:10:00.000Z',
      closed_at: '2026-11-09T12:30:00.000Z',
      cause: 'analysis',
      deviation_tags: ['none'],
      stop_adhered: true,
      plan_adhered: true,
      size_adhered: true,
      journal_completed: true,
    },
    {
      id: 'trd_102',
      trader_id: 'trader_main',
      plan_id: null,
      advice_id: 'adv_seed_2',
      symbol: 'ESRS',
      side: 'sell',
      qty: 280,
      entry_price: 94.5,
      price: 88.2,
      fees_egp: 89.4,
      net_pnl_egp: -1853.4,
      net_return_pct: -7.0,
      rule_break_cost_egp: 690, // Lost extra 690 EGP by delaying stop exit!
      executed_at: '2026-11-07T11:20:00.000Z',
      closed_at: '2026-11-11T14:05:00.000Z',
      cause: 'execution',
      deviation_tags: ['no_stop'],
      stop_adhered: false,
      plan_adhered: false,
      size_adhered: true,
      journal_completed: true,
    },
    {
      id: 'trd_103',
      trader_id: 'trader_main',
      plan_id: null,
      advice_id: 'adv_seed_3',
      symbol: 'SWDY',
      side: 'sell',
      qty: 500,
      entry_price: 46.8,
      price: 49.4,
      fees_egp: 82.9,
      net_pnl_egp: 1217.1,
      net_return_pct: 5.2,
      rule_break_cost_egp: 0,
      executed_at: '2026-11-13T10:40:00.000Z',
      closed_at: '2026-11-18T13:45:00.000Z',
      cause: 'market',
      deviation_tags: ['none'],
      stop_adhered: true,
      plan_adhered: true,
      size_adhered: true,
      journal_completed: true,
    },
    {
      id: 'trd_104',
      trader_id: 'trader_main',
      plan_id: null,
      advice_id: 'adv_seed_4',
      symbol: 'FWRY',
      side: 'sell',
      qty: 2200,
      entry_price: 8.95,
      price: 8.45,
      fees_egp: 68.5,
      net_pnl_egp: -1168.5,
      net_return_pct: -5.93,
      rule_break_cost_egp: 410,
      executed_at: '2026-11-19T13:50:00.000Z',
      closed_at: '2026-11-21T11:10:00.000Z',
      cause: 'execution',
      deviation_tags: ['fomo', 'early_exit'],
      stop_adhered: true,
      plan_adhered: false,
      size_adhered: false,
      journal_completed: true,
    },
  ];

  // Build hash-chained public sealed track record (INCLUDING losses & abstentions!)
  const rawSeedAdvices: Array<{
    id: string;
    symbol: string;
    kind: Advice['kind'];
    text_ar: string;
    confidence: number;
    agreement: number;
    sealed_at: string;
    result: Outcome['result'];
    net_return_pct: number;
    cause: Outcome['cause'];
  }> = [
    {
      id: 'adv_seed_1',
      symbol: 'ABUK',
      kind: 'plan',
      text_ar: 'جهزت لك خطة على سهم ABUK: دخول قرب 59.0، وقف الخسارة 56.2، هدف أول 63.2. حجم الصفقة 12% من محفظتك بس. توافق؟',
      confidence: 0.81,
      agreement: 0.88,
      sealed_at: '2026-11-04T09:15:00.000Z',
      result: 'win',
      net_return_pct: 6.76,
      cause: 'analysis',
    },
    {
      id: 'adv_seed_2',
      symbol: 'ESRS',
      kind: 'plan',
      text_ar: 'جهزت لك خطة على سهم ESRS: دخول قرب 94.5، وقف الخسارة 90.0، هدف أول 101.0. حجم الصفقة 10% من محفظتك بس. توافق؟',
      confidence: 0.68,
      agreement: 0.72,
      sealed_at: '2026-11-07T09:10:00.000Z',
      result: 'loss',
      net_return_pct: -4.9,
      cause: 'market',
    },
    {
      id: 'adv_seed_3',
      symbol: 'SWDY',
      kind: 'plan',
      text_ar: 'جهزت لك خطة على سهم SWDY: دخول قرب 46.8، وقف الخسارة 44.5، هدف أول 50.2. حجم الصفقة 14% من محفظتك بس. توافق؟',
      confidence: 0.76,
      agreement: 0.84,
      sealed_at: '2026-11-13T09:20:00.000Z',
      result: 'win',
      net_return_pct: 5.2,
      cause: 'analysis',
    },
    {
      id: 'adv_seed_4',
      symbol: 'DSPK',
      kind: 'abstain',
      text_ar: 'النهارده مفيش صفقة واضحة على DSPK تستاهل المخاطرة. السبب: ارتفاع حاد غير مفسر وسيولة ضعيفة. الانتظار برضه قرار سليم.',
      confidence: 0.85,
      agreement: 0.94,
      sealed_at: '2026-11-18T09:30:00.000Z',
      result: 'abstained_correctly',
      net_return_pct: 0,
      cause: 'analysis',
    },
    {
      id: 'adv_seed_5',
      symbol: 'FWRY',
      kind: 'plan',
      text_ar: 'جهزت لك خطة على سهم FWRY: دخول قرب 8.95، وقف الخسارة 8.45، هدف أول 9.65. حجم الصفقة 8% من محفظتك بس. توافق؟',
      confidence: 0.62,
      agreement: 0.69,
      sealed_at: '2026-11-19T09:25:00.000Z',
      result: 'loss',
      net_return_pct: -5.93,
      cause: 'execution',
    },
  ];

  let prevHash = 'GENESIS_BORSAGY_EGX_V6';
  const advices: Advice[] = [];
  const outcomes: Outcome[] = [];

  for (const item of rawSeedAdvices) {
    const payload = {
      id: item.id,
      trader_id: 'trader_main',
      kind: item.kind,
      symbol: item.symbol,
      mode: 'manager',
      text_ar: item.text_ar,
      numbers: {},
      confidence: item.confidence,
      agent_agreement: item.agreement,
      claim_ids: [`clm_${item.id}`],
      sealed_at: item.sealed_at,
    };
    const sealHash = computeSealHash(payload, prevHash);

    advices.push({
      id: item.id,
      kind: item.kind,
      trader_id: 'trader_main',
      symbol: item.symbol,
      mode: 'manager',
      text_ar: item.text_ar,
      numbers: {},
      confidence: item.confidence,
      agent_agreement: item.agreement,
      data_age_seconds: 240,
      claim_ids: [`clm_${item.id}`],
      claims: [],
      red_team_ar: 'تم عرض الحجة المضادة قبل التفعيل، وتوثيق النتيجة الفعلية في السجل العلني.',
      conflict_flags: [],
      constraints_checked: [],
      disclaimer_ar: SHORT_DISCLAIMER_AR,
      as_of: item.sealed_at,
      sealed_at: item.sealed_at,
      seal_hash: sealHash,
      prev_seal_hash: prevHash,
      status: item.kind === 'abstain' ? 'abstained' : 'approved',
    });

    outcomes.push({
      advice_id: item.id,
      resolved_at: item.sealed_at,
      symbol: item.symbol,
      kind: item.kind,
      result: item.result,
      net_return_pct: item.net_return_pct,
      cause: item.cause,
      predicted_confidence: item.confidence,
    });

    prevHash = sealHash;
  }
  advices.reverse();

  // Calibration curve buckets (predicted confidence vs actual hit rate)
  const calibrations: CalibrationRow[] = [
    { agent: 'coordinator', bucket: 5, n: 32, hit_rate: 0.53, weight: 0.96, as_of: '2026-11-24' },
    { agent: 'coordinator', bucket: 6, n: 41, hit_rate: 0.63, weight: 1.0, as_of: '2026-11-24' },
    { agent: 'coordinator', bucket: 7, n: 38, hit_rate: 0.74, weight: 1.05, as_of: '2026-11-24' },
    { agent: 'coordinator', bucket: 8, n: 29, hit_rate: 0.82, weight: 1.08, as_of: '2026-11-24' },
  ];

  // Top 10 EGX Brokers (Q3 2026 data from Part 2 / Section 21 — strict TO_COLLECT for unverified fees)
  const brokers: BrokerInfo[] = [
    {
      id: 'brk_thndr',
      name_ar: 'ثاندر (Thndr)',
      name_en: 'Thndr',
      rank_q3_2026: 1,
      traded_value_bn_egp: 328.89,
      market_share_pct: 24.0,
      avg_ticket_egp: 24_007,
      share_period: 'الربع الثالث 2026 (يوليو–سبتمبر)',
      share_source: 'شوف نيوز / بيانات البورصة (3 أكتوبر 2026)',
      best_for_ar: 'المضارب الفرد والعمليات الصغيرة والمتوسطة بتجربة تطبيق سريعة',
      research_available: true,
      margin_supported: true,
      app_quality_note_ar: 'منصة رقمية متقدمة بمتوسط أمر صغير (~24 ألف ج) واشتراك شهري للباقات النشطة.',
      referral_disclosure_ar: 'لا توجد عمولة إحالة مؤثرة على الترتيب — الترتيب يخضع لمعايير التكلفة والبيانات المعلنة فقط.',
      fees: [
        {
          id: 'fee_thndr_comm',
          broker_id: 'brk_thndr',
          fee_type: 'commission',
          value: 0.1,
          unit: 'pct',
          status: 'verified',
          conditions_ar: '0.1% من قيمة الأمر + رسوم الأطراف الأخرى (بورصة + رقابة + مقاصة)',
          source_url: 'https://support.thndr.app',
          source_kind: 'official_price_list',
          verified_on: '2026-10-08',
        },
        {
          id: 'fee_thndr_min',
          broker_id: 'brk_thndr',
          fee_type: 'min_per_order',
          value: 2,
          unit: 'egp',
          status: 'verified',
          conditions_ar: 'حد أدنى 2 جنيه للأمر (وتُرد عمولة أول 50 صفقة في باقة ثندر تريدر)',
          source_url: 'https://support.thndr.app',
          source_kind: 'official_price_list',
          verified_on: '2026-10-08',
        },
      ],
    },
    {
      id: 'brk_hermes',
      name_ar: 'هيرميس للوساطة (EFG Hermes)',
      name_en: 'EFG Hermes Brokerage',
      rank_q3_2026: 2,
      traded_value_bn_egp: 118.26,
      market_share_pct: 8.6,
      avg_ticket_egp: 87_600,
      share_period: 'الربع الثالث 2026 (يوليو–سبتمبر)',
      share_source: 'جريدة المال / شوف نيوز (أكتوبر 2026)',
      best_for_ar: 'الأوامر الكبيرة والباحثين عن تقارير بحوث مؤسسية عميقة',
      research_available: true,
      margin_supported: true,
      app_quality_note_ar: 'تخدم شريحة العمليات الأكبر حجماً (متوسط العملية ~87.6 ألف ج) مع بحوث قطاعية.',
      referral_disclosure_ar: 'لا توجد أي شراكة إحالة مدفوعة؛ البيانات للعرض المحايد فقط.',
      fees: [
        {
          id: 'fee_hermes_comm',
          broker_id: 'brk_hermes',
          fee_type: 'commission',
          value: null,
          unit: 'pct',
          status: 'to_collect',
          conditions_ar: 'العمولة الرسمية غير مؤكدة رقمياً بعد — يُجمع السعر الرسمي من جدول الشركة (TO_COLLECT)',
          source_url: '',
          source_kind: 'unverified',
          verified_on: '2026-11-20',
        },
      ],
    },
    {
      id: 'brk_mubasher',
      name_ar: 'مباشر لتداول الأوراق المالية',
      name_en: 'Mubasher Trade',
      rank_q3_2026: 3,
      traded_value_bn_egp: 95.27,
      market_share_pct: 7.0,
      avg_ticket_egp: 50_142,
      share_period: 'الربع الثالث 2026 (يوليو–سبتمبر)',
      share_source: 'جريدة المال / اليوم السابع (أكتوبر 2026)',
      best_for_ar: 'المتداول النشط الباحث عن أدوات شاشات أسعار وتحليل فني متكاملة',
      research_available: true,
      margin_supported: true,
      app_quality_note_ar: 'أحد أكبر المنفذين للأفراد والمؤسسات بحصة 7% في الربع الثالث 2026.',
      referral_disclosure_ar: 'ترتيب محايد بدون مقابل.',
      fees: [
        {
          id: 'fee_mubasher_comm',
          broker_id: 'brk_mubasher',
          fee_type: 'commission',
          value: null,
          unit: 'pct',
          status: 'to_collect',
          conditions_ar: 'السعر غير مؤكد من قائمة رسمية محدثة (نطاق السوق 0.1% – 0.45% استرشادياً — TO_COLLECT)',
          source_url: '',
          source_kind: 'unverified',
          verified_on: '2026-11-20',
        },
      ],
    },
    {
      id: 'brk_alahly_pharos',
      name_ar: 'الأهلي فاروس',
      name_en: 'Al Ahly Pharos',
      rank_q3_2026: 4,
      traded_value_bn_egp: 81.58,
      market_share_pct: 6.0,
      avg_ticket_egp: 211_178,
      share_period: 'الربع الثالث 2026 (يوليو–سبتمبر)',
      share_source: 'تقارير ترتيب شركات الوساطة (أكتوبر 2026)',
      best_for_ar: 'المحافظ الكبيرة والعمليات المؤسسية ذات التذاكر العالية',
      research_available: true,
      margin_supported: true,
      app_quality_note_ar: 'أعلى متوسط قيمة عملية بين الكبار (~211 ألف ج للعملية).',
      referral_disclosure_ar: 'ترتيب محايد بدون مقابل.',
      fees: [
        {
          id: 'fee_pharos_comm',
          broker_id: 'brk_alahly_pharos',
          fee_type: 'commission',
          value: null,
          unit: 'pct',
          status: 'to_collect',
          conditions_ar: 'قائمة الأسعار الرسمية قيد الجمع والتحقق (TO_COLLECT)',
          source_url: '',
          source_kind: 'unverified',
          verified_on: '2026-11-20',
        },
      ],
    },
    {
      id: 'brk_aspire',
      name_ar: 'أسباير كابيتال',
      name_en: 'Aspire Capital',
      rank_q3_2026: 5,
      traded_value_bn_egp: 79.13,
      market_share_pct: 5.8,
      avg_ticket_egp: 64_861,
      share_period: 'الربع الثالث 2026',
      share_source: 'تقارير البورصة المنشورة (أكتوبر 2026)',
      best_for_ar: 'التداولات المتوسطة والشخصية مع دعم تنفيذي مباشر',
      research_available: false,
      margin_supported: true,
      app_quality_note_ar: 'متوسط العملية ~64.8 ألف ج في الربع الثالث 2026.',
      referral_disclosure_ar: 'ترتيب محايد بدون مقابل.',
      fees: [
        {
          id: 'fee_aspire_comm',
          broker_id: 'brk_aspire',
          fee_type: 'commission',
          value: null,
          unit: 'pct',
          status: 'to_collect',
          conditions_ar: 'قائمة الأسعار الرسمية قيد الجمع والتحقق (TO_COLLECT)',
          source_url: '',
          source_kind: 'unverified',
          verified_on: '2026-11-20',
        },
      ],
    },
    {
      id: 'brk_ostoul',
      name_ar: 'أسطول لتداول الأوراق المالية',
      name_en: 'Ostoul',
      rank_q3_2026: 6,
      traded_value_bn_egp: 75.7,
      market_share_pct: 5.5,
      avg_ticket_egp: null,
      share_period: 'الربع الثالث 2026',
      share_source: 'تقارير البورصة المنشورة (أكتوبر 2026)',
      best_for_ar: 'المضارب النشط والعمليات متوسطة الحجم',
      research_available: true,
      margin_supported: true,
      app_quality_note_ar: 'تتمتع بحضور نشط وحصة سوقية 5.5%.',
      referral_disclosure_ar: 'ترتيب محايد بدون مقابل.',
      fees: [
        {
          id: 'fee_ostoul_comm',
          broker_id: 'brk_ostoul',
          fee_type: 'commission',
          value: null,
          unit: 'pct',
          status: 'to_collect',
          conditions_ar: 'قائمة الأسعار الرسمية قيد الجمع والتحقق (TO_COLLECT)',
          source_url: '',
          source_kind: 'unverified',
          verified_on: '2026-11-20',
        },
      ],
    },
    {
      id: 'brk_beltone',
      name_ar: 'بلتون لتداول الأوراق المالية',
      name_en: 'Beltone',
      rank_q3_2026: 7,
      traded_value_bn_egp: 74.59,
      market_share_pct: 5.5,
      avg_ticket_egp: null,
      share_period: 'الربع الثالث 2026',
      share_source: 'شوف نيوز / المال (أكتوبر 2026)',
      best_for_ar: 'التداولات المؤسسية والبحثية',
      research_available: true,
      margin_supported: true,
      app_quality_note_ar: 'حصة سوقية 5.5% بقيمة تداول 74.59 مليار ج.',
      referral_disclosure_ar: 'ترتيب محايد بدون مقابل.',
      fees: [
        {
          id: 'fee_beltone_comm',
          broker_id: 'brk_beltone',
          fee_type: 'commission',
          value: null,
          unit: 'pct',
          status: 'to_collect',
          conditions_ar: 'قائمة الأسعار الرسمية قيد الجمع والتحقق (TO_COLLECT)',
          source_url: '',
          source_kind: 'unverified',
          verified_on: '2026-11-20',
        },
      ],
    },
    {
      id: 'brk_cairo',
      name_ar: 'كايرو كابيتال',
      name_en: 'Cairo Capital',
      rank_q3_2026: 8,
      traded_value_bn_egp: 70.66,
      market_share_pct: 5.2,
      avg_ticket_egp: null,
      share_period: 'الربع الثالث 2026',
      share_source: 'شوف نيوز (أكتوبر 2026)',
      best_for_ar: 'المحافظ الفردية النشطة والمتوسطة',
      research_available: false,
      margin_supported: true,
      app_quality_note_ar: 'حصة سوقية 5.2% بقيمة تداول 70.66 مليار ج.',
      referral_disclosure_ar: 'ترتيب محايد بدون مقابل.',
      fees: [
        {
          id: 'fee_cairo_comm',
          broker_id: 'brk_cairo',
          fee_type: 'commission',
          value: null,
          unit: 'pct',
          status: 'to_collect',
          conditions_ar: 'قائمة الأسعار الرسمية قيد الجمع والتحقق (TO_COLLECT)',
          source_url: '',
          source_kind: 'unverified',
          verified_on: '2026-11-20',
        },
      ],
    },
    {
      id: 'brk_cib',
      name_ar: 'التجاري الدولي للسمسرة (CI Capital)',
      name_en: 'CI Capital',
      rank_q3_2026: 9,
      traded_value_bn_egp: 68.77,
      market_share_pct: 5.0,
      avg_ticket_egp: null,
      share_period: 'الربع الثالث 2026',
      share_source: 'تقارير البورصة المنشورة (أكتوبر 2026)',
      best_for_ar: 'عملاء المؤسسات والبنوك والبحوث المتخصصة',
      research_available: true,
      margin_supported: true,
      app_quality_note_ar: 'حصة سوقية 5.0% بقيمة تداول 68.77 مليار ج.',
      referral_disclosure_ar: 'ترتيب محايد بدون مقابل.',
      fees: [
        {
          id: 'fee_ci_comm',
          broker_id: 'brk_cib',
          fee_type: 'commission',
          value: null,
          unit: 'pct',
          status: 'to_collect',
          conditions_ar: 'قائمة الأسعار الرسمية قيد الجمع والتحقق (TO_COLLECT)',
          source_url: '',
          source_kind: 'unverified',
          verified_on: '2026-11-20',
        },
      ],
    },
    {
      id: 'brk_arqaam',
      name_ar: 'أرقام لتداول الأوراق المالية',
      name_en: 'Arqaam',
      rank_q3_2026: 10,
      traded_value_bn_egp: 64.31,
      market_share_pct: 4.7,
      avg_ticket_egp: null,
      share_period: 'الربع الثالث 2026',
      share_source: 'تقارير البورصة المنشورة (أكتوبر 2026)',
      best_for_ar: 'المؤسسات والمحافظ الإقليمية',
      research_available: true,
      margin_supported: false,
      app_quality_note_ar: 'حصة سوقية 4.7% بقيمة تداول 64.31 مليار ج.',
      referral_disclosure_ar: 'ترتيب محايد بدون مقابل.',
      fees: [
        {
          id: 'fee_arqaam_comm',
          broker_id: 'brk_arqaam',
          fee_type: 'commission',
          value: null,
          unit: 'pct',
          status: 'to_collect',
          conditions_ar: 'قائمة الأسعار الرسمية قيد الجمع والتحقق (TO_COLLECT)',
          source_url: '',
          source_kind: 'unverified',
          verified_on: '2026-11-20',
        },
      ],
    },
  ];

  const reviewQueue: HumanReviewItem[] = [
    {
      id: 'rev_1',
      created_at: '2026-11-25T09:15:00.000Z',
      kind: 'disclosure_disagreement',
      subject: 'Stock:ETEL',
      summary_ar: 'تعارض رقمي بين الاستخراج الأول والثاني لصافي ربح الربع الثالث في إفصاح ETEL — بانتظار الاعتماد البشري.',
      payload: { extractor_1_net_profit_mn: 4120, extractor_2_net_profit_mn: 4210 },
      status: 'pending',
    },
    {
      id: 'rev_2',
      created_at: '2026-11-25T10:05:00.000Z',
      kind: 'broker_fee_verify',
      subject: 'brk_hermes',
      summary_ar: 'تحديث قائمة عمولات هيرميس للوساطة (TO_COLLECT) قبل تفعيل المقارنة الرقمية التفصيلية.',
      payload: { broker: 'EFG Hermes', current_status: 'to_collect' },
      status: 'pending',
    },
    {
      id: 'rev_3',
      created_at: '2026-11-25T11:20:00.000Z',
      kind: 'insider_move_flag',
      subject: 'Stock:DSPK',
      summary_ar: 'رُصد ارتفاع حجم تداول بنسبة 310% في DSPK دون إفصاح منشور — يتطلب مراجعة سياق.',
      payload: { volume_spike_pct: 310, disclosure_found: false },
      status: 'pending',
    },
  ];

  const auditLogs: AuditLogEntry[] = [
    {
      id: 1,
      actor: 'system_seed',
      action: 'CONFIG_INITIALIZED',
      subject: `config_v${INITIAL_CONFIG.version}`,
      at: INITIAL_CONFIG.updated_at,
      detail: { licence_path: INITIAL_CONFIG.licence_path },
    },
    {
      id: 2,
      actor: 'compliance_gate',
      action: 'SEAL_CHAIN_VERIFIED',
      subject: 'track_record',
      at: nowIso,
      detail: { records: advices.length, head_hash: prevHash.slice(0, 16) },
    },
  ];

  const academyLessons = [
    {
      id: 'acad_1',
      title_ar: '١. إيه هو وقف الخسارة وليه هو خط الأمان الأول؟',
      summary_ar: 'الفرق بين خسارة صغيرة محسوبة وخسارة كبيرة تخرجك من السوق. إزاي تحدد السعر قبل ما تشتري مش بعد ما السهم ينزل.',
      duration_min: 4,
      example_ar: 'مثال مصري: لو معاك 50 ألف جنيه، وخسارتك المسموحة 1.5% (750 جنيه)، ده اللي بيحدد تشتري كام سهم مش إحساسك.',
      linked_symbol: 'COMI',
    },
    {
      id: 'acad_2',
      title_ar: '٢. فخ السيولة: أسهم سهل تدخلها بس صعب تخرج منها',
      summary_ar: 'ليه متوسط التداول اليومي (ADV) ونسبة الأسهم الحرة أهم من سعر السهم الرخيص، وإزاي تحسب أيام الخروج.',
      duration_min: 5,
      example_ar: 'في أسهم في البورصة المصرية بيبقى حجم تداولها اليومي قليل جداً؛ لو دخلت بـ 100 ألف جنيه ممكن تحتاج 4 أيام عشان تبيعهم.',
      linked_symbol: 'DILQ1',
    },
    {
      id: 'acad_3',
      title_ar: '٣. التنويع الوهمي: 5 أسهم = سهم واحد!',
      summary_ar: 'لو اشتريت 5 أسهم كلهم في قطاع البنوك أو نفس المجموعة المالكة، محفظتك بتتحرك كأنها سهم واحد وقت الأزمات.',
      duration_min: 4,
      example_ar: 'لو عندك سهمين تابعين لنفس المجموعة المالكة، أي خبر عن المجموعة هيهز السهمين مع بعض.',
      linked_symbol: 'HRHO',
    },
    {
      id: 'acad_4',
      title_ar: '٤. التكلفة الحقيقية للصفقة (العمولات والرسوم)',
      summary_ar: 'الفرق بين الربح الظاهر على الشاشة والربح الصافي بعد عمولة الوسيط ورسوم البورصة والرقابة ومصر للمقاصة.',
      duration_min: 3,
      example_ar: 'المضاربة المتكررة على ربح 0.5% ممكن تاكل معظم مكسبك في العمولات والحد الأدنى للفاتورة.',
      linked_symbol: 'TMGH',
    },
  ];

  const glossary = [
    {
      term_ar: 'مضاعف الربحية (P/E)',
      term_en: 'P/E Ratio',
      simple_ar: 'بتدفع كام جنيه في السهم عشان تشتري جنيه واحد من أرباح الشركة السنوية.',
      egyptian_example_ar: 'لو سعر السهم 40 جنيه وربح السهم في السنة 5 جنيه، يبقى المضاعف 8 مرات.',
    },
    {
      term_ar: 'أيام الخروج (Exit Days)',
      term_en: 'Days to Exit',
      simple_ar: 'عدد الأيام اللي تحتاجها عشان تبيع كميتك بالكامل من غير ما تخسّف بسعر السهم.',
      egyptian_example_ar: 'لو متوسط التداول اليومي مليون جنيه، وأنت حصتك 10% في اليوم (100 ألف)، ومعاك أسهم بـ 200 ألف يبقى تحتاج يومين.',
    },
    {
      term_ar: 'الأسهم الحرة (Free Float)',
      term_en: 'Free Float',
      simple_ar: 'نسبة الأسهم المتاحة فعلياً للتداول في السوق، بعيداً عن حصص الملاك الكبار والدولة.',
      egyptian_example_ar: 'شركة أسهمها الحرة 10% بس بتكون حركتها عنيفة وسهل تتحبس فيها مقارنة بشركة أسهمها الحرة 45%.',
    },
    {
      term_ar: 'الانحراف السلوكي (Tilt)',
      term_en: 'Behavioral Tilt',
      simple_ar: 'حالة توتر أو تسرع بتخليك تفتح صفقات انتقامية بعد خسارة أو تكسر خطتك.',
      egyptian_example_ar: 'بعد خسارة في أول الجلسة تدخل 3 صفقات في ساعة واحدة عشان تعوض، فتضاعف الخسارة.',
    },
  ];

  const agentsCatalog: AgentDefinition[] = ALL_84_AGENTS.map((ag) => ({ ...ag }));

  return {
    sources,
    entities,
    facts,
    edges,
    stocks,
    traders,
    riskProfiles,
    traderStates,
    positions,
    plans,
    trades,
    advices,
    outcomes,
    calibrations,
    brokers,
    reviewQueue,
    auditLogs,
    academyLessons,
    glossary,
    agentsCatalog,
  };
}
