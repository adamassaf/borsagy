import { VersionedConfig } from './types';

export const EGX_MARKET_PACK = {
  id: 'EGX',
  country: 'EG',
  currency: 'EGP',
  language: 'ar-EG',
  calendar: {
    trading_days: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu'],
    regular_session: 'تسجيل الأوامر 08:30–10:00 · الجلسة المستمرة 10:00–14:30 (يتطلب تأكيداً دورياً)',
    ramadan: 'الجلسة المستمرة 10:00–13:30 · مزاد الإغلاق ~13:15',
    holidays_source: 'التقويم الرسمي للبورصة المصرية',
  },
  price_limits: {
    main_market_daily_pct: 20,
    temporary_halt_pct: 10,
    first_day_listing_pct: 40,
    reference_in_session: 'MVWAP',
  },
  settlement: {
    cash_equities: 'T+0 / T+1 للأسهم النشطة (تُراجع حسب القائمة الرسمية)',
    futures: 'تسوية نقدية T+1 (تحديث مارس 2026 — TO VERIFY)',
  },
  regulator: 'الهيئة العامة للرقابة المالية (FRA)',
  sharia_standards: ['AAOIFI', 'EGX_SHARIA_INDEX'] as const,
  fees_to_verify: {
    broker_commission_range_note_ar: 'نطاق السوق التقديري 0.1% – 0.45% بحد أدنى 2 ج.م للفاتورة (TO VERIFY)',
    exchange_clearing_regulator_pct: 0.000725, // ~0.0725% combined EGX + FRA + MCDR estimate (TO VERIFY)
    stamp_or_cgt_note_ar: 'تُطبق رسوم البورصة والرقابة ومصر للمقاصة والضرائب حسب اللوائح السارية',
  },
  data_notice: 'بيانات تجريبية (DEMO) للاختبار — في التشغيل الفعلي تُربط بمزود مرخص (EGID / ICE)',
};

export const INITIAL_CONFIG: VersionedConfig = {
  version: 4,
  updated_at: '2026-11-25T08:00:00.000Z',
  updated_by: 'system_seed',
  licence_path: 'PATH_B', // Sandbox/Partner demo toggleable to PATH_A in Admin
  risk_per_trade_beginner_pct: 1.0,
  risk_per_trade_standard_pct: 1.5,
  risk_per_trade_advanced_pct: 2.0,
  risk_per_trade_hard_max_pct: 3.0,
  single_stock_cap_beginner_pct: 15,
  single_stock_cap_standard_pct: 25,
  single_stock_cap_advanced_pct: 35,
  single_stock_cap_absolute_pct: 40,
  sector_cap_beginner_pct: 35,
  sector_cap_standard_pct: 45,
  sector_cap_advanced_pct: 55,
  daily_loss_limit_default_pct: 2.0,
  weekly_loss_limit_default_pct: 5.0,
  daily_loss_cap_beginner_pct: 3.0,
  weekly_loss_cap_beginner_pct: 8.0,
  cool_off_hours: 24,
  cool_off_day_loss_trigger_pct: 3.0,
  liquidity_max_adv_pct: 10,
  liquidity_max_exit_days: 2,
  liquidity_block_exit_days: 5,
  age_max_intraday_seconds: 1200, // 20 mins delayed feed + 5 min tolerance
  abstain_min_confidence: 0.55,
  abstain_min_agreement: 0.60,
  abstain_max_interval_ratio: 0.50,
  tilt_threshold: 60,
  discipline_upgrade_threshold: 0.80,
  discipline_min_trades: 20,
  crisis_index_drop_pct: 3.0,
  crisis_halted_top_stocks: 5,
  notification_budget_per_day: 5,
  trap_red_threshold: 70,
  crowding_min_active_users: 100,
  crowding_min_stock_holders: 20,
};

export const PUBLIC_SAFETY_CHARTER_10 = [
  'لا نحتفظ بأموالك، ولا نطلب كلمات مرور حسابات الوساطة أبداً.',
  'لا إعلانات ولا توصيات مدفوعة.',
  'لا يتداول فريقنا في أسهم نوصي بها.',
  'لكل توصية سجل أداء ودرجة ثقة وأدلة تستطيع مراجعتها.',
  'ننشر أخطاءنا كما ننشر نجاحنا.',
  'لا نعدك بربح، ولا نستخدم عبارات الضمان.',
  'لا نبيع بياناتك.',
  'نحترم حد الخسارة الذي تحدده أنت.',
  'لا نستخدم حيلاً لدفعك لمزيد من التداول.',
  'نحذف بياناتك متى طلبت، وبكل ما اشتق منها.',
];

export const SHORT_DISCLAIMER_AR =
  'هذه المعلومات والتحليلات أداة مساعدة لاتخاذ القرار وليست ضماناً لنتيجة ولا بديلاً عن استشارة مرخصة. التداول ينطوي على مخاطر قد تصل لخسارة جزء من رأس المال. القرار والتنفيذ مسؤوليتك.';

export const BANNED_PHRASES = [
  'مضمون',
  'ربح مضمون',
  'ربح أكيد',
  'بدون مخاطرة',
  'آمن 100%',
  '100% آمن',
  'الحل الوحيد',
  'فرصة متتكررش',
  'اشتري دلوقتي قبل ما تفوتك',
  'بلا خسارة',
  'توصيات مضمونة',
  'ذكاء أدق',
  'نعتمد على الذكاء الفائق',
  'أفضل شركة',
  'guaranteed profit',
  'risk-free',
  '100% safe',
  'the only solution',
  'sure win',
  'buy now before it is gone',
  'superintelligence',
];

export const EGYPTIAN_TEMPLATES: Record<
  string,
  { requiredSlots: string[]; template: string }
> = {
  plan_manager: {
    requiredSlots: ['stock', 'entry', 'stop', 'target1', 'size_pct'],
    template:
      'جهزت لك خطة على سهم {stock}: دخول قرب {entry}، وقف الخسارة {stop}، هدف أول {target1}. حجم الصفقة {size_pct}% من محفظتك بس. توافق؟',
  },
  signal_advisor: {
    requiredSlots: ['stock', 'level'],
    template:
      'سهم {stock} قرّب من منطقة دعم والسيولة كويسة. لو دخلت، أنسب سعر قريب من {level}. القرار ليك.',
  },
  hold_off: {
    requiredSlots: ['stock', 'reason'],
    template:
      'النهارده مفيش صفقة واضحة على {stock} تستاهل المخاطرة. السبب: {reason}. الانتظار برضه قرار سليم.',
  },
  approaching_target: {
    requiredSlots: ['stock', 'price', 'target', 'new_stop'],
    template:
      'سهم {stock} وصل {price}، قريب من هدفك {target}. تحب نرفع وقف الخسارة لـ {new_stop} عشان نأمّن جزء من المكسب؟',
  },
  stop_hit: {
    requiredSlots: ['stock', 'stop'],
    template:
      'سهم {stock} وصل لوقف الخسارة اللي اتفقنا عليه عند {stop}. الخطة بتقول نخرج، والخسارة في حدود اللي حددتها.',
  },
  impulse_guard: {
    requiredSlots: ['action'],
    template:
      'لاحظت إنك عايز {action} بعد حركة حادة. قبل ما تنفذ: ده كان في خطتك؟ تحب نراجع الأسباب سوا؟',
  },
  limit_reached: {
    requiredSlots: ['limit_type', 'break_hours'],
    template:
      'وصلت لحد الخسارة اللي حددته ({limit_type}). هوقف الإشارات الجديدة، وأقترح استراحة {break_hours} ساعة قبل أي قرار.',
  },
  concentration_reject: {
    requiredSlots: ['stock', 'current_share', 'cap'],
    template:
      'الصفقة دي هتخلّي {current_share}% من محفظتك في {stock}، وده أعلى من حدك ({cap}%). مقدرش أوصي بالحجم ده، تحب نشوف حجم أصغر؟',
  },
  crisis_calm: {
    requiredSlots: ['event_summary'],
    template:
      'السوق متحرك بشدة النهارده ({event_summary}). مش لازم تتحرك دلوقتي. بلاش قرارات سريعة، وراجع خطتك ومراكزك بهدوء.',
  },
  stale_data: {
    requiredSlots: ['stock', 'age_mins'],
    template:
      'بيانات {stock} متأخرة ({age_mins} دقيقة) فأوقفت الإشارة لحد ما تتحدث. مش هقترح حاجة على بيانات قديمة.',
  },
};

export const ALTERNATIVE_BENCHMARKS = [
  { id: 'egx30', name_ar: 'مؤشر EGX30', annual_return_pct: 24.5, risk_ar: 'عالي (أسهم)' },
  { id: 'certs', name_ar: 'شهادات الادخار البنكية', annual_return_pct: 22.0, risk_ar: 'منخفض (ثابت)' },
  { id: 'tbills', name_ar: 'أذون الخزانة (بعد الضريبة)', annual_return_pct: 21.4, risk_ar: 'منخفض جداً' },
  { id: 'inflation', name_ar: 'معدل التضخم السنوي (مرجعي)', annual_return_pct: 26.2, risk_ar: 'تآكل القوة الشرائية' },
  { id: 'usd', name_ar: 'الدولار الأمريكي (مقابل الجنيه)', annual_return_pct: 12.8, risk_ar: 'متوسط (عملة)' },
  { id: 'gold', name_ar: 'الذهب المحلي عيار 21', annual_return_pct: 29.5, risk_ar: 'متوسط (تحوط)' },
];
