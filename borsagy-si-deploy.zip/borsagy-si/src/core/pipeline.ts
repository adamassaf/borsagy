import { compileHardConstraints, detectAgentConflicts } from './constraints';
import {
  calculateStockQualityScore,
  calculateTrapScore,
  runPointInTimeBacktest,
} from './deterministicServices';
import { EGYPTIAN_TEMPLATES, SHORT_DISCLAIMER_AR } from './marketPack';
import {
  Advice,
  AdviceKind,
  Claim,
  Edge,
  EvidenceRef,
  Fact,
  KillSwitches,
  PlanDraft,
  Position,
  RiskProfile,
  Source,
  StockSummary,
  TraderState,
  VersionedConfig,
} from './types';
import {
  checkComplianceCopy,
  computeSealHash,
  fillTemplateStrict,
  queryFactsAsOf,
  validateClaim,
} from './validators';

export interface AdviseInput {
  trader_id: string;
  symbol: string;
  as_of: string;
  stock: StockSummary;
  facts: Fact[];
  sources: Map<string, Source>;
  edges: Edge[];
  profile: RiskProfile;
  traderState: TraderState;
  positions: Position[];
  config: VersionedConfig;
  killSwitches: KillSwitches;
  agentWeights: Record<string, number>;
  prevSealHash: string;
  marketIndexDropPct: number;
  haltedTopStocksCount: number;
  requestedSizePct?: number;
  optionalComposeFn?: (params: {
    kind: AdviceKind;
    slots: Record<string, string | number>;
    templateText: string;
    mode: 'manager' | 'advisor';
  }) => Promise<string | null>;
}

export interface WhyLevelResponse {
  level: 1 | 2 | 3;
  advice_id: string;
  summary_ar: string;
  agreement_pct: number;
  confidence_pct: number;
  data_age_seconds: number;
  conflict_flags: string[];
  red_team_ar?: string;
  evidence_list?: Array<{
    fact_id: string;
    label_ar: string;
    value: string | number;
    source_name: string;
    valid_from: string;
    known_at: string;
  }>;
  full_chain?: {
    as_of: string;
    seal_hash: string;
    prev_seal_hash: string;
    constraints: Advice['constraints_checked'];
    claims: Claim[];
  };
}

export async function runAdvicePipeline(input: AdviseInput): Promise<Advice> {
  const {
    trader_id,
    symbol,
    as_of,
    stock,
    facts,
    sources,
    edges,
    profile,
    traderState,
    positions,
    config,
    killSwitches,
    agentWeights,
    prevSealHash,
    marketIndexDropPct,
    haltedTopStocksCount,
    requestedSizePct,
    optionalComposeFn,
  } = input;

  // Step 1-2: Bitemporal snapshot at as_of + entity facts
  const factsById = new Map<string, Fact>();
  for (const f of facts) {
    if (Date.parse(f.known_at) <= Date.parse(as_of)) {
      factsById.set(f.id, f);
    }
  }
  const stockFacts = queryFactsAsOf(facts, as_of, stock.id);

  // Step 3-4: Build DecisionFrame & Compile Hard Constraints FIRST
  const entry = stock.price;
  const stop = Number((entry * 0.95).toFixed(2));
  const target1 = Number((entry * 1.08).toFixed(2));
  const target2 = Number((entry * 1.14).toFixed(2));

  const space = compileHardConstraints({
    stock,
    profile,
    traderState,
    positions,
    edges,
    config,
    killSwitches,
    marketIndexDropPct,
    haltedTopStocksCount,
    requestedSizePct,
    proposedEntry: entry,
    proposedStop: stop,
  });

  const mode = traderState.active_mode;
  const adviceId = `adv_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;

  const makeFactRef = (
    fact: Fact | undefined,
    label_ar: string,
    value: number | string,
    useFactValueDirectly = false
  ): EvidenceRef => {
    const src = fact ? sources.get(fact.source_id) : undefined;
    return {
      fact_id: fact?.id ?? `fact_synthetic_${stock.symbol}`,
      label_ar,
      value: useFactValueDirectly && fact?.value !== undefined ? (fact.value as number | string) : value,
      source_name: src?.name ?? 'بيانات السوق (DEMO)',
      valid_from: fact?.valid_from ?? stock.last_updated,
      known_at: fact?.known_at ?? as_of,
      display_licence: src?.licence ?? 'displayable',
    };
  };

  const priceFact = stockFacts.find((f) => f.predicate === 'last_price') ?? stockFacts[0];
  const advFact = stockFacts.find((f) => f.predicate === 'adv_30d') ?? priceFact;
  const peFact = stockFacts.find((f) => f.predicate === 'pe_ratio') ?? priceFact;
  const rsiFact = stockFacts.find((f) => f.predicate === 'rsi_14') ?? priceFact;

  // Helper to seal and return
  const finalizeAdvice = (params: {
    kind: AdviceKind;
    textAr: string;
    numbers: Record<string, EvidenceRef>;
    confidence: number;
    agreement: number;
    claims: Claim[];
    planDraft?: PlanDraft | null;
    redTeamAr?: string;
    conflictFlags: string[];
    status: Advice['status'];
  }): Advice => {
    // Compliance gate: check banned phrases + untraced numbers + max 3 sentences + disclaimer
    const compliance = checkComplianceCopy(params.textAr, params.numbers, {
      maxSentences: 3,
      requireDisclaimer: true,
      disclaimerText: SHORT_DISCLAIMER_AR,
    });

    let safeText = params.textAr;
    let finalStatus = params.status;

    if (!compliance.ok) {
      // Deterministic safe fallback (never emit non-compliant text)
      safeText = `تم إيقاف صياغة النص لأن مراجعة الامتثال رصدت ملاحظة (${compliance.errors.join(', ')}). الانتظار ومراجعة الأرقام الأصلية قرار أسلم.`;
      finalStatus = 'blocked';
    }

    const sealedAt = new Date().toISOString();
    const sealPayload = {
      id: adviceId,
      trader_id,
      kind: params.kind,
      symbol,
      mode,
      text_ar: safeText,
      numbers: params.numbers,
      confidence: params.confidence,
      agent_agreement: params.agreement,
      claim_ids: params.claims.map((c) => c.id),
      sealed_at: sealedAt,
    };
    const sealHash = computeSealHash(sealPayload, prevSealHash);

    return {
      id: adviceId,
      kind: params.kind,
      trader_id,
      symbol,
      mode,
      text_ar: safeText,
      numbers: params.numbers,
      confidence: params.confidence,
      agent_agreement: params.agreement,
      data_age_seconds: stock.data_age_seconds,
      claim_ids: params.claims.map((c) => c.id),
      claims: params.claims,
      plan_draft: params.planDraft ?? null,
      red_team_ar: params.redTeamAr,
      conflict_flags: params.conflictFlags,
      constraints_checked: space.verdicts,
      disclaimer_ar: SHORT_DISCLAIMER_AR,
      as_of,
      sealed_at: sealedAt,
      seal_hash: sealHash,
      prev_seal_hash: prevSealHash,
      status: finalStatus,
    };
  };

  // Early veto branches (Crisis / HALT / Stale / Licence / Concentration)
  if (space.crisis) {
    const summary = `تراجع المؤشر ${Math.abs(marketIndexDropPct)}%`;
    const numbers: Record<string, EvidenceRef> = {
      drop_pct: makeFactRef(priceFact, 'نسبة تحرك المؤشر', Math.abs(marketIndexDropPct)),
    };
    const text = fillTemplateStrict(EGYPTIAN_TEMPLATES.crisis_calm.template, {
      event_summary: summary,
    }).text;
    return finalizeAdvice({
      kind: 'calm_down',
      textAr: text,
      numbers,
      confidence: 0.9,
      agreement: 1,
      claims: [],
      conflictFlags: [],
      status: 'abstained',
    });
  }

  if (space.halted) {
    const breakHours = config.cool_off_hours;
    const limitType =
      traderState.day_pnl_pct <= -profile.daily_loss_limit_pct ? 'الحد اليومي' : 'الحد الأسبوعي';
    const numbers: Record<string, EvidenceRef> = {
      break_hours: makeFactRef(priceFact, 'ساعات الاستراحة', breakHours),
    };
    const text = fillTemplateStrict(EGYPTIAN_TEMPLATES.limit_reached.template, {
      limit_type: limitType,
      break_hours: breakHours,
    }).text;
    return finalizeAdvice({
      kind: 'calm_down',
      textAr: text,
      numbers,
      confidence: 0.95,
      agreement: 1,
      claims: [],
      conflictFlags: [],
      status: 'abstained',
    });
  }

  if (space.empty) {
    const ageMins = Math.round(stock.data_age_seconds / 60);
    const isStale = stock.data_age_seconds > config.age_max_intraday_seconds;
    if (isStale) {
      const numbers: Record<string, EvidenceRef> = {
        age_mins: makeFactRef(priceFact, 'عمر البيانات بالدقائق', ageMins),
      };
      const text = fillTemplateStrict(EGYPTIAN_TEMPLATES.stale_data.template, {
        stock: stock.symbol,
        age_mins: ageMins,
      }).text;
      return finalizeAdvice({
        kind: 'abstain',
        textAr: text,
        numbers,
        confidence: 0,
        agreement: 1,
        claims: [],
        conflictFlags: [],
        status: 'abstained',
      });
    }

    const reason = space.abstainReasons[0] ?? 'القيود لا تسمح بدخول آمن حالياً';
    const text = fillTemplateStrict(EGYPTIAN_TEMPLATES.hold_off.template, {
      stock: stock.symbol,
      reason,
    }).text;
    return finalizeAdvice({
      kind: space.licenceBlocked ? 'alternative' : 'abstain',
      textAr: text,
      numbers: {},
      confidence: 0.85,
      agreement: 1,
      claims: [],
      conflictFlags: [],
      status: 'abstained',
    });
  }

  // Step 5-6: Run parallel specialist agents and validate every Claim
  const quality = calculateStockQualityScore(stock, facts, as_of, config);
  const trap = calculateTrapScore(stock, space.maxAllowedQty, config);
  const pitBacktest = runPointInTimeBacktest(stock.bars, as_of, config, profile.portfolio_size_egp);

  const rawClaims: Claim[] = [];

  if (!killSwitches.disabled_agents.includes('fundamental') && quality.fundamental !== null) {
    rawClaims.push({
      id: `clm_fund_${adviceId}`,
      agent: 'fundamental',
      subject: stock.id,
      predicate: 'fundamental_score',
      value: quality.fundamental,
      interval: [Math.max(0, quality.fundamental - 8), Math.min(100, quality.fundamental + 8)],
      confidence: 0.78,
      calibration_version: 'cal-v1',
      model_version: 'fund-det-1.2',
      evidence: [peFact?.id ?? stockFacts[0]?.id ?? 'fact_missing'].filter(Boolean),
      valid_from: stock.last_updated,
      valid_to: new Date(Date.parse(as_of) + 24 * 3600_000).toISOString(),
      known_at: as_of,
      data_age_seconds: stock.data_age_seconds,
      display_licence: 'displayable',
    });
  }

  if (!killSwitches.disabled_agents.includes('technical') && quality.technical !== null) {
    rawClaims.push({
      id: `clm_tech_${adviceId}`,
      agent: 'technical',
      subject: stock.id,
      predicate: 'technical_score',
      value: quality.technical,
      interval: [Math.max(0, quality.technical - 10), Math.min(100, quality.technical + 10)],
      confidence: 0.72,
      calibration_version: 'cal-v1',
      model_version: 'tech-det-1.1',
      evidence: [rsiFact?.id ?? stockFacts[0]?.id ?? 'fact_missing'].filter(Boolean),
      valid_from: stock.last_updated,
      valid_to: new Date(Date.parse(as_of) + 4 * 3600_000).toISOString(),
      known_at: as_of,
      data_age_seconds: stock.data_age_seconds,
      display_licence: 'displayable',
    });
  }

  if (!killSwitches.disabled_agents.includes('liquidity')) {
    rawClaims.push({
      id: `clm_liq_${adviceId}`,
      agent: 'liquidity',
      subject: stock.id,
      predicate: 'exit_days',
      value: trap.exit_days,
      interval: [Math.max(0.1, Number((trap.exit_days * 0.75).toFixed(2))), Number((trap.exit_days * 1.35).toFixed(2))],
      confidence: 0.84,
      calibration_version: 'cal-v1',
      model_version: 'liq-det-1.3',
      evidence: [advFact?.id ?? stockFacts[0]?.id ?? 'fact_missing'].filter(Boolean),
      valid_from: stock.last_updated,
      valid_to: new Date(Date.parse(as_of) + 6 * 3600_000).toISOString(),
      known_at: as_of,
      data_age_seconds: stock.data_age_seconds,
      display_licence: 'displayable',
    });
  }

  if (!killSwitches.disabled_agents.includes('macro')) {
    const macroEdges = edges.filter((e) => e.src === stock.sector_id && e.rel === 'affected_by');
    const macroScore = macroEdges.length > 0 ? 64 : 58;
    rawClaims.push({
      id: `clm_macro_${adviceId}`,
      agent: 'macro',
      subject: stock.id,
      predicate: 'macro_score',
      value: macroScore,
      interval: [macroScore - 12, macroScore + 12],
      confidence: 0.66,
      calibration_version: 'cal-v1',
      model_version: 'macro-graph-1.0',
      evidence: [priceFact?.id ?? stockFacts[0]?.id ?? 'fact_missing'].filter(Boolean),
      valid_from: stock.last_updated,
      valid_to: new Date(Date.parse(as_of) + 24 * 3600_000).toISOString(),
      known_at: as_of,
      data_age_seconds: stock.data_age_seconds,
      display_licence: 'displayable',
    });
  }

  // Validate all claims strictly through ontology validator
  const validClaims = rawClaims.filter((c) => validateClaim(c, factsById).ok);

  // Step 7-8: Aggregate with calibration weights + detect conflict
  const conflict = detectAgentConflicts(validClaims);
  const scoredClaims = validClaims.filter((c) => typeof c.value === 'number' && c.predicate.endsWith('_score'));

  let weightedSum = 0;
  let weightDenom = 0;
  for (const c of scoredClaims) {
    const w = agentWeights[c.agent] ?? 1.0;
    weightedSum += w * c.confidence * Number(c.value);
    weightDenom += w * c.confidence;
  }
  const unifiedScore = weightDenom > 0 ? Math.round(weightedSum / weightDenom) : 0;
  const avgConfidence =
    validClaims.length > 0
      ? Number((validClaims.reduce((s, c) => s + c.confidence, 0) / validClaims.length).toFixed(2))
      : 0;

  // Step 9: Abstention gate (weak confidence, low agreement, or wide uncertainty interval)
  const weakBacktest = pitBacktest.ok && pitBacktest.net_return_pct < -8;
  if (
    validClaims.length < 2 ||
    avgConfidence < config.abstain_min_confidence ||
    conflict.agreementScore < config.abstain_min_agreement ||
    unifiedScore < 55 ||
    weakBacktest
  ) {
    const reason =
      conflict.hasConflict
        ? 'تضارب إشارات الوكلاء التحليليين، فالأفضل عدم الدخول الآن'
        : unifiedScore < 55
          ? `الدرجة الموحدة للسهم (${unifiedScore}/100) أقل من مستوى الثقة المطلوب`
          : 'الأدلة الحالية غير كافية لاتخاذ قرار دخول';
    const numbers: Record<string, EvidenceRef> = {
      score: makeFactRef(priceFact, 'الدرجة الموحدة', unifiedScore),
    };
    const text = fillTemplateStrict(EGYPTIAN_TEMPLATES.hold_off.template, {
      stock: stock.symbol,
      reason,
    }).text;

    return finalizeAdvice({
      kind: 'abstain',
      textAr: text,
      numbers,
      confidence: avgConfidence,
      agreement: conflict.agreementScore,
      claims: validClaims,
      redTeamAr: conflict.hasConflict
        ? `محامي الشيطان: ${conflict.conflictFlags[0]}؛ التريث يحمي رأس المال من إشارة متناقضة.`
        : `محامي الشيطان: الاختبار التاريخي أو الزخم الحالي لا يدعمان مخاطرة إضافية على ${stock.symbol}.`,
      conflictFlags: conflict.conflictFlags,
      status: 'abstained',
    });
  }

  // Step 10: Red Team (Devil's Advocate) — always present strongest counter-argument in 2 sentences
  const redTeamNotes: string[] = [];
  if (space.hiddenConcentrationFlag && space.hiddenConcentrationDetailAr) {
    redTeamNotes.push(space.hiddenConcentrationDetailAr);
  }
  if (stock.pe > 16) {
    redTeamNotes.push(`مضاعف ربحية السهم (${stock.pe} مرة) مرتفع نسبياً مما يزيد حساسية السهم لأي نتائج أضعف من المتوقع.`);
  } else if (stock.rsi_14 > 65) {
    redTeamNotes.push(`مؤشر القوة النسبية (${stock.rsi_14}) قريب من التشبع الشرائي، وقد يحدث جني أرباح قصير الأجل.`);
  } else {
    redTeamNotes.push(`أداء السهم في الاختبار التاريخي حقق عائداً صافياً ${pitBacktest.net_return_pct}% بحد أقصى للهبوط ${pitBacktest.max_drawdown_pct}%، والماضي لا يضمن المستقبل.`);
  }
  const redTeamAr = redTeamNotes.slice(0, 2).join(' ');

  // Step 11-12: Build PlanDraft & Compose Egyptian-dialect 3-sentence message using ONLY evidence-linked numbers
  const planDraft: PlanDraft = {
    symbol: stock.symbol,
    stock_name_ar: stock.name_ar,
    entry,
    stop,
    targets: [target1, target2],
    size_pct: space.maxAllowedPct,
    size_egp: space.maxAllowedEgp,
    qty: space.maxAllowedQty,
    max_loss_egp: Number(((entry - stop) * space.maxAllowedQty).toFixed(2)),
    exit_days: trap.exit_days,
  };

  const kind: AdviceKind = mode === 'manager' ? 'plan' : 'signal';
  const slots: Record<string, string | number> =
    mode === 'manager'
      ? {
          stock: stock.symbol,
          entry: planDraft.entry,
          stop: planDraft.stop,
          target1: planDraft.targets[0],
          size_pct: planDraft.size_pct,
        }
      : {
          stock: stock.symbol,
          level: planDraft.entry,
        };

  const numbers: Record<string, EvidenceRef> = {
    entry: makeFactRef(priceFact, 'سعر الدخول المرجعي', planDraft.entry),
    ...(mode === 'manager'
      ? {
          stop: makeFactRef(priceFact, 'سعر وقف الخسارة المحسوب', planDraft.stop),
          target1: makeFactRef(priceFact, 'الهدف الأول المحسوب', planDraft.targets[0]),
          size_pct: makeFactRef(advFact, 'نسبة حجم الصفقة من المحفظة', planDraft.size_pct),
        }
      : {}),
  };

  const templateStr =
    mode === 'manager' ? EGYPTIAN_TEMPLATES.plan_manager.template : EGYPTIAN_TEMPLATES.signal_advisor.template;
  let composedText = fillTemplateStrict(templateStr, slots).text;

  // Optional Gemini phrasing enhancement (strictly slot-injected, validated immediately)
  if (optionalComposeFn) {
    try {
      const llmText = await optionalComposeFn({
        kind,
        slots,
        templateText: composedText,
        mode,
      });
      if (llmText) {
        const testGate = checkComplianceCopy(llmText, numbers, {
          maxSentences: 3,
          requireDisclaimer: true,
          disclaimerText: SHORT_DISCLAIMER_AR,
        });
        if (testGate.ok) {
          composedText = llmText;
        }
      }
    } catch {
      // Fallback cleanly to deterministic Egyptian template
    }
  }

  return finalizeAdvice({
    kind,
    textAr: composedText,
    numbers,
    confidence: avgConfidence,
    agreement: conflict.agreementScore,
    claims: validClaims,
    planDraft,
    redTeamAr,
    conflictFlags: conflict.conflictFlags,
    status: 'active',
  });
}

export function getWhyChain(
  advice: Advice,
  level: 1 | 2 | 3,
  sources: Map<string, Source>
): WhyLevelResponse {
  const base: WhyLevelResponse = {
    level,
    advice_id: advice.id,
    summary_ar:
      advice.kind === 'abstain' || advice.kind === 'calm_down'
        ? 'تم تغليب الحماية والامتناع بناءً على قواعد المخاطر والبيانات قبل أي اقتراح.'
        : `النتيجة مبنية على ${advice.claims.length} وكلاء متخصصين بدرجة اتفاق ${Math.round(advice.agent_agreement * 100)}% وثقة ${Math.round(advice.confidence * 100)}%.`,
    agreement_pct: Math.round(advice.agent_agreement * 100),
    confidence_pct: Math.round(advice.confidence * 100),
    data_age_seconds: advice.data_age_seconds,
    conflict_flags: advice.conflict_flags,
    red_team_ar: advice.red_team_ar,
  };

  if (level === 1) return base;

  const evidence_list = Object.values(advice.numbers).map((ref) => ({
    fact_id: ref.fact_id,
    label_ar: ref.label_ar,
    value: ref.value,
    source_name: ref.source_name,
    valid_from: ref.valid_from,
    known_at: ref.known_at,
  }));

  if (level === 2) {
    return { ...base, evidence_list };
  }

  // Level 3: full chain including constraints and bitemporal claims
  const enrichedClaims = advice.claims.map((c) => ({
    ...c,
    source_names: c.evidence.map((fid) => sources.get(fid)?.name ?? 'مصدر أنطولوجيا'),
  }));

  return {
    ...base,
    evidence_list,
    full_chain: {
      as_of: advice.as_of,
      seal_hash: advice.seal_hash,
      prev_seal_hash: advice.prev_seal_hash,
      constraints: advice.constraints_checked,
      claims: enrichedClaims,
    },
  };
}
