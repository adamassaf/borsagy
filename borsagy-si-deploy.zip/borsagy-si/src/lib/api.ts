import {
  Advice,
  AgentDefinition,
  AgentGroupKey,
  AuditLogEntry,
  BillingCycle,
  BrokerInfo,
  CalibrationRow,
  Fact,
  HumanReviewItem,
  KillSwitches,
  LiveFeedStatus,
  Outcome,
  Plan,
  Position,
  QualityScoreBreakdown,
  RiskProfile,
  StockSummary,
  SubscriptionPlan,
  SubscriptionTierId,
  Trade,
  Trader,
  TraderState,
  TrapScoreBreakdown,
  VersionedConfig,
} from '../core/types';

export interface WhyChainResponse {
  level: 1 | 2 | 3;
  advice_id: string;
  summary_ar: string;
  agreement_pct: number;
  confidence_pct: number;
  data_age_seconds: number;
  conflict_flags: string[];
  red_team_ar?: string;
  evidence_list?: Array<{
    fact_id: string;
    label_ar: string;
    value: string | number;
    source_name: string;
    valid_from: string;
    known_at: string;
  }>;
  full_chain?: {
    as_of: string;
    seal_hash: string;
    prev_seal_hash: string;
    constraints: Advice['constraints_checked'];
    claims: Array<Advice['claims'][number] & { source_names?: string[] }>;
  };
}

async function requestJson<T>(url: string, options: RequestInit = {}, traderId?: string, adminToken?: string): Promise<T> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...((options.headers as Record<string, string>) ?? {}),
  };
  if (traderId) {
    headers['x-trader-id'] = traderId;
  }
  if (adminToken) {
    headers['Authorization'] = `Bearer ${adminToken}`;
  }
  const res = await fetch(url, { ...options, headers });
  const text = await res.text();
  let data: unknown = {};
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    throw new Error('استجابة غير صالحة من الخادم.');
  }
  if (!res.ok) {
    const errMsg = (data as { error?: string })?.error ?? `خطأ من الخادم (${res.status})`;
    throw new Error(errMsg);
  }
  return data as T;
}

export const api = {
  getHealth: () =>
    requestJson<{
      ok: boolean;
      domain?: string;
      config_version: number;
      licence_path: string;
      total_agents?: number;
      live_feed_status?: LiveFeedStatus;
      kill_switches: KillSwitches;
      market_pack: Record<string, unknown>;
    }>('/api/health'),
  getPersonas: () => requestJson<{ personas: Array<{ trader: Trader; profile: RiskProfile; traderState: TraderState }> }>('/api/personas'),
  getAgents: (params: { group?: string; tier?: string; q?: string }, traderId?: string) => {
    const qs = new URLSearchParams();
    if (params.group) qs.set('group', params.group);
    if (params.tier) qs.set('tier', params.tier);
    if (params.q) qs.set('q', params.q);
    return requestJson<{
      total_agents: number;
      filtered_count: number;
      active_tier: SubscriptionTierId;
      groups: Array<{ key: AgentGroupKey; code_ar: string; title_ar: string; range_label: string }>;
      agents: Array<AgentDefinition & { unlocked: boolean }>;
      disclaimer_ar: string;
    }>(`/api/agents?${qs.toString()}`, {}, traderId);
  },
  runAgent: (agentId: string | number, symbol: string, traderId?: string) =>
    requestJson<{
      agent: AgentDefinition;
      symbol: string;
      as_of: string;
      headline_ar: string;
      summary_ar: string;
      verdict_ar: string;
      metrics: Array<{ label_ar: string; value: string; source_fact_id: string }>;
      cited_fact_ids: string[];
      usage_guide: {
        purpose_ar: string;
        how_it_works_ar: string;
        steps_ar: string[];
        example_ar: string;
        caution_ar: string;
        related_route?: {
          route: 'market' | 'stock' | 'portfolio' | 'discipline' | 'brokers' | 'track_record' | 'academy' | 'onboarding' | 'admin' | 'home';
          label_ar: string;
        };
      };
      disclaimer_ar: string;
    }>(`/api/agents/${encodeURIComponent(String(agentId))}/run`, { method: 'POST', body: JSON.stringify({ symbol }) }, traderId),
  askAgentCopilot: (
    agentId: string | number,
    payload: { symbol: string; question: string; history?: Array<{ role: 'user' | 'assistant'; text: string }> },
    traderId?: string
  ) =>
    requestJson<{
      agent: AgentDefinition;
      symbol: string;
      execution: Awaited<ReturnType<typeof api.runAgent>>;
      used_ai: boolean;
      answer_ar: string;
      suggested_questions_ar: string[];
      disclaimer_ar: string;
      ai_error?: string;
    }>(`/api/agents/${encodeURIComponent(String(agentId))}/copilot`, { method: 'POST', body: JSON.stringify(payload) }, traderId),
  getSubscriptions: (traderId?: string) =>
    requestJson<{
      plans: SubscriptionPlan[];
      active_tier: SubscriptionTierId;
      billing_cycle: BillingCycle;
      agent_counts_by_tier: Record<SubscriptionTierId, number>;
      disclaimer_ar: string;
    }>('/api/subscriptions', {}, traderId),
  selectSubscription: (tier: SubscriptionTierId, billing_cycle: BillingCycle, traderId?: string) =>
    requestJson<{
      ok: boolean;
      trader: Trader;
      active_tier: SubscriptionTierId;
      billing_cycle: BillingCycle;
      unlocked_agents_count: number;
    }>('/api/subscription/select', { method: 'POST', body: JSON.stringify({ tier, billing_cycle }) }, traderId),
  refreshLiveMarket: () =>
    requestJson<{ ok: boolean; live_feed_status: LiveFeedStatus }>('/api/market/refresh', { method: 'POST' }),
  submitOnboarding: (payload: Record<string, unknown>, traderId: string) =>
    requestJson<{ ok: boolean; trader: Trader; profile: RiskProfile; traderState: TraderState; charter: string[]; disclaimer_ar: string }>(
      '/api/onboarding',
      { method: 'POST', body: JSON.stringify(payload) },
      traderId
    ),
  getMovers: (params: { timeframe?: string; sector?: string; sharia?: boolean; q?: string }) => {
    const qs = new URLSearchParams();
    if (params.timeframe) qs.set('timeframe', params.timeframe);
    if (params.sector) qs.set('sector', params.sector);
    if (params.sharia) qs.set('sharia', 'true');
    if (params.q) qs.set('q', params.q);
    return requestJson<{
      timeframe: string;
      is_demo: boolean;
      live_feed_status?: LiveFeedStatus;
      data_notice: string;
      fear_greed: { score: number; label_ar: string; factors_ar: string[] };
      gainers: StockSummary[];
      losers: StockSummary[];
      most_active: StockSummary[];
      sector_heatmap: Array<{ sector_id: string; sector_ar: string; count: number; avgChange: number; totalAdv: number }>;
      stocks: Array<Omit<StockSummary, 'bars'>>;
      disclaimer_ar: string;
    }>(`/api/market/movers?${qs.toString()}`);
  },
  getStockDetail: (symbol: string) =>
    requestJson<{
      stock: StockSummary;
      quality: QualityScoreBreakdown;
      trap: TrapScoreBreakdown;
      sharia: { compliant: boolean; non_halal_pct: number; purification_per_share_egp: number; total_purification_egp: number; zakat_estimate_egp: number; note_ar: string };
      backtest: { ok: boolean; net_return_pct: number; max_drawdown_pct: number; trades_count: number; win_rate_pct: number; total_fees_egp: number; note_ar: string; error_ar?: string };
      is_blocked: boolean;
      disclaimer_ar: string;
    }>(`/api/stocks/${encodeURIComponent(symbol)}`),
  extractDisclosure: (symbol: string, text: string) =>
    requestJson<{
      used_ai: boolean;
      event_type: string;
      direction: 'positive' | 'negative' | 'neutral';
      summary_ar: string;
      key_points_ar: string[];
      requires_human_review: boolean;
      disclaimer_ar: string;
    }>(`/api/stocks/${encodeURIComponent(symbol)}/disclosure-extract`, {
      method: 'POST',
      body: JSON.stringify({ text }),
    }),
  requestAdvice: (symbol: string, traderId: string, requestedSizePct?: number) =>
    requestJson<{ advice: Advice; disclaimer_ar: string }>(
      '/api/advice',
      { method: 'POST', body: JSON.stringify({ symbol, requested_size_pct: requestedSizePct }) },
      traderId
    ),
  getAdvice: (id: string) => requestJson<{ advice: Advice; stock_name_ar: string; disclaimer_ar: string }>(`/api/advice/${encodeURIComponent(id)}`),
  getAdviceWhy: (id: string, level: 1 | 2 | 3) => requestJson<WhyChainResponse>(`/api/advice/${encodeURIComponent(id)}/why?level=${level}`),
  dismissAdvice: (id: string) => requestJson<{ ok: boolean; advice: Advice }>(`/api/advice/${encodeURIComponent(id)}/dismiss`, { method: 'POST' }),
  createPlan: (payload: Record<string, unknown>, traderId: string) =>
    requestJson<{ ok: boolean; plan: Plan; position?: Position }>('/api/plans', { method: 'POST', body: JSON.stringify(payload) }, traderId),
  closeTrade: (positionId: string, payload: Record<string, unknown>, traderId: string) =>
    requestJson<{ ok: boolean; trade: Trade; traderState: TraderState }>(
      `/api/trades/${encodeURIComponent(positionId)}/close`,
      { method: 'POST', body: JSON.stringify(payload) },
      traderId
    ),
  getPortfolioRisk: (traderId: string) =>
    requestJson<{
      trader: Trader;
      profile: RiskProfile;
      traderState: TraderState;
      positions: Position[];
      plans: Plan[];
      trades: Trade[];
      recentAdvices: Advice[];
      metrics: {
        total_market_value_egp: number;
        total_cost_egp: number;
        unrealized_pnl_egp: number;
        unrealized_pnl_pct: number;
        top_stock_symbol: string;
        top_stock_pct: number;
        top_sector_ar: string;
        top_sector_pct: number;
        hidden_group_warning_ar: string | null;
        risk_meter_1_to_5: 1 | 2 | 3 | 4 | 5;
        risk_label_ar: string;
        portfolio_move_reasons_ar: string[];
      };
      net_realized_egp: number;
      rule_break_cost_egp: number;
      remaining_alert_budget: number;
      benchmarks: Array<{ id: string; name_ar: string; annual_return_pct: number; risk_ar: string }>;
      disclaimer_ar: string;
    }>('/api/portfolio/risk', {}, traderId),
  importStatement: (payload: { csv_or_text: string; consent_acknowledged: boolean; auto_delete_raw: boolean }, traderId: string) =>
    requestJson<{ ok: boolean; imported_count: number; skipped_count: number; raw_deleted: boolean; note_ar: string }>(
      '/api/portfolio/statement',
      { method: 'POST', body: JSON.stringify(payload) },
      traderId
    ),
  getTrackRecord: () =>
    requestJson<{
      seal_verification: { valid: boolean; total: number; brokenIds: string[] };
      summary: { total_outcomes: number; wins: number; losses: number; abstained_correctly: number; win_rate_pct: number };
      calibration_curve: Array<{ bucket_label: string; predicted_mid: number; actual_hit_pct: number; sample_size: number }>;
      advices: Advice[];
      outcomes: Outcome[];
      charter: string[];
      disclaimer_ar: string;
    }>('/api/track-record'),
  updateSettings: (payload: Record<string, unknown>, traderId: string) =>
    requestJson<{ ok: boolean; trader: Trader; profile: RiskProfile; traderState: TraderState }>(
      '/api/settings',
      { method: 'POST', body: JSON.stringify(payload) },
      traderId
    ),
  exportMyData: (traderId: string) => requestJson<Record<string, unknown>>('/api/me/export', {}, traderId),
  deleteMeCascade: (traderId: string) =>
    requestJson<{ ok: boolean; deleted: boolean; message_ar: string; removedCounts: Record<string, number> }>('/api/me', { method: 'DELETE' }, traderId),
  recordPanicGuard: (action: 'cooled_off' | 'proceeded', traderId: string) =>
    requestJson<{ ok: boolean; action: string; note_ar: string }>('/api/panic-guard', { method: 'POST', body: JSON.stringify({ action }) }, traderId),
  getBrokers: () => requestJson<{ brokers: BrokerInfo[]; fees_note_ar: string; disclaimer_ar: string }>('/api/brokers'),
  calculateBrokerFees: (ticket_egp: number, trades_per_month: number) =>
    requestJson<{
      ticket_egp: number;
      trades_per_month: number;
      rows: Array<{ broker_id: string; name_ar: string; verified: boolean; per_order_total_egp: number | null; annual_cost_egp: number | null; note_ar?: string }>;
    }>('/api/brokers/fee-calculate', { method: 'POST', body: JSON.stringify({ ticket_egp, trades_per_month }) }),
  getAcademy: () =>
    requestJson<{
      lessons: Array<{ id: string; title_ar: string; summary_ar: string; duration_min: number; example_ar: string; linked_symbol: string }>;
      glossary: Array<{ term_ar: string; term_en: string; simple_ar: string; egyptian_example_ar: string }>;
      charter: string[];
    }>('/api/academy'),
  explainTerm: (term_ar: string) => requestJson<{ term_ar: string; used_ai: boolean; explanation_ar: string; disclaimer_ar: string }>('/api/academy/explain', { method: 'POST', body: JSON.stringify({ term_ar }) }),
  checkFraud: (message: string) =>
    requestJson<{ risk_level: 'low' | 'medium' | 'high'; score: number; flags_ar: string[]; recommendation_ar: string }>('/api/fraud-check', {
      method: 'POST',
      body: JSON.stringify({ message }),
    }),
  runBacktest: (symbol: string, as_of: string, portfolio_egp: number) =>
    requestJson<{ ok: boolean; net_return_pct: number; max_drawdown_pct: number; trades_count: number; win_rate_pct: number; total_fees_egp: number; note_ar: string; error_ar?: string }>('/api/backtest', {
      method: 'POST',
      body: JSON.stringify({ symbol, as_of, portfolio_egp }),
    }),
  // Admin endpoints
  adminStatus: () => requestJson<{ configured: boolean; viaEnv: boolean; bootstrapAllowed: boolean }>('/api/admin/status'),
  adminBootstrap: (passcode: string) => requestJson<{ ok: boolean; token: string }>('/api/admin/bootstrap', { method: 'POST', body: JSON.stringify({ passcode }) }),
  adminLogin: (passcode: string) => requestJson<{ ok: boolean; token: string }>('/api/admin/login', { method: 'POST', body: JSON.stringify({ passcode }) }),
  adminOverview: (token: string) =>
    requestJson<{
      kpis: Record<string, number | boolean>;
      live_feed_status: LiveFeedStatus;
      config: VersionedConfig;
      kill_switches: KillSwitches;
      agents: AgentDefinition[];
      review_queue: HumanReviewItem[];
      brokers: BrokerInfo[];
      audit_logs: AuditLogEntry[];
      calibrations: CalibrationRow[];
    }>('/api/admin/overview', {}, undefined, token),
  adminSyncLive: (token: string) =>
    requestJson<{ ok: boolean; live_feed_status: LiveFeedStatus }>('/api/admin/sync-live', { method: 'POST' }, undefined, token),
  adminKillSwitch: (payload: Partial<KillSwitches>, token: string) =>
    requestJson<{ ok: boolean; kill_switches: KillSwitches }>('/api/admin/kill-switch', { method: 'POST', body: JSON.stringify(payload) }, undefined, token),
  adminUpdateConfig: (payload: Partial<VersionedConfig>, token: string) =>
    requestJson<{ ok: boolean; config: VersionedConfig }>('/api/admin/config', { method: 'POST', body: JSON.stringify(payload) }, undefined, token),
  adminOntologyQuery: (params: { as_of: string; entity_id?: string; predicate?: string }, token: string) => {
    const qs = new URLSearchParams({ as_of: params.as_of });
    if (params.entity_id) qs.set('entity_id', params.entity_id);
    if (params.predicate) qs.set('predicate', params.predicate);
    return requestJson<{ as_of: string; entity_id: string; fact_count: number; facts: Fact[]; edges: Array<Record<string, unknown>> }>(`/api/admin/ontology/query?${qs.toString()}`, {}, undefined, token);
  },
  adminAddFact: (payload: Record<string, unknown>, token: string) =>
    requestJson<{ ok: boolean; fact: Fact }>('/api/admin/facts', { method: 'POST', body: JSON.stringify(payload) }, undefined, token),
  adminComplianceTest: (text_ar: string, allowed_numbers: number[], token: string) =>
    requestJson<{ ok: boolean; errors: string[] }>('/api/admin/compliance-test', { method: 'POST', body: JSON.stringify({ text_ar, allowed_numbers }) }, undefined, token),
  adminResolveReview: (id: string, status: 'approved' | 'rejected', token: string) =>
    requestJson<{ ok: boolean; item: HumanReviewItem }>(`/api/admin/review-queue/${encodeURIComponent(id)}`, { method: 'POST', body: JSON.stringify({ status }) }, undefined, token),
  adminUpdateBrokerFee: (brokerId: string, payload: Record<string, unknown>, token: string) =>
    requestJson<{ ok: boolean; broker: BrokerInfo }>(`/api/admin/brokers/${encodeURIComponent(brokerId)}/fee`, { method: 'POST', body: JSON.stringify(payload) }, undefined, token),
};
