export type NumeralMode = 'western' | 'arabic_indic';

const ARABIC_INDIC = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];

export function toArabicIndicDigits(str: string): string {
  return str
    .replace(/\d/g, (d) => ARABIC_INDIC[Number(d)])
    .replace(/\./g, '٫');
}

export function formatNum(
  val: number | null | undefined,
  numerals: NumeralMode = 'western',
  decimals = 2
): string {
  if (val === null || val === undefined || Number.isNaN(val)) return '—';
  const formatted = val.toLocaleString('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
  return numerals === 'arabic_indic' ? toArabicIndicDigits(formatted) : formatted;
}

export function formatInt(val: number | null | undefined, numerals: NumeralMode = 'western'): string {
  return formatNum(val, numerals, 0);
}

export function formatEgp(val: number | null | undefined, numerals: NumeralMode = 'western'): string {
  if (val === null || val === undefined || Number.isNaN(val)) return '—';
  return `${formatNum(val, numerals, Math.abs(val) >= 1000 ? 0 : 2)} ج.م`;
}

export function formatPct(val: number | null | undefined, numerals: NumeralMode = 'western', signed = true): string {
  if (val === null || val === undefined || Number.isNaN(val)) return '—';
  const sign = signed && val > 0 ? '+' : '';
  return `\u2066${sign}${formatNum(val, numerals, 2)}%\u2069`;
}

export function formatAgeAr(seconds: number, numerals: NumeralMode = 'western'): string {
  if (seconds < 60) return `منذ ${formatInt(seconds, numerals)} ثانية`;
  const mins = Math.round(seconds / 60);
  if (mins < 60) return `منذ ${formatInt(mins, numerals)} دقيقة`;
  const hrs = Math.round(mins / 60);
  return `منذ ${formatInt(hrs, numerals)} ساعة`;
}

export function formatDateAr(iso: string): string {
  try {
    return new Date(iso).toLocaleString('ar-EG', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return iso;
  }
}
