import { useEffect, useState } from 'react';
import { CrisisOverlay } from './components/Modals';
import { AppRoute, Navbar } from './components/Navbar';
import { WorkspaceToolbar } from './components/WorkspaceToolbar';
import { SHORT_DISCLAIMER_AR } from './core/marketPack';
import { LiveFeedStatus, RiskProfile, Trader, TraderState } from './core/types';
import { api } from './lib/api';
import { NumeralMode } from './lib/formatters';
import { AcademyPage } from './pages/AcademyPage';
import { AdminPage } from './pages/AdminPage';
import { AdvicePage } from './pages/AdvicePage';
import { AgentsPage } from './pages/AgentsPage';
import { BrokersPage } from './pages/BrokersPage';
import { DisciplinePage } from './pages/DisciplinePage';
import { HomeBriefPage } from './pages/HomeBriefPage';
import { MarketPage } from './pages/MarketPage';
import { OnboardingPage } from './pages/OnboardingPage';
import { PortfolioPage } from './pages/PortfolioPage';
import { PricingPage } from './pages/PricingPage';
import { SettingsPage } from './pages/SettingsPage';
import { StockDetailPage } from './pages/StockDetailPage';
import { TrackRecordPage } from './pages/TrackRecordPage';
import { WelcomePage } from './pages/WelcomePage';

const HASH_ROUTE_MAP: Record<string, AppRoute> = {
  welcome: 'welcome',
  home: 'home',
  market: 'market',
  agents: 'agents',
  pricing: 'pricing',
  portfolio: 'portfolio',
  onboarding: 'onboarding',
  discipline: 'discipline',
  brokers: 'brokers',
  'track-record': 'track_record',
  track_record: 'track_record',
  academy: 'academy',
  admin: 'admin',
  settings: 'settings',
  advice: 'advice',
  stock: 'stock',
};

function resolveInitialRoute(): AppRoute {
  if (typeof window === 'undefined') return 'welcome';
  const params = new URLSearchParams(window.location.search);
  if (params.get('autostart') === '1') return 'home';
  const hash = window.location.hash.replace(/^#\/?/, '').toLowerCase();
  if (hash && HASH_ROUTE_MAP[hash]) return HASH_ROUTE_MAP[hash];
  const path = window.location.pathname.replace(/^\/+/, '').toLowerCase();
  if (path && HASH_ROUTE_MAP[path]) return HASH_ROUTE_MAP[path];
  return 'welcome';
}

export default function App() {
  const [route, setRoute] = useState<AppRoute>(resolveInitialRoute);

  const [routeParam, setRouteParam] = useState<string>('COMI');
  const [dark, setDark] = useState(false);
  const [activeTraderId, setActiveTraderId] = useState('trader_main');
  const [personas, setPersonas] = useState<Array<{ trader: Trader; profile: RiskProfile; traderState: TraderState }>>([]);
  const [crisisActive, setCrisisActive] = useState(false);
  const [crisisDismissed, setCrisisDismissed] = useState(false);
  const [licencePath, setLicencePath] = useState<string>('PATH_B');
  const [liveFeedStatus, setLiveFeedStatus] = useState<LiveFeedStatus | undefined>(undefined);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', dark);
  }, [dark]);

  useEffect(() => {
    const onHashChange = () => {
      const hash = window.location.hash.replace(/^#\/?/, '').toLowerCase();
      if (hash && HASH_ROUTE_MAP[hash]) {
        setRoute(HASH_ROUTE_MAP[hash]);
      }
    };
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  const refreshSystem = () => {
    api
      .getPersonas()
      .then((res) => {
        setPersonas(res.personas);
        if (res.personas.length > 0 && !res.personas.some((p) => p.trader.id === activeTraderId)) {
          setActiveTraderId(res.personas[0].trader.id);
        }
      })
      .catch(() => {});

    api
      .getHealth()
      .then((h) => {
        setCrisisActive(Boolean(h.kill_switches.crisis_mode_manual));
        setLicencePath(h.licence_path);
        if (h.live_feed_status) setLiveFeedStatus(h.live_feed_status);
      })
      .catch(() => {});
  };

  useEffect(() => {
    refreshSystem();
  }, []);

  const currentPersona = personas.find((p) => p.trader.id === activeTraderId);
  const numerals: NumeralMode = currentPersona?.trader.numerals ?? 'western';

  const navigate = (nextRoute: AppRoute, param?: string) => {
    setRoute(nextRoute);
    if (param) setRouteParam(param);
    if (typeof window !== 'undefined') {
      const hashSlug = nextRoute === 'track_record' ? 'track-record' : nextRoute;
      if (window.location.hash !== `#${hashSlug}`) {
        window.history.replaceState(null, '', `#${hashSlug}`);
      }
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div
      dir="rtl"
      className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100"
    >
      <Navbar route={route} onNavigate={navigate} />

      <WorkspaceToolbar
        route={route}
        onNavigate={navigate}
        personas={personas}
        activeTraderId={activeTraderId}
        onSelectTrader={(id) => {
          setActiveTraderId(id);
          refreshSystem();
        }}
        dark={dark}
        onToggleDark={() => setDark((d) => !d)}
        licencePath={licencePath}
        liveFeedStatus={liveFeedStatus}
      />

      <CrisisOverlay
        active={crisisActive && !crisisDismissed}
        reasonAr="تفعيل وضع الحماية من التقلبات عبر غرفة الحوكمة"
        onDismiss={() => setCrisisDismissed(true)}
        onReviewPortfolio={() => navigate('portfolio')}
      />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-4">
        {route === 'welcome' && <WelcomePage onNavigate={navigate} />}
        {route === 'onboarding' && (
          <OnboardingPage
            traderId={activeTraderId}
            numerals={numerals}
            onCompleted={refreshSystem}
            onNavigate={navigate}
          />
        )}
        {route === 'home' && (
          <HomeBriefPage traderId={activeTraderId} numerals={numerals} onNavigate={navigate} />
        )}
        {route === 'market' && <MarketPage numerals={numerals} onNavigate={navigate} />}
        {route === 'agents' && (
          <AgentsPage
            traderId={activeTraderId}
            numerals={numerals}
            onSubscriptionChanged={refreshSystem}
            onNavigate={navigate}
          />
        )}
        {route === 'pricing' && (
          <PricingPage
            traderId={activeTraderId}
            numerals={numerals}
            onSubscriptionChanged={refreshSystem}
            onNavigate={navigate}
          />
        )}
        {route === 'stock' && (
          <StockDetailPage symbol={routeParam || 'COMI'} traderId={activeTraderId} numerals={numerals} onNavigate={navigate} />
        )}
        {route === 'advice' && (
          <AdvicePage adviceId={routeParam} traderId={activeTraderId} numerals={numerals} onNavigate={navigate} />
        )}
        {route === 'portfolio' && (
          <PortfolioPage traderId={activeTraderId} numerals={numerals} onNavigate={navigate} />
        )}
        {route === 'discipline' && (
          <DisciplinePage traderId={activeTraderId} numerals={numerals} initialSection="overview" onNavigate={navigate} />
        )}
        {route === 'plan_new' && (
          <DisciplinePage traderId={activeTraderId} numerals={numerals} initialSection="new_plan" onNavigate={navigate} />
        )}
        {route === 'trade_review' && (
          <DisciplinePage
            traderId={activeTraderId}
            numerals={numerals}
            initialSection="review"
            reviewParam={routeParam}
            onNavigate={navigate}
          />
        )}
        {route === 'track_record' && <TrackRecordPage numerals={numerals} onNavigate={navigate} />}
        {route === 'brokers' && <BrokersPage numerals={numerals} />}
        {route === 'academy' && <AcademyPage numerals={numerals} onNavigate={navigate} />}
        {route === 'settings' && (
          <SettingsPage
            traderId={activeTraderId}
            onTraderPreferencesUpdated={refreshSystem}
            onAccountDeleted={() => {
              setActiveTraderId('trader_beginner_debt');
              refreshSystem();
            }}
            onNavigate={navigate}
          />
        )}
        {route === 'admin' && <AdminPage numerals={numerals} onGovernanceChanged={refreshSystem} />}
      </main>

      <footer className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-slate-500 dark:text-slate-400">
          <p className="max-w-3xl leading-relaxed">{SHORT_DISCLAIMER_AR}</p>
          <div className="flex flex-wrap items-center gap-4 shrink-0">
            <button type="button" onClick={() => navigate('agents')} className="hover:text-slate-900 dark:hover:text-slate-100">
              الوكلاء (84)
            </button>
            <button type="button" onClick={() => navigate('pricing')} className="hover:text-slate-900 dark:hover:text-slate-100">
              الباقات
            </button>
            <button type="button" onClick={() => navigate('track_record')} className="hover:text-slate-900 dark:hover:text-slate-100">
              السجل المختوم
            </button>
            <button type="button" onClick={() => navigate('admin')} className="hover:text-slate-900 dark:hover:text-slate-100">
              لوحة الحوكمة
            </button>
            <a
              href="/api/export-repo.zip"
              download="borsagy-si-deploy.zip"
              className="font-semibold text-emerald-700 dark:text-emerald-400 hover:underline"
            >
              تحميل حزمة الرفع (.zip)
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
