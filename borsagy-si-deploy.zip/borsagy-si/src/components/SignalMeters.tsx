import React from 'react';
import { NumeralMode, formatNum } from '../lib/formatters';

export const RiskMeter: React.FC<{ level: 1 | 2 | 3 | 4 | 5; labelAr: string; numerals?: NumeralMode }> = ({
  level,
  labelAr,
  numerals = 'western',
}) => {
  const colors = ['bg-emerald-600', 'bg-emerald-500', 'bg-amber-500', 'bg-orange-600', 'bg-rose-700'];
  return (
    <div className="space-y-1.5" aria-label={`مقياس المخاطر: ${labelAr}`}>
      <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-300">
        <span>مستوى مخاطرة المحفظة</span>
        <span className="font-semibold text-slate-900 dark:text-slate-100 tabular-nums">
          {labelAr} ·{' '}
          <span dir="ltr" className="inline-block">
            {formatNum(level, numerals, 0)} / {formatNum(5, numerals, 0)}
          </span>
        </span>
      </div>
      <div className="grid grid-cols-5 gap-1.5">
        {[1, 2, 3, 4, 5].map((step) => (
          <div
            key={step}
            className={`h-2 rounded-sm transition-colors ${
              step <= level ? colors[level - 1] : 'bg-slate-200 dark:bg-slate-800'
            }`}
          />
        ))}
      </div>
    </div>
  );
};

export const DataAgeBadge: React.FC<{
  seconds: number;
  isDemo?: boolean;
  staleThreshold?: number;
  numerals?: NumeralMode;
}> = ({ seconds, isDemo = true, staleThreshold = 1200, numerals = 'western' }) => {
  const isStale = seconds > staleThreshold;
  const mins = Math.max(1, Math.round(seconds / 60));
  return (
    <span
      className={`text-xs font-medium tabular-nums ${
        isStale ? 'text-rose-700 dark:text-rose-400' : 'text-slate-500 dark:text-slate-400'
      }`}
    >
      {isDemo ? 'بيانات تجريبية (DEMO)' : 'تغذية حية (Live EGX)'}
      <span aria-hidden="true"> · </span>
      {isStale
        ? `بيانات متأخرة (${formatNum(mins, numerals, 0)} دقيقة)`
        : `تحديث منذ ${formatNum(mins, numerals, 0)} دقيقة`}
    </span>
  );
};

export const ConfidenceBar: React.FC<{ confidence: number; numerals?: NumeralMode }> = ({
  confidence,
  numerals = 'western',
}) => {
  const pct = Math.round(Math.max(0, Math.min(1, confidence)) * 100);
  const tone =
    pct >= 70 ? 'bg-emerald-700 dark:bg-emerald-500' : pct >= 55 ? 'bg-amber-600 dark:bg-amber-500' : 'bg-rose-700 dark:bg-rose-500';
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between text-xs">
        <span className="text-slate-500 dark:text-slate-400">درجة الثقة المُعايَرة</span>
        <span className="font-semibold text-slate-900 dark:text-slate-100 tabular-nums">
          {formatNum(pct, numerals, 0)}%
        </span>
      </div>
      <div className="h-2 w-full bg-slate-200 dark:bg-slate-800 rounded-sm overflow-hidden">
        <div className={`h-full ${tone} transition-all duration-200`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
};

export const AgreementDots: React.FC<{ agreement: number; conflictFlags: string[]; numerals?: NumeralMode }> = ({
  agreement,
  conflictFlags,
  numerals = 'western',
}) => {
  const pct = Math.round(agreement * 100);
  const filled = Math.max(1, Math.round(agreement * 5));
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between text-xs">
        <span className="text-slate-500 dark:text-slate-400">اتفاق الوكلاء التحليليين</span>
        <span className="font-semibold text-slate-900 dark:text-slate-100 tabular-nums">
          {formatNum(pct, numerals, 0)}% {conflictFlags.length > 0 ? '· تضارب مرصود' : '· متسق'}
        </span>
      </div>
      <div className="flex items-center gap-1.5" aria-hidden="true">
        {[1, 2, 3, 4, 5].map((i) => (
          <span
            key={i}
            className={`h-2 flex-1 rounded-sm ${
              i <= filled
                ? conflictFlags.length > 0
                  ? 'bg-amber-600'
                  : 'bg-slate-800 dark:bg-slate-200'
                : 'bg-slate-200 dark:bg-slate-800'
            }`}
          />
        ))}
      </div>
    </div>
  );
};

export const ConflictBanner: React.FC<{ flags: string[] }> = ({ flags }) => {
  if (!flags || flags.length === 0) return null;
  return (
    <div
      role="status"
      className="rounded-lg border border-amber-300 dark:border-amber-700/70 bg-amber-50/70 dark:bg-amber-950/30 p-3.5 text-sm text-amber-950 dark:text-amber-100"
    >
      <p className="font-semibold mb-1">تنبيه تضارب بين الوكلاء التحليليين</p>
      <ul className="space-y-1 text-xs text-amber-900 dark:text-amber-200">
        {flags.map((f, idx) => (
          <li key={idx}>• {f}</li>
        ))}
      </ul>
    </div>
  );
};
