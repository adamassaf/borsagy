import React, { useState } from 'react';
import { SHORT_DISCLAIMER_AR } from '../core/marketPack';
import { PlanDraft } from '../core/types';
import { api } from '../lib/api';
import { NumeralMode, formatEgp, formatInt, formatNum } from '../lib/formatters';

export const CrisisOverlay: React.FC<{
  active: boolean;
  reasonAr: string;
  onDismiss: () => void;
  onReviewPortfolio: () => void;
}> = ({ active, reasonAr, onDismiss, onReviewPortfolio }) => {
  if (!active) return null;
  return (
    <div
      role="region"
      aria-label="وضع تهدئة السوق"
      className="bg-amber-50 dark:bg-amber-950/60 border-b border-amber-300 dark:border-amber-800"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-1 max-w-2xl">
          <div className="text-xs font-semibold text-amber-900 dark:text-amber-200">
            حالة أزمة وتقلبات حادة في السوق
          </div>
          <p className="text-sm text-amber-950 dark:text-amber-100 leading-relaxed">
            السوق متحرك بشدة ({reasonAr}). مش لازم تتحرك دلوقتي. بلاش قرارات سريعة، وراجع خطتك ومراكزك بهدوء.
          </p>
        </div>
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={onReviewPortfolio}
            className="px-4 py-2 rounded-lg text-xs font-semibold bg-amber-900 text-white hover:bg-amber-800 transition-colors whitespace-nowrap shrink-0"
          >
            مراجعة المراكز بهدوء
          </button>
          <button
            type="button"
            onClick={onDismiss}
            className="px-3 py-2 rounded-lg text-xs font-medium border border-amber-400 dark:border-amber-700 text-amber-900 dark:text-amber-200 hover:bg-amber-100 dark:hover:bg-amber-900/40 transition-colors whitespace-nowrap shrink-0"
          >
            إخفاء مؤقتاً
          </button>
        </div>
      </div>
    </div>
  );
};

export const PanicGuardModal: React.FC<{
  open: boolean;
  onClose: () => void;
  totalValueEgp: number;
  unrealizedPnlEgp: number;
  traderId: string;
  numerals?: NumeralMode;
  onActionRecorded: (note: string) => void;
}> = ({ open, onClose, totalValueEgp, unrealizedPnlEgp, traderId, numerals = 'western', onActionRecorded }) => {
  const [busy, setBusy] = useState(false);
  if (!open) return null;

  const estimatedFees = Math.max(10, totalValueEgp * 0.0028);

  const handleChoice = async (action: 'cooled_off' | 'proceeded') => {
    setBusy(true);
    try {
      const res = await api.recordPanicGuard(action, traderId);
      onActionRecorded(res.note_ar);
      onClose();
    } finally {
      setBusy(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="panic-guard-title"
      className="fixed inset-0 z-50 bg-slate-950/60 flex items-center justify-center p-4"
    >
      <div className="max-w-lg w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-5">
        <div className="space-y-1.5">
          <p className="text-xs font-semibold text-amber-700 dark:text-amber-400">حماية التسرع قبل البيع الجماعي</p>
          <h2 id="panic-guard-title" className="text-lg font-bold text-slate-900 dark:text-slate-100">
            ثانية واحدة قبل ما تقرر تبيع الكل
          </h2>
          <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
            قرار الخروج الكامل تحت ضغط الشاشة غالباً بيثبت الخسارة ويحمّلك عمولات بيع فورية. هل القرار ده كان مكتوب في خطتك؟
          </p>
        </div>

        <div className="grid grid-cols-2 gap-3 p-3.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 text-xs">
          <div>
            <div className="text-slate-500">إجمالي قيمة المراكز</div>
            <div className="font-bold text-slate-900 dark:text-slate-100 tabular-nums mt-0.5">
              {formatEgp(totalValueEgp, numerals)}
            </div>
          </div>
          <div>
            <div className="text-slate-500">الربح/الخسارة غير المحققة</div>
            <div className={`font-bold tabular-nums mt-0.5 ${unrealizedPnlEgp >= 0 ? 'text-emerald-700 dark:text-emerald-400' : 'text-rose-700 dark:text-rose-400'}`}>
              {formatEgp(unrealizedPnlEgp, numerals)}
            </div>
          </div>
          <div className="col-span-2 pt-2 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between">
            <span className="text-slate-500">تقدير عمولة ورسوم التصفية الفورية</span>
            <span className="font-semibold text-slate-900 dark:text-slate-100 tabular-nums">
              {formatEgp(estimatedFees, numerals)}
            </span>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-end gap-3">
          <button
            type="button"
            disabled={busy}
            onClick={() => handleChoice('proceeded')}
            className="px-4 py-2 rounded-lg text-xs font-medium border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800"
          >
            أفهم التكلفة، مراجعة المراكز يدوياً
          </button>
          <button
            type="button"
            disabled={busy}
            onClick={() => handleChoice('cooled_off')}
            className="px-4 py-2 rounded-lg text-xs font-semibold bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 hover:bg-slate-800"
          >
            خُد استراحة ١٥ دقيقة وهدّي القرار
          </button>
        </div>
      </div>
    </div>
  );
};

export const OrderPrepModal: React.FC<{
  open: boolean;
  onClose: () => void;
  plan: PlanDraft | null;
  adviceId?: string;
  traderId: string;
  numerals?: NumeralMode;
  onPaperExecuted: (msg: string) => void;
}> = ({ open, onClose, plan, adviceId, traderId, numerals = 'western', onPaperExecuted }) => {
  const [reason, setReason] = useState('التزام بخطة الدخول المحسوبة مع وقف خسارة محدد مسبقاً');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  if (!open || !plan) return null;

  const estFees = Math.max(2, plan.size_egp * 0.001725);
  const netCost = plan.size_egp + estFees;

  const handlePaperConfirm = async () => {
    setBusy(true);
    setErr(null);
    try {
      await api.createPlan(
        {
          symbol: plan.symbol,
          reason,
          entry: plan.entry,
          stop: plan.stop,
          targets: plan.targets,
          size_pct: plan.size_pct,
          worst_case: `تفعيل وقف الخسارة عند ${plan.stop} بخسارة قصوى ${plan.max_loss_egp} ج.م`,
          advice_id: adviceId,
          open_paper_fill: true,
        },
        traderId
      );
      onPaperExecuted(`تم توقيع الخطة وتسجيل مركز تجريبي (Paper Fill) على ${plan.symbol} بالمحفظة.`);
      onClose();
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'تعذر تسجيل الخطة.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="order-prep-title"
      className="fixed inset-0 z-50 bg-slate-950/60 flex items-center justify-center p-4"
    >
      <div className="max-w-lg w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
        <div>
          <p className="text-xs font-semibold text-emerald-700 dark:text-emerald-400">
            تجهيز مسودة الأمر فقط — بدون تنفيذ آلي وبدون كلمة مرور وسيط
          </p>
          <h2 id="order-prep-title" className="text-lg font-bold text-slate-900 dark:text-slate-100 mt-1">
            مسودة أمر شراء · {plan.stock_name_ar} ({plan.symbol})
          </h2>
        </div>

        <div className="grid grid-cols-2 gap-3 p-3.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 text-xs">
          <div>
            <span className="text-slate-500 block">نوع الأمر</span>
            <span className="font-semibold text-slate-900 dark:text-slate-100">شراء محدد السعر (Limit)</span>
          </div>
          <div>
            <span className="text-slate-500 block">الكمية</span>
            <span className="font-semibold tabular-nums">{formatInt(plan.qty, numerals)} سهم</span>
          </div>
          <div>
            <span className="text-slate-500 block">السعر المحدد</span>
            <span className="font-semibold tabular-nums">{formatNum(plan.entry, numerals, 2)} ج.م</span>
          </div>
          <div>
            <span className="text-slate-500 block">وقف الخسارة المخطط</span>
            <span className="font-semibold text-rose-700 dark:text-rose-400 tabular-nums">
              {formatNum(plan.stop, numerals, 2)} ج.م
            </span>
          </div>
          <div>
            <span className="text-slate-500 block">تقدير عمولة ورسوم (TO VERIFY)</span>
            <span className="font-semibold tabular-nums">{formatEgp(estFees, numerals)}</span>
          </div>
          <div>
            <span className="text-slate-500 block">الإجمالي المقدر بالرسوم</span>
            <span className="font-bold tabular-nums">{formatEgp(netCost, numerals)}</span>
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
            سبب الصفقة في عقد التداول (إلزامي)
          </label>
          <input
            type="text"
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm text-slate-900 dark:text-slate-100"
          />
        </div>

        {err && <p className="text-xs text-rose-700 dark:text-rose-400">{err}</p>}

        <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">{SHORT_DISCLAIMER_AR}</p>

        <div className="flex flex-wrap items-center justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg text-xs font-medium border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300"
          >
            إلغاء
          </button>
          <button
            type="button"
            disabled={busy || reason.trim().length < 5}
            onClick={handlePaperConfirm}
            className="px-4 py-2 rounded-lg text-xs font-semibold bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 hover:bg-slate-800 disabled:opacity-50"
          >
            {busy ? 'جاري التوقيع...' : 'توقيع الخطة وتسجيل تنفيذ ورقي (Paper Fill)'}
          </button>
        </div>
      </div>
    </div>
  );
};
