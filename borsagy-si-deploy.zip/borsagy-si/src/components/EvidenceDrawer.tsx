import React, { useState } from 'react';
import { api, WhyChainResponse } from '../lib/api';
import { NumeralMode, formatDateAr, formatNum } from '../lib/formatters';

export const EvidenceDrawer: React.FC<{
  adviceId: string;
  numerals?: NumeralMode;
}> = ({ adviceId, numerals = 'western' }) => {
  const [open, setOpen] = useState(false);
  const [level, setLevel] = useState<1 | 2 | 3>(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<WhyChainResponse | null>(null);

  const loadLevel = async (targetLevel: 1 | 2 | 3) => {
    setOpen(true);
    setLevel(targetLevel);
    setLoading(true);
    setError(null);
    try {
      const res = await api.getAdviceWhy(adviceId, targetLevel);
      setData(res);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'تعذر تحميل سلسلة الأدلة.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
      <div className="p-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
            سلسلة الأدلة والأنطولوجيا (ليه؟)
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            3 مستويات للتعمق: ملخص بسيط، ثم الأرقام ومصادرها، ثم الفحص الثنائي الزمني والختم الرقمي.
          </p>
        </div>
        <button
          type="button"
          aria-expanded={open}
          onClick={() => (open ? setOpen(false) : loadLevel(level))}
          className="px-4 py-2 rounded-lg text-xs font-semibold border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
        >
          {open ? 'إخفاء التفاصيل' : 'ليه؟ اعرض الأدلة'}
        </button>
      </div>

      {open && (
        <div className="border-t border-slate-100 dark:border-slate-800 p-4 space-y-4">
          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg w-fit">
            {([1, 2, 3] as const).map((lvl) => (
              <button
                key={lvl}
                type="button"
                onClick={() => loadLevel(lvl)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  level === lvl
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                {lvl === 1 ? 'مستوى ١: الملخص' : lvl === 2 ? 'مستوى ٢: الأرقام والمصادر' : 'مستوى ٣: السلسلة الكاملة'}
              </button>
            ))}
          </div>

          {loading && <p className="text-xs text-slate-500">جاري تحميل الأدلة الموثقة...</p>}
          {error && <p className="text-xs text-rose-700 dark:text-rose-400">{error}</p>}

          {!loading && data && (
            <div className="space-y-4 text-sm">
              <div className="space-y-1.5">
                <p className="text-slate-800 dark:text-slate-200 leading-relaxed">{data.summary_ar}</p>
                {data.red_team_ar && (
                  <p className="text-xs text-amber-800 dark:text-amber-300 bg-amber-50/60 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800/60 rounded-lg p-3">
                    {data.red_team_ar}
                  </p>
                )}
              </div>

              {level >= 2 && data.evidence_list && (
                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-right border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500">
                        <th className="py-2 font-medium">البيان</th>
                        <th className="py-2 font-medium">القيمة المرجعية</th>
                        <th className="py-2 font-medium">معرّف الحقيقة (Fact ID)</th>
                        <th className="py-2 font-medium">المصدر</th>
                        <th className="py-2 font-medium">تاريخ المعرفة</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {data.evidence_list.map((ev, i) => (
                        <tr key={i}>
                          <td className="py-2 text-slate-800 dark:text-slate-200">{ev.label_ar}</td>
                          <td className="py-2 font-mono tabular-nums font-semibold">
                            {typeof ev.value === 'number' ? formatNum(ev.value, numerals, 2) : ev.value}
                          </td>
                          <td className="py-2 font-mono text-slate-500">{ev.fact_id}</td>
                          <td className="py-2 text-slate-600 dark:text-slate-300">{ev.source_name}</td>
                          <td className="py-2 text-slate-500">{formatDateAr(ev.known_at)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {level === 3 && data.full_chain && (
                <div className="space-y-3 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 font-mono">
                    <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/60">
                      <span className="text-slate-500 block">SHA-256 Seal Hash</span>
                      <span className="text-slate-800 dark:text-slate-200 break-all">{data.full_chain.seal_hash}</span>
                    </div>
                    <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/60">
                      <span className="text-slate-500 block">Previous Seal Hash</span>
                      <span className="text-slate-800 dark:text-slate-200 break-all">{data.full_chain.prev_seal_hash}</span>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold text-slate-800 dark:text-slate-200 mb-2">
                      فحوصات القيود الصلبة قبل النصيحة ({data.full_chain.constraints.length})
                    </h4>
                    <div className="space-y-1.5">
                      {data.full_chain.constraints.map((c) => (
                        <div key={c.id} className="flex items-center justify-between gap-2 py-1 border-b border-slate-100 dark:border-slate-800/60">
                          <span className="text-slate-700 dark:text-slate-300">
                            {c.id} · {c.reason_ar}
                          </span>
                          <span className={c.passed ? 'text-emerald-700 dark:text-emerald-400 font-semibold' : 'text-rose-700 dark:text-rose-400 font-semibold'}>
                            {c.passed ? 'مسموح' : c.action}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
