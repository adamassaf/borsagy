import React from 'react';
import { Moon, Sun } from 'lucide-react';
import { LiveFeedStatus, Trader, TraderState } from '../core/types';
import { AppRoute } from './Navbar';

export const WorkspaceToolbar: React.FC<{
  route: AppRoute;
  onNavigate: (r: AppRoute) => void;
  personas: Array<{ trader: Trader; traderState?: TraderState }>;
  activeTraderId: string;
  onSelectTrader: (id: string) => void;
  dark: boolean;
  onToggleDark: () => void;
  licencePath?: string;
  liveFeedStatus?: LiveFeedStatus;
}> = ({ route, onNavigate, personas, activeTraderId, onSelectTrader, dark, onToggleDark, licencePath, liveFeedStatus }) => {
  const secondaryNav: Array<{ id: AppRoute; label: string }> = [
    { id: 'track_record', label: 'السجل المنشور' },
    { id: 'discipline', label: 'الانضباط والمزاج' },
    { id: 'brokers', label: 'شركات التداول' },
    { id: 'academy', label: 'الأكاديمية' },
    { id: 'admin', label: 'الحوكمة' },
    { id: 'settings', label: 'الإعدادات' },
  ];

  const isLive = Boolean(liveFeedStatus?.synced && liveFeedStatus.live_symbols_count > 0);

  return (
    <div className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-4">
        <div className="hidden md:flex items-center gap-3 text-xs">
          {secondaryNav.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => onNavigate(item.id)}
              className={`px-2.5 py-1.5 rounded-md transition-colors whitespace-nowrap shrink-0 ${
                route === item.id
                  ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-semibold border border-slate-200 dark:border-slate-700'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-3 text-xs mr-auto">
          <span className="text-slate-600 dark:text-slate-300 tabular-nums">
            {isLive ? (
              <>
                <span className="font-semibold text-emerald-700 dark:text-emerald-400">
                  سوق حي · {liveFeedStatus?.live_symbols_count} سهم
                </span>
                {liveFeedStatus?.usd_egp ? ` · USD ${liveFeedStatus.usd_egp} ج` : ''}
                {liveFeedStatus?.gold_21k_egp ? ` · ذهب 21: ${liveFeedStatus.gold_21k_egp} ج` : ''}
              </>
            ) : (
              'البورصة المصرية (DEMO)'
            )}
            {licencePath ? ` · ${licencePath}` : ''}
          </span>

          {personas.length > 0 && (
            <label className="flex items-center gap-2 text-slate-600 dark:text-slate-300">
              <span className="sr-only">تبديل شخصية الاختبار</span>
              <select
                aria-label="اختيار شخصية المستثمر التجريبية"
                value={activeTraderId}
                onChange={(e) => onSelectTrader(e.target.value)}
                className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-md px-2.5 py-1 text-xs text-slate-800 dark:text-slate-100"
              >
                {personas.map((p) => (
                  <option key={p.trader.id} value={p.trader.id}>
                    {p.trader.handle}
                    {p.traderState?.halted ? ' (موقوف للحد)' : ''}
                  </option>
                ))}
              </select>
            </label>
          )}

          <button
            type="button"
            onClick={onToggleDark}
            aria-label={dark ? 'التبديل للوضع الفاتح' : 'التبديل للوضع الداكن'}
            className="p-1.5 rounded-md border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-white dark:hover:bg-slate-800 transition-colors"
          >
            {dark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </div>
  );
};
