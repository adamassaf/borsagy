import React from 'react';
import { TrapScoreBreakdown } from '../core/types';
import { NumeralMode, formatNum } from '../lib/formatters';

export const TrapScoreGauge: React.FC<{ trap: TrapScoreBreakdown; numerals?: NumeralMode }> = ({
  trap,
  numerals = 'western',
}) => {
  const toneText =
    trap.level === 'high_risk'
      ? 'تحذير: فخ سيولة أو مخاطر مرتفعة'
      : trap.level === 'caution'
        ? 'يتطلب حذراً في حجم الدخول'
        : 'سيولة ومخاطر ضمن النطاق الآمن';

  const toneColor =
    trap.level === 'high_risk'
      ? 'text-rose-700 dark:text-rose-400'
      : trap.level === 'caution'
        ? 'text-amber-700 dark:text-amber-400'
        : 'text-emerald-700 dark:text-emerald-400';

  const barColor =
    trap.level === 'high_risk'
      ? 'bg-rose-700'
      : trap.level === 'caution'
        ? 'bg-amber-600'
        : 'bg-emerald-700';

  return (
    <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">مقياس خطر السيولة والفخاخ (Trap Score)</h3>
          <p className={`text-xs font-medium mt-0.5 ${toneColor}`}>{toneText}</p>
        </div>
        <div className="text-left tabular-nums">
          <div className="text-2xl font-bold text-slate-900 dark:text-slate-100">
            {formatNum(trap.total, numerals, 0)}
            <span className="text-xs font-normal text-slate-500"> / 100</span>
          </div>
          <div className="text-xs text-slate-500 dark:text-slate-400">
            أيام الخروج المقدّرة: {formatNum(trap.exit_days, numerals, 2)} يوم
          </div>
        </div>
      </div>

      <div className="h-2.5 w-full bg-slate-100 dark:bg-slate-800 rounded-sm overflow-hidden">
        <div className={`h-full ${barColor} transition-all duration-200`} style={{ width: `${Math.min(100, trap.total)}%` }} />
      </div>

      <div className="divide-y divide-slate-100 dark:divide-slate-800">
        {trap.factors.map((f) => (
          <div key={f.key} className="py-2.5 flex items-center justify-between gap-4 text-xs">
            <div>
              <div className="font-medium text-slate-800 dark:text-slate-200">{f.label_ar}</div>
              <div className="text-slate-500 dark:text-slate-400 mt-0.5">{f.detail_ar}</div>
            </div>
            <div className="font-mono tabular-nums font-semibold text-slate-700 dark:text-slate-300 shrink-0">
              {formatNum(f.score, numerals, 0)} / {formatNum(f.max, numerals, 0)}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
