import React from 'react';
import { PlanDraft } from '../core/types';
import { NumeralMode, formatEgp, formatInt, formatNum } from '../lib/formatters';

export const PlanCard: React.FC<{
  plan: PlanDraft;
  numerals?: NumeralMode;
  onApprovePrep?: () => void;
  onDismiss?: () => void;
  actionBusy?: boolean;
  approved?: boolean;
}> = ({ plan, numerals = 'western', onApprovePrep, onDismiss, actionBusy, approved }) => {
  return (
    <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
      <div className="flex items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-3">
        <div>
          <div className="text-xs text-slate-500 dark:text-slate-400">خطة الصفقة المحسوبة بالقيود المسبقة</div>
          <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 mt-0.5">
            {plan.stock_name_ar} · {plan.symbol}
          </h3>
        </div>
        <div className="text-left text-xs text-slate-600 dark:text-slate-300 tabular-nums">
          أيام الخروج: <span className="font-semibold">{formatNum(plan.exit_days, numerals, 2)} يوم</span>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
        <div>
          <div className="text-xs text-slate-500 dark:text-slate-400">سعر الدخول المرجعي</div>
          <div className="text-lg font-bold text-slate-900 dark:text-slate-100 tabular-nums mt-0.5">
            {formatNum(plan.entry, numerals, 2)} ج.م
          </div>
        </div>
        <div>
          <div className="text-xs text-rose-700 dark:text-rose-400">وقف الخسارة الإلزامي</div>
          <div className="text-lg font-bold text-rose-700 dark:text-rose-400 tabular-nums mt-0.5">
            {formatNum(plan.stop, numerals, 2)} ج.م
          </div>
        </div>
        <div>
          <div className="text-xs text-emerald-700 dark:text-emerald-400">الأهداف المرحلية</div>
          <div className="text-lg font-bold text-emerald-700 dark:text-emerald-400 tabular-nums mt-0.5">
            {plan.targets.map((t) => formatNum(t, numerals, 2)).join(' / ')}
          </div>
        </div>
        <div>
          <div className="text-xs text-slate-500 dark:text-slate-400">الكمية المسموح بها</div>
          <div className="text-sm font-semibold text-slate-900 dark:text-slate-100 tabular-nums mt-0.5">
            {formatInt(plan.qty, numerals)} سهم (
            <span dir="ltr" className="inline-block">
              {formatNum(plan.size_pct, numerals, 2)}%
            </span>
            )
          </div>
        </div>
        <div>
          <div className="text-xs text-slate-500 dark:text-slate-400">قيمة المركز</div>
          <div className="text-sm font-semibold text-slate-900 dark:text-slate-100 tabular-nums mt-0.5">
            {formatEgp(plan.size_egp, numerals)}
          </div>
        </div>
        <div>
          <div className="text-xs text-slate-500 dark:text-slate-400">أقصى خسارة عند الوقف</div>
          <div className="text-sm font-semibold text-rose-700 dark:text-rose-400 tabular-nums mt-0.5">
            {formatEgp(plan.max_loss_egp, numerals)}
          </div>
        </div>
      </div>

      {(onApprovePrep || onDismiss) && (
        <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-slate-100 dark:border-slate-800">
          {onApprovePrep && (
            <button
              type="button"
              disabled={actionBusy || approved}
              onClick={onApprovePrep}
              className="px-4 py-2 rounded-lg text-sm font-semibold bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 hover:bg-slate-800 dark:hover:bg-slate-200 disabled:opacity-50 transition-colors whitespace-nowrap shrink-0"
            >
              {approved ? 'تم تجهيز مسودة الأمر' : 'توافق؟ تجهيز مسودة الأمر'}
            </button>
          )}
          {onDismiss && !approved && (
            <button
              type="button"
              disabled={actionBusy}
              onClick={onDismiss}
              className="px-4 py-2 rounded-lg text-sm font-medium border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
            >
              تجاهل وتريث
            </button>
          )}
        </div>
      )}
    </div>
  );
};
