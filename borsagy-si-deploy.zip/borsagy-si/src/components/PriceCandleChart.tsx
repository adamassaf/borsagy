import React, { useMemo, useState } from 'react';
import { PriceBar } from '../core/types';
import { NumeralMode, formatNum } from '../lib/formatters';

export const PriceCandleChart: React.FC<{
  bars: PriceBar[];
  symbol: string;
  numerals?: NumeralMode;
}> = ({ bars, symbol, numerals = 'western' }) => {
  const [range, setRange] = useState<'30d' | '90d' | '180d'>('90d');
  const [hoverIdx, setHoverIdx] = useState<number | null>(null);

  const sliced = useMemo(() => {
    const count = range === '30d' ? 30 : range === '90d' ? 90 : 180;
    return bars.slice(-count);
  }, [bars, range]);

  const width = 760;
  const height = 240;
  const padX = 16;
  const padY = 18;

  const { minP, maxP, points, activeBar } = useMemo(() => {
    if (sliced.length === 0) {
      return { minP: 0, maxP: 1, points: '', activeBar: null };
    }
    let lo = Infinity;
    let hi = -Infinity;
    for (const b of sliced) {
      if (b.l < lo) lo = b.l;
      if (b.h > hi) hi = b.h;
    }
    const span = Math.max(0.01, hi - lo);
    const pts = sliced
      .map((b, i) => {
        const x = padX + (i / Math.max(1, sliced.length - 1)) * (width - padX * 2);
        const y = height - padY - ((b.c - lo) / span) * (height - padY * 2);
        return `${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(' ');
    const idx = hoverIdx !== null && hoverIdx < sliced.length ? hoverIdx : sliced.length - 1;
    return { minP: lo, maxP: hi, points: pts, activeBar: sliced[idx] };
  }, [sliced, hoverIdx]);

  if (sliced.length === 0) {
    return (
      <div className="h-56 flex items-center justify-center text-sm text-slate-500 border border-slate-200 dark:border-slate-800 rounded-xl">
        لا توجد بيانات شموع تاريخية متاحة حالياً.
      </div>
    );
  }

  return (
    <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="text-xs text-slate-600 dark:text-slate-300 tabular-nums">
          <span className="font-semibold text-slate-900 dark:text-slate-100">{symbol}</span>
          {activeBar && (
            <>
              <span aria-hidden="true"> · </span>
              <span>التاريخ: {activeBar.ts.slice(0, 10)}</span>
              <span aria-hidden="true"> · </span>
              <span>إغلاق: {formatNum(activeBar.c, numerals, 2)}</span>
              <span aria-hidden="true"> · </span>
              <span>أعلى/أدنى: {formatNum(activeBar.h, numerals, 2)} / {formatNum(activeBar.l, numerals, 2)}</span>
            </>
          )}
        </div>

        <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
          {(['30d', '90d', '180d'] as const).map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => setRange(r)}
              className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                range === r
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              {r === '30d' ? '٣٠ يوم' : r === '90d' ? '٩٠ يوم' : '١٨٠ يوم'}
            </button>
          ))}
        </div>
      </div>

      <div className="relative w-full overflow-hidden">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-56 select-none"
          onMouseMove={(e) => {
            const rect = e.currentTarget.getBoundingClientRect();
            const relX = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
            setHoverIdx(Math.round(relX * (sliced.length - 1)));
          }}
          onMouseLeave={() => setHoverIdx(null)}
        >
          <defs>
            <linearGradient id="borsagyArea" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#0f172a" stopOpacity="0.16" />
              <stop offset="100%" stopColor="#0f172a" stopOpacity="0.0" />
            </linearGradient>
          </defs>
          {/* Reference Grid Lines */}
          {[0.25, 0.5, 0.75].map((f) => {
            const y = padY + f * (height - padY * 2);
            return (
              <line
                key={f}
                x1={padX}
                y1={y}
                x2={width - padX}
                y2={y}
                stroke="currentColor"
                className="text-slate-200 dark:text-slate-800"
                strokeDasharray="3 3"
              />
            );
          })}
          {/* Price Polyline */}
          <polyline
            fill="none"
            stroke="currentColor"
            className="text-slate-900 dark:text-slate-100"
            strokeWidth="2"
            points={points}
          />
          {/* Candlesticks when <= 90 bars */}
          {sliced.length <= 90 &&
            sliced.map((b, i) => {
              const span = Math.max(0.01, maxP - minP);
              const x = padX + (i / Math.max(1, sliced.length - 1)) * (width - padX * 2);
              const yH = height - padY - ((b.h - minP) / span) * (height - padY * 2);
              const yL = height - padY - ((b.l - minP) / span) * (height - padY * 2);
              const isUp = b.c >= b.o;
              return (
                <line
                  key={i}
                  x1={x}
                  y1={yH}
                  x2={x}
                  y2={yL}
                  stroke={isUp ? '#047857' : '#b91c1c'}
                  strokeWidth="1.5"
                  opacity="0.55"
                />
              );
            })}
        </svg>
        <div className="flex justify-between text-[11px] text-slate-400 tabular-nums px-2">
          <span>أدنى فترة: {formatNum(minP, numerals, 2)}</span>
          <span>أعلى فترة: {formatNum(maxP, numerals, 2)}</span>
        </div>
      </div>
    </div>
  );
};
