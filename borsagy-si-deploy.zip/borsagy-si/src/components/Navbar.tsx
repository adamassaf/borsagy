import React, { useState } from 'react';
import { Menu, X } from 'lucide-react';

export type AppRoute =
  | 'welcome'
  | 'onboarding'
  | 'home'
  | 'market'
  | 'agents'
  | 'pricing'
  | 'stock'
  | 'advice'
  | 'plan_new'
  | 'portfolio'
  | 'trade_review'
  | 'discipline'
  | 'track_record'
  | 'brokers'
  | 'academy'
  | 'settings'
  | 'admin';

export const Navbar: React.FC<{
  route: AppRoute;
  onNavigate: (route: AppRoute, param?: string) => void;
}> = ({ route, onNavigate }) => {
  const [mobileOpen, setMobileOpen] = useState(false);

  const primaryLinks: Array<{ id: AppRoute; label: string }> = [
    { id: 'home', label: 'الموجز' },
    { id: 'market', label: 'السوق' },
    { id: 'agents', label: 'الوكلاء (84)' },
    { id: 'pricing', label: 'الباقات والأسعار' },
    { id: 'portfolio', label: 'المحفظة' },
  ];

  const secondaryLinks: Array<{ id: AppRoute; label: string }> = [
    { id: 'track_record', label: 'السجل المنشور' },
    { id: 'discipline', label: 'الانضباط والمزاج' },
    { id: 'brokers', label: 'شركات التداول' },
    { id: 'academy', label: 'الأكاديمية' },
    { id: 'admin', label: 'الحوكمة' },
    { id: 'settings', label: 'الإعدادات' },
  ];

  const handleGo = (r: AppRoute) => {
    setMobileOpen(false);
    onNavigate(r);
  };

  return (
    <header className="sticky top-0 z-30 border-b border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-950/95 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Single-element Brand Wordmark */}
        <a
          href="#welcome"
          onClick={(e) => {
            e.preventDefault();
            handleGo('welcome');
          }}
          className="text-lg sm:text-xl font-extrabold tracking-tight text-slate-900 dark:text-slate-50 whitespace-nowrap shrink-0 flex items-baseline gap-2"
        >
          <span>بورصجي</span>
          <span className="text-xs font-mono font-semibold text-emerald-700 dark:text-emerald-400">borsagy.si</span>
        </a>

        {/* Zone 2: 5 concise single-line nav links */}
        <nav aria-label="التنقل الرئيسي" className="hidden md:flex items-center gap-6 text-sm font-medium">
          {primaryLinks.map((lnk) => {
            const active = route === lnk.id || (lnk.id === 'market' && route === 'stock');
            return (
              <a
                key={lnk.id}
                href={`#${lnk.id}`}
                onClick={(e) => {
                  e.preventDefault();
                  handleGo(lnk.id);
                }}
                className={`py-1 border-b-2 transition-colors whitespace-nowrap shrink-0 ${
                  active
                    ? 'border-slate-900 dark:border-slate-100 text-slate-900 dark:text-slate-100 font-semibold'
                    : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
                }`}
              >
                {lnk.label}
              </a>
            );
          })}
        </nav>

        {/* Zone 3: 1 Primary Action + Mobile Menu Trigger */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() => handleGo(route === 'welcome' ? 'onboarding' : 'plan_new')}
            className="px-4 py-2 rounded-lg text-xs font-semibold bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 hover:bg-slate-800 dark:hover:bg-slate-200 transition-colors whitespace-nowrap shrink-0"
          >
            {route === 'welcome' ? 'ابدأ التقييم' : 'خطة جديدة'}
          </button>

          <button
            type="button"
            aria-label={mobileOpen ? 'إغلاق القائمة' : 'فتح القائمة'}
            aria-expanded={mobileOpen}
            onClick={() => setMobileOpen((v) => !v)}
            className="md:hidden p-2 rounded-lg border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="md:hidden border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 px-4 py-3 space-y-2">
          <div className="grid grid-cols-2 gap-2">
            {[...primaryLinks, ...secondaryLinks].map((lnk) => (
              <button
                key={lnk.id}
                type="button"
                onClick={() => handleGo(lnk.id)}
                className={`text-right px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  route === lnk.id
                    ? 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-semibold'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-900'
                }`}
              >
                {lnk.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </header>
  );
};
