import React, { useEffect, useState } from 'react';
import { AppRoute } from '../components/Navbar';
import { BillingCycle, SubscriptionTierId } from '../core/types';
import { api } from '../lib/api';
import { NumeralMode, formatInt } from '../lib/formatters';

export const PricingPage: React.FC<{
  traderId: string;
  numerals: NumeralMode;
  onSubscriptionChanged: () => void;
  onNavigate: (route: AppRoute, param?: string) => void;
}> = ({ traderId, numerals, onSubscriptionChanged, onNavigate }) => {
  const [loading, setLoading] = useState(true);
  const [cycle, setCycle] = useState<BillingCycle>('monthly');
  const [data, setData] = useState<Awaited<ReturnType<typeof api.getSubscriptions>> | null>(null);
  const [busyTier, setBusyTier] = useState<SubscriptionTierId | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const loadPlans = (silent = false) => {
    if (!silent) setLoading(true);
    api
      .getSubscriptions(traderId)
      .then((res) => {
        setData(res);
        setCycle(res.billing_cycle);
      })
      .catch((e) => setErr(e instanceof Error ? e.message : 'تعذر تحميل باقات الاشتراك.'))
      .finally(() => {
        if (!silent) setLoading(false);
      });
  };

  useEffect(() => {
    loadPlans(false);
  }, [traderId]);

  const handleSelectPlan = async (tier: SubscriptionTierId) => {
    setBusyTier(tier);
    setNotice(null);
    setErr(null);
    try {
      const res = await api.selectSubscription(tier, cycle, traderId);
      setNotice(
        `تم تفعيل باقة (${tier.toUpperCase()}) بنجاح — أصبح لديك الآن ${formatInt(res.unlocked_agents_count, numerals)} وكيلاً مفعّلاً وجاهزاً للتشغيل المباشر.`
      );
      onSubscriptionChanged();
      loadPlans(true);
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'تعذر تحديث الباقة.');
    } finally {
      setBusyTier(null);
    }
  };

  return (
    <div className="space-y-10 py-4">
      {/* Header + Billing Toggle */}
      <div className="flex flex-wrap items-end justify-between gap-6 border-b border-slate-200 dark:border-slate-800 pb-6">
        <div className="space-y-2 max-w-2xl">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
            هيكل التسعير الشفاف لـ borsagy.si · لا إعلانات · لا عمولات إحالة · لا توصيات مدفوعة
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-slate-50">
            باقات الاشتراك وتغطية الوكلاء{' '}
            <span dir="ltr" className="inline-block font-mono text-xl sm:text-2xl text-slate-700 dark:text-slate-300">
              (Free · Plus · Pro · B2B)
            </span>
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
            التسعير مصمم لتغطية تكلفة بيانات السوق الحية والأنطولوجيا دون بيع بياناتك أو تلقي عمولات من أي شركة وساطة.
          </p>
        </div>

        <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
          <button
            type="button"
            onClick={() => setCycle('monthly')}
            className={`px-3.5 py-2 rounded-md text-xs font-semibold transition-colors ${
              cycle === 'monthly'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            دفع شهري
          </button>
          <button
            type="button"
            onClick={() => setCycle('annual')}
            className={`px-3.5 py-2 rounded-md text-xs font-semibold transition-colors ${
              cycle === 'annual'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            دفع سنوي (خصم شهرين)
          </button>
        </div>
      </div>

      {notice && (
        <div className="rounded-xl border border-emerald-300 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/30 p-4 text-sm text-emerald-900 dark:text-emerald-100 flex flex-wrap items-center justify-between gap-3">
          <span>{notice}</span>
          <button
            type="button"
            onClick={() => onNavigate('agents')}
            className="px-3 py-1.5 rounded-md text-xs font-semibold bg-emerald-800 text-white"
          >
            استعرض الوكلاء الـ 84 الآن
          </button>
        </div>
      )}

      {err && <div className="rounded-xl border border-rose-300 bg-rose-50 p-4 text-sm text-rose-900">{err}</div>}

      {loading || !data ? (
        <div className="py-12 text-center text-sm text-slate-500">جاري تحميل الباقات والأسعار...</div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-5 items-stretch">
            {data.plans.map((plan) => {
              const isActive = data.active_tier === plan.id;
              const displayedPrice = cycle === 'annual' ? Math.round(plan.annual_egp / 12) : plan.monthly_egp;
              const unlockedCount = data.agent_counts_by_tier[plan.id] ?? 0;

              return (
                <section
                  key={plan.id}
                  className={`rounded-xl border p-6 flex flex-col justify-between space-y-6 bg-white dark:bg-slate-900 ${
                    plan.recommended
                      ? 'border-emerald-700 dark:border-emerald-500'
                      : 'border-slate-200 dark:border-slate-800'
                  }`}
                >
                  <div className="space-y-4">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h2 className="text-lg font-extrabold text-slate-900 dark:text-slate-50">{plan.name_ar}</h2>
                        <div className="text-[11px] font-mono text-slate-400">{plan.name_en}</div>
                      </div>
                      {plan.badge_ar && (
                        <span className="text-[11px] font-semibold text-emerald-800 dark:text-emerald-300">
                          {plan.badge_ar}
                        </span>
                      )}
                    </div>

                    <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">{plan.tagline_ar}</p>

                    <div className="pt-3 border-t border-slate-100 dark:border-slate-800">
                      <div className="flex items-baseline gap-1.5">
                        <span className="text-3xl font-extrabold text-slate-900 dark:text-slate-50 tabular-nums">
                          {displayedPrice === 0 ? '0' : formatInt(displayedPrice, numerals)}
                        </span>
                        <span className="text-xs font-semibold text-slate-500">
                          {plan.id === 'b2b' ? '+ ج.م / شهرياً' : 'ج.م / شهرياً'}
                        </span>
                      </div>
                      {cycle === 'annual' && plan.annual_egp > 0 && (
                        <div className="text-[11px] text-emerald-700 dark:text-emerald-400 mt-0.5 tabular-nums">
                          تُدفع سنوياً {formatInt(plan.annual_egp, numerals)} ج.م
                        </div>
                      )}
                      <div className="text-[11px] text-slate-500 mt-1">{plan.billing_note_ar}</div>
                    </div>

                    <div className="rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-3 space-y-1 text-xs">
                      <div className="font-bold text-slate-900 dark:text-slate-100 tabular-nums">
                        {formatInt(unlockedCount, numerals)} وكيلاً مفعّلاً
                      </div>
                      <div className="text-[11px] text-slate-500">{plan.data_feed_ar}</div>
                    </div>

                    <ul className="space-y-2 text-xs text-slate-700 dark:text-slate-300">
                      {plan.highlights_ar.map((h, i) => (
                        <li key={i} className="flex items-start gap-2 leading-relaxed">
                          <span className="text-emerald-700 dark:text-emerald-400 font-bold shrink-0">✓</span>
                          <span>{h}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="space-y-3 pt-4 border-t border-slate-100 dark:border-slate-800">
                    <button
                      type="button"
                      disabled={busyTier === plan.id}
                      onClick={() => handleSelectPlan(plan.id)}
                      className={`w-full px-4 py-2.5 rounded-lg text-xs font-semibold transition-colors ${
                        isActive
                          ? 'bg-emerald-700 text-white'
                          : 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 hover:bg-slate-800 dark:hover:bg-slate-200'
                      }`}
                    >
                      {busyTier === plan.id
                        ? 'جاري التفعيل...'
                        : isActive
                          ? 'الباقة النشطة حالياً ✓'
                          : `تجربة وتفعيل باقة ${plan.name_ar}`}
                    </button>
                    {isActive && (
                      <button
                        type="button"
                        onClick={() => onNavigate('agents')}
                        className="w-full px-3 py-1.5 rounded-md text-xs font-semibold border border-emerald-700 text-emerald-800 dark:text-emerald-300 hover:bg-emerald-50 dark:hover:bg-emerald-950/30"
                      >
                        افتح الوكلاء ({formatInt(unlockedCount, numerals)}) الآن ←
                      </button>
                    )}
                    <p className="text-[11px] text-slate-500 leading-relaxed">{plan.compliance_note_ar}</p>
                  </div>
                </section>
              );
            })}
          </div>

          {/* Transparent Pricing Philosophy & Compliance Table */}
          <section className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
            <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
              ضوابط التسعير التنظيمية وتكاليف البيانات الحية (المواصفات §18 و§23)
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              <div className="space-y-1">
                <div className="font-bold text-slate-900 dark:text-slate-100">١. الحياد المالي الكامل</div>
                <p>
                  إيرادات المنصة تأتي حصراً من اشتراكات الأعضاء ومؤسسات السوق، ولا توجد أي إعلانات أو عمولات إحالة خفية تؤثر على ترتيب الوسطاء أو توصيات الأسهم.
                </p>
              </div>
              <div className="space-y-1">
                <div className="font-bold text-slate-900 dark:text-slate-100">٢. تغذية السوق الحية</div>
                <p>
                  تستهلك التغذية الفورية المرخصة للبورصة المصرية (EGID/ICE) ما بين 150 إلى 400 جنيه/شهرياً للمستخدم؛ لذا تركز باقة Plus على القيمة التحليلية المتأخرة بينما تشمل Pro التغذية الحية المباشرة.
                </p>
              </div>
              <div className="space-y-1">
                <div className="font-bold text-slate-900 dark:text-slate-100">٣. الالتزام بتراخيص الرقابة (FRA)</div>
                <p>
                  تعمل المنصة في وضع التعليم والتحليل (PATH_A) أو البيئة التجريبية/الشريك المرخص (PATH_B/C) ولا تنفذ أوامر تداول نيابة عن المستخدم أبداً.
                </p>
              </div>
            </div>
            <div className="text-[11px] text-slate-500 pt-3 border-t border-slate-100 dark:border-slate-800">
              {data.disclaimer_ar}
            </div>
          </section>
        </>
      )}
    </div>
  );
};
