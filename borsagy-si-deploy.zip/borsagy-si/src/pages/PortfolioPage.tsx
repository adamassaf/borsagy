import React, { useEffect, useState } from 'react';
import { PanicGuardModal } from '../components/Modals';
import { AppRoute } from '../components/Navbar';
import { RiskMeter } from '../components/SignalMeters';
import { api } from '../lib/api';
import { NumeralMode, formatEgp, formatInt, formatNum, formatPct } from '../lib/formatters';

export const PortfolioPage: React.FC<{
  traderId: string;
  numerals: NumeralMode;
  onNavigate: (route: AppRoute, param?: string) => void;
}> = ({ traderId, numerals, onNavigate }) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<Awaited<ReturnType<typeof api.getPortfolioRisk>> | null>(null);
  const [panicOpen, setPanicOpen] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);

  // Broker statement upload / import state
  const [csvText, setCsvText] = useState('TMGH, 250, 56.5\nEFID, 300, 28.8');
  const [consent, setConsent] = useState(false);
  const [autoDeleteRaw, setAutoDeleteRaw] = useState(true);
  const [importBusy, setImportBusy] = useState(false);

  const loadData = () => {
    setLoading(true);
    setError(null);
    api
      .getPortfolioRisk(traderId)
      .then(setData)
      .catch((e) => setError(e instanceof Error ? e.message : 'تعذر تحميل بيانات المحفظة.'))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadData();
  }, [traderId]);

  const handleImport = async () => {
    setImportBusy(true);
    setNotice(null);
    setError(null);
    try {
      const res = await api.importStatement(
        { csv_or_text: csvText, consent_acknowledged: consent, auto_delete_raw: autoDeleteRaw },
        traderId
      );
      setNotice(`${res.note_ar} (تم استيراد ${res.imported_count} مركز)`);
      loadData();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'فشل استيراد الكشف.');
    } finally {
      setImportBusy(false);
    }
  };

  if (loading) {
    return <div className="py-12 text-center text-sm text-slate-500">جاري تحليل مخاطر المحفظة...</div>;
  }

  if (error && !data) {
    return <div className="rounded-xl border border-rose-300 bg-rose-50 p-6 text-sm text-rose-800">{error}</div>;
  }

  if (!data) return null;
  const { positions, metrics, net_realized_egp, rule_break_cost_egp, benchmarks } = data;

  return (
    <div className="space-y-8 py-4">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="text-xs text-slate-500 dark:text-slate-400">
            حفظ ذاتي للمستخدم · بدون ربط بكلمات مرور شركات التداول
          </div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-50 mt-0.5">
            المحفظة وميزانية المخاطر والعائد الصافي
          </h1>
        </div>
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => onNavigate('plan_new')}
            className="px-4 py-2 rounded-lg text-xs font-semibold bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 whitespace-nowrap"
          >
            توقيع خطة دخول جديدة
          </button>
          <button
            type="button"
            onClick={() => setPanicOpen(true)}
            className="px-4 py-2 rounded-lg text-xs font-semibold border border-rose-300 dark:border-rose-800 text-rose-700 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 whitespace-nowrap"
          >
            بيع الكل (اختبار حارس الذعر)
          </button>
        </div>
      </div>

      {notice && (
        <div className="rounded-xl border border-emerald-300 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/30 p-4 text-sm text-emerald-900 dark:text-emerald-100">
          {notice}
        </div>
      )}

      {metrics.hidden_group_warning_ar && (
        <div className="rounded-xl border border-amber-300 dark:border-amber-800 bg-amber-50/80 dark:bg-amber-950/30 p-4 text-sm text-amber-950 dark:text-amber-100">
          <span className="font-bold">تنبيه تركز مخفي في الأنطولوجيا: </span>
          {metrics.hidden_group_warning_ar}
        </div>
      )}

      {/* Top Metrics Grid */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-8 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div>
            <div className="text-xs text-slate-500">القيمة السوقية للمراكز</div>
            <div className="text-lg font-bold tabular-nums mt-1">{formatEgp(metrics.total_market_value_egp, numerals)}</div>
          </div>
          <div>
            <div className="text-xs text-slate-500">الربح/الخسارة غير المحققة</div>
            <div className={`text-lg font-bold tabular-nums mt-1 ${metrics.unrealized_pnl_egp >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
              {formatEgp(metrics.unrealized_pnl_egp, numerals)}
            </div>
          </div>
          <div>
            <div className="text-xs text-slate-500">الصافي المحقق (بعد العمولات)</div>
            <div className={`text-lg font-bold tabular-nums mt-1 ${net_realized_egp >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
              {formatEgp(net_realized_egp, numerals)}
            </div>
          </div>
          <div>
            <div className="text-xs text-slate-500">تكلفة كسر القواعد</div>
            <div className="text-lg font-bold text-rose-700 tabular-nums mt-1">
              {formatEgp(rule_break_cost_egp, numerals)}
            </div>
          </div>
        </div>

        <div className="lg:col-span-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5">
          <RiskMeter level={metrics.risk_meter_1_to_5} labelAr={metrics.risk_label_ar} numerals={numerals} />
          <div className="text-xs text-slate-500 mt-3 tabular-nums">
            أكبر سهم: {metrics.top_stock_symbol} ({formatNum(metrics.top_stock_pct, numerals, 1)}%) · أكبر قطاع: {metrics.top_sector_ar} ({formatNum(metrics.top_sector_pct, numerals, 1)}%)
          </div>
        </div>
      </section>

      {/* Open Positions Table */}
      <section className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
        <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">المراكز المفتوحة</h2>
        {positions.length === 0 ? (
          <div className="py-8 text-center text-sm text-slate-500">
            لا توجد مراكز مفتوحة حالياً لهذا الحساب. يمكنك استيراد كشف وسيط أو توقيع خطة جديدة.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-right border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-xs text-slate-500">
                  <th className="py-2 font-medium">السهم</th>
                  <th className="py-2 font-medium text-left">الكمية</th>
                  <th className="py-2 font-medium text-left">متوسط الشراء</th>
                  <th className="py-2 font-medium text-left">السعر الحالي</th>
                  <th className="py-2 font-medium text-left">القيمة</th>
                  <th className="py-2 font-medium text-left">الربح/الخسارة</th>
                  <th className="py-2 font-medium text-left">مراجعة وإغلاق</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {positions.map((p) => {
                  const val = p.qty * p.current_price;
                  const pnl = (p.current_price - p.avg_price) * p.qty;
                  const pct = ((p.current_price - p.avg_price) / p.avg_price) * 100;
                  return (
                    <tr key={p.id}>
                      <td className="py-3">
                        <button
                          type="button"
                          onClick={() => onNavigate('stock', p.symbol)}
                          className="font-bold text-slate-900 dark:text-slate-100 hover:underline"
                        >
                          {p.symbol}
                        </button>
                        <div className="text-xs text-slate-500">{p.stock_name_ar}</div>
                      </td>
                      <td className="py-3 text-left font-mono tabular-nums">{formatInt(p.qty, numerals)}</td>
                      <td className="py-3 text-left font-mono tabular-nums">{formatNum(p.avg_price, numerals, 2)}</td>
                      <td className="py-3 text-left font-mono tabular-nums">{formatNum(p.current_price, numerals, 2)}</td>
                      <td className="py-3 text-left font-mono tabular-nums">{formatEgp(val, numerals)}</td>
                      <td className={`py-3 text-left font-mono tabular-nums font-semibold ${pnl >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                        {formatPct(pct, numerals)}
                      </td>
                      <td className="py-3 text-left">
                        <button
                          type="button"
                          onClick={() => onNavigate('trade_review', `${p.id}|${p.symbol}|${p.current_price}`)}
                          className="px-3 py-1.5 rounded-md text-xs font-semibold border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 whitespace-nowrap"
                        >
                          إغلاق ومراجعة
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* Benchmarks + Statement Importer */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
          <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
            مقارنة العائد مع البدائل الآمنة والتضخم
          </h2>
          <p className="text-xs text-slate-500">
            لا نحسب ربحك أمام سعر الشراء فقط — نقارنه بعائد الشهادات وأذون الخزانة والتضخم والذهب:
          </p>
          <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
            {benchmarks.map((b) => (
              <div key={b.id} className="py-2.5 flex items-center justify-between">
                <div>
                  <span className="font-semibold text-slate-800 dark:text-slate-200">{b.name_ar}</span>
                  <span className="text-slate-500 mr-2">· {b.risk_ar}</span>
                </div>
                <span className="font-mono font-bold tabular-nums text-slate-900 dark:text-slate-100">
                  {formatNum(b.annual_return_pct, numerals, 1)}% سنوياً
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
          <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
            استيراد كشف حساب الوسيط (CSV / نص)
          </h2>
          <p className="text-xs text-slate-500 leading-relaxed">
            بدلاً من ربط كلمة المرور، الصق أسطر المراكز بصيغة (الرمز، الكمية، متوسط السعر). يمكنك حذف النص الخام فور الاستيراد.
          </p>
          <textarea
            rows={3}
            value={csvText}
            onChange={(e) => setCsvText(e.target.value)}
            className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 p-2.5 text-xs font-mono"
          />
          <label className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
            <input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} />
            <span>أوافق على استيراد هذه المراكز لملفي داخل بورصجي فقط</span>
          </label>
          <label className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
            <input type="checkbox" checked={autoDeleteRaw} onChange={(e) => setAutoDeleteRaw(e.target.checked)} />
            <span>حذف النص الخام تلقائياً بعد القراءة (افتراضي للخصوصية)</span>
          </label>
          {error && <p className="text-xs text-rose-700">{error}</p>}
          <button
            type="button"
            disabled={importBusy}
            onClick={handleImport}
            className="px-4 py-2 rounded-lg text-xs font-semibold bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 disabled:opacity-50"
          >
            {importBusy ? 'جاري الاستيراد...' : 'استيراد المراكز الآن'}
          </button>
        </div>
      </section>

      <PanicGuardModal
        open={panicOpen}
        onClose={() => setPanicOpen(false)}
        totalValueEgp={metrics.total_market_value_egp}
        unrealizedPnlEgp={metrics.unrealized_pnl_egp}
        traderId={traderId}
        numerals={numerals}
        onActionRecorded={(note) => {
          setNotice(note);
          loadData();
        }}
      />
    </div>
  );
};
