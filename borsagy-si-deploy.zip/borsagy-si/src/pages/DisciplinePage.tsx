import React, { useEffect, useState } from 'react';
import { AppRoute } from '../components/Navbar';
import { Trade, TraderMode, TraderMood } from '../core/types';
import { api } from '../lib/api';
import { NumeralMode, formatDateAr, formatEgp, formatNum, formatPct } from '../lib/formatters';

export const DisciplinePage: React.FC<{
  traderId: string;
  numerals: NumeralMode;
  initialSection?: 'overview' | 'new_plan' | 'review';
  reviewParam?: string;
  onNavigate: (r: AppRoute, param?: string) => void;
}> = ({ traderId, numerals, initialSection = 'overview', reviewParam, onNavigate }) => {
  const [section, setSection] = useState<'overview' | 'new_plan' | 'review'>(initialSection);
  const [data, setData] = useState<Awaited<ReturnType<typeof api.getPortfolioRisk>> | null>(null);
  const [stocks, setStocks] = useState<Array<{ symbol: string; name_ar: string; price: number }>>([]);
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  // New Plan Contract form
  const [planSymbol, setPlanSymbol] = useState('COMI');
  const [planEntry, setPlanEntry] = useState(84.5);
  const [planStop, setPlanStop] = useState(80.0);
  const [planTarget, setPlanTarget] = useState(91.0);
  const [planSizePct, setPlanSizePct] = useState(10);
  const [planReason, setPlanReason] = useState('');
  const [planMood, setPlanMood] = useState<TraderMood>('calm');
  const [openPaperFill, setOpenPaperFill] = useState(true);

  // Post-trade Review form
  const [revPosId, setRevPosId] = useState('manual');
  const [revSymbol, setRevSymbol] = useState('COMI');
  const [revExitPrice, setRevExitPrice] = useState(86.0);
  const [revCause, setRevCause] = useState<'market' | 'analysis' | 'execution' | 'luck'>('execution');
  const [revTags, setRevTags] = useState<Trade['deviation_tags']>(['none']);

  useEffect(() => {
    setSection(initialSection);
  }, [initialSection]);

  useEffect(() => {
    if (reviewParam) {
      const [pid, sym, pr] = reviewParam.split('|');
      if (pid) setRevPosId(pid);
      if (sym) setRevSymbol(sym);
      if (pr && !Number.isNaN(Number(pr))) setRevExitPrice(Number(pr));
      setSection('review');
    }
  }, [reviewParam]);

  const reload = () => {
    Promise.all([api.getPortfolioRisk(traderId), api.getMovers({ timeframe: '1d' })])
      .then(([p, m]) => {
        setData(p);
        setStocks(m.stocks);
      })
      .catch((e) => setErr(e instanceof Error ? e.message : 'تعذر تحميل بيانات الانضباط.'));
  };

  useEffect(() => {
    reload();
  }, [traderId]);

  const handleModeOrMoodChange = async (patch: { mode?: TraderMode; mood?: TraderMood }) => {
    setMsg(null);
    setErr(null);
    try {
      await api.updateSettings(patch, traderId);
      setMsg('تم تحديث وضع المرافق أو الحالة المزاجية.');
      reload();
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'تعذر التحديث.');
    }
  };

  const handleCreatePlan = async (e: React.FormEvent) => {
    e.preventDefault();
    setMsg(null);
    setErr(null);
    try {
      await api.createPlan(
        {
          symbol: planSymbol,
          entry: planEntry,
          stop: planStop,
          targets: [planTarget],
          size_pct: planSizePct,
          reason: planReason,
          mood: planMood,
          open_paper_fill: openPaperFill,
        },
        traderId
      );
      setMsg(`تم توقيع عقد الصفقة لسهم ${planSymbol} مع وقف خسارة إلزامي عند ${planStop}.`);
      setPlanReason('');
      reload();
      setSection('overview');
    } catch (e2) {
      setErr(e2 instanceof Error ? e2.message : 'تعذر حفظ العقد.');
    }
  };

  const handleCloseTrade = async (e: React.FormEvent) => {
    e.preventDefault();
    setMsg(null);
    setErr(null);
    try {
      const res = await api.closeTrade(
        revPosId,
        {
          symbol: revSymbol,
          exit_price: revExitPrice,
          cause: revCause,
          deviation_tags: revTags,
          journal_completed: true,
        },
        traderId
      );
      setMsg(
        `تم إغلاق الصفقة ومراجعتها: الصافي ${formatEgp(res.trade.net_pnl_egp, numerals)} · تكلفة كسر القواعد ${formatEgp(res.trade.rule_break_cost_egp, numerals)}.`
      );
      reload();
      setSection('overview');
    } catch (e2) {
      setErr(e2 instanceof Error ? e2.message : 'تعذر إغلاق الصفقة.');
    }
  };

  const toggleTag = (tag: Trade['deviation_tags'][number]) => {
    if (tag === 'none') {
      setRevTags(['none']);
      return;
    }
    const withoutNone = revTags.filter((t) => t !== 'none');
    if (withoutNone.includes(tag)) {
      const next = withoutNone.filter((t) => t !== tag);
      setRevTags(next.length > 0 ? next : ['none']);
    } else {
      setRevTags([...withoutNone, tag]);
    }
  };

  if (!data) {
    return <div className="py-12 text-center text-sm text-slate-500">جاري تحميل مركز الانضباط...</div>;
  }

  const { traderState, trades, plans, rule_break_cost_egp } = data;

  return (
    <div className="space-y-6 py-4">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="text-xs text-slate-500">حفظ الانضباط وإدارة المزاج · بدون تحفيز على كثرة التداول</div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-50">
            مركز الانضباط، عقد الصفقة، ومراجعة ما بعد التداول
          </h1>
        </div>

        <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
          {([
            ['overview', 'الوضع والانضباط'],
            ['new_plan', 'عقد صفقة جديدة'],
            ['review', 'مراجعة وإغلاق صفقة'],
          ] as const).map(([id, lbl]) => (
            <button
              key={id}
              type="button"
              onClick={() => setSection(id)}
              className={`px-3.5 py-2 rounded-md text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                section === id
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              {lbl}
            </button>
          ))}
        </div>
      </div>

      {msg && (
        <div className="rounded-xl border border-emerald-300 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/30 p-4 text-sm text-emerald-900 dark:text-emerald-100">
          {msg}
        </div>
      )}
      {err && (
        <div className="rounded-xl border border-rose-300 dark:border-rose-800 bg-rose-50 dark:bg-rose-950/30 p-4 text-sm text-rose-900 dark:text-rose-100">
          {err}
        </div>
      )}

      {section === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
              <div className="text-xs text-slate-500">درجة الانضباط</div>
              <div className="text-2xl font-bold tabular-nums mt-1">{formatNum(traderState.discipline_score * 100, numerals, 0)}%</div>
              <div className="text-xs text-slate-500 mt-1">
                {traderState.upgrade_eligible ? 'مؤهل لمستوى ترقية أعلى' : 'الترقية تتطلب ٨٠%+ على ٢٠ صفقة'}
              </div>
            </div>
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
              <div className="text-xs text-slate-500">مؤشر الانفعال (Tilt)</div>
              <div className={`text-2xl font-bold tabular-nums mt-1 ${traderState.tilt_score >= 60 ? 'text-rose-700' : 'text-emerald-700'}`}>
                {formatNum(traderState.tilt_score, numerals, 0)} / 100
              </div>
              <div className="text-xs text-slate-500 mt-1">
                {traderState.tilt_score >= 60 ? 'انفعال مرتفع — ينصح بالراحة' : 'توازن سلوكي طبيعي'}
              </div>
            </div>
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
              <div className="text-xs text-slate-500">تكلفة كسر القواعد التراكمية</div>
              <div className="text-2xl font-bold text-rose-700 tabular-nums mt-1">{formatEgp(rule_break_cost_egp, numerals)}</div>
              <div className="text-xs text-slate-500 mt-1">خسارة كان يمكن تفاديها بالخطة</div>
            </div>
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-2">
              <div className="text-xs text-slate-500">المزاج ووضع المرافق</div>
              <select
                aria-label="وضع المرافق"
                value={traderState.mode}
                onChange={(e) => handleModeOrMoodChange({ mode: e.target.value as TraderMode })}
                className="w-full rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-2.5 py-1.5 text-xs"
              >
                <option value="manager">مدير محفظة (Manager)</option>
                <option value="advisor">مستشار (Advisor)</option>
                <option value="hybrid">مختلط (Hybrid)</option>
              </select>
              <select
                aria-label="تسجيل الحالة النفسية"
                value={traderState.mood}
                onChange={(e) => handleModeOrMoodChange({ mood: e.target.value as TraderMood })}
                className="w-full rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-2.5 py-1.5 text-xs"
              >
                <option value="calm">هادي ومركّز</option>
                <option value="tense">متوتر / مضغوط</option>
                <option value="excited">متحمس بزيادة</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
              <h2 className="text-sm font-bold">سجل الصفقات والمخالفات</h2>
              {trades.length === 0 ? (
                <p className="text-xs text-slate-500 py-4">لا توجد صفقات مغلقة بعد.</p>
              ) : (
                <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                  {trades.slice(0, 8).map((t) => (
                    <div key={t.id} className="py-2.5 flex items-center justify-between gap-3">
                      <div>
                        <span className="font-bold text-slate-900 dark:text-slate-100">{t.symbol}</span>
                        <span className="text-slate-500 mr-2">· {formatDateAr(t.executed_at)}</span>
                        <div className="text-slate-500 mt-0.5">
                          {t.plan_adhered ? 'التزام بالخطة' : `انحراف: ${t.deviation_tags.join(', ')}`}
                        </div>
                      </div>
                      <div className="text-left tabular-nums">
                        <div className={`font-bold ${t.net_pnl_egp >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                          {formatEgp(t.net_pnl_egp, numerals)} ({formatPct(t.net_return_pct, numerals)})
                        </div>
                        {t.rule_break_cost_egp > 0 && (
                          <div className="text-rose-600">تكلفة الانحراف: {formatEgp(t.rule_break_cost_egp, numerals)}</div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-bold">عقود التداول الموقعة ({plans.length})</h2>
                <button
                  type="button"
                  onClick={() => onNavigate('portfolio')}
                  className="text-xs underline text-slate-600"
                >
                  عرض المحفظة
                </button>
              </div>
              {plans.length === 0 ? (
                <p className="text-xs text-slate-500 py-4">لم توقّع أي عقد صفقة بعد.</p>
              ) : (
                <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                  {plans.slice(0, 6).map((pl) => (
                    <div key={pl.id} className="py-2.5 space-y-1">
                      <div className="flex justify-between font-semibold">
                        <span>{pl.symbol} · دخول {formatNum(pl.entry, numerals, 2)} · وقف {formatNum(pl.stop, numerals, 2)}</span>
                        <span className="tabular-nums">{formatNum(pl.size_pct, numerals, 1)}%</span>
                      </div>
                      <p className="text-slate-600 dark:text-slate-400">{pl.reason}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {section === 'new_plan' && (
        <form
          onSubmit={handleCreatePlan}
          className="max-w-2xl rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4"
        >
          <h2 className="text-base font-bold">توقيع عقد التداول المسبق (وقف الخسارة إجباري)</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium mb-1">السهم</label>
              <select
                value={planSymbol}
                onChange={(e) => {
                  const s = e.target.value;
                  setPlanSymbol(s);
                  const found = stocks.find((x) => x.symbol === s);
                  if (found) {
                    setPlanEntry(found.price);
                    setPlanStop(Number((found.price * 0.95).toFixed(2)));
                    setPlanTarget(Number((found.price * 1.08).toFixed(2)));
                  }
                }}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm"
              >
                {stocks.map((s) => (
                  <option key={s.symbol} value={s.symbol}>
                    {s.symbol} — {s.name_ar}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">حجم الصفقة (% من المحفظة)</label>
              <input
                type="number"
                min={1}
                max={40}
                value={planSizePct}
                onChange={(e) => setPlanSizePct(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm tabular-nums"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">سعر الدخول</label>
              <input
                type="number"
                step="0.01"
                value={planEntry}
                onChange={(e) => setPlanEntry(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm tabular-nums"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-rose-700 dark:text-rose-400 mb-1">
                وقف الخسارة (أقل من الدخول — إجباري)
              </label>
              <input
                type="number"
                step="0.01"
                value={planStop}
                onChange={(e) => setPlanStop(Number(e.target.value))}
                className="w-full rounded-lg border border-rose-300 dark:border-rose-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm tabular-nums"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">الهدف الأول</label>
              <input
                type="number"
                step="0.01"
                value={planTarget}
                onChange={(e) => setPlanTarget(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm tabular-nums"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">الحالة المزاجية عند التوقيع</label>
              <select
                value={planMood}
                onChange={(e) => setPlanMood(e.target.value as TraderMood)}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm"
              >
                <option value="calm">هادي</option>
                <option value="tense">متوتر</option>
                <option value="excited">متحمس</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium mb-1">لماذا تدخل هذه الصفقة؟</label>
            <textarea
              rows={2}
              required
              placeholder="مثال: السهم قريب من دعم أسبوعي مع سيولة صحية ومضاعف ربحية منخفض..."
              value={planReason}
              onChange={(e) => setPlanReason(e.target.value)}
              className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 p-3 text-sm"
            />
          </div>

          <label className="flex items-center gap-2 text-xs cursor-pointer">
            <input type="checkbox" checked={openPaperFill} onChange={(e) => setOpenPaperFill(e.target.checked)} />
            <span>فتح مركز تجريبي (Paper Fill) بالمحفظة فوراً مع توقيع العقد</span>
          </label>

          <button
            type="submit"
            className="px-5 py-2.5 rounded-lg text-xs font-semibold bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900"
          >
            توقيع عقد الصفقة
          </button>
        </form>
      )}

      {section === 'review' && (
        <form
          onSubmit={handleCloseTrade}
          className="max-w-2xl rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4"
        >
          <h2 className="text-base font-bold">مراجعة ما بعد الصفقة وحساب تكلفة كسر القواعد</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium mb-1">السهم</label>
              <input
                type="text"
                value={revSymbol}
                onChange={(e) => setRevSymbol(e.target.value.toUpperCase())}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">سعر الإغلاق الفعلي</label>
              <input
                type="number"
                step="0.01"
                value={revExitPrice}
                onChange={(e) => setRevExitPrice(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm tabular-nums"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">السبب الرئيسي للنتيجة</label>
              <select
                value={revCause}
                onChange={(e) => setRevCause(e.target.value as typeof revCause)}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm"
              >
                <option value="execution">انضباط التنفيذ</option>
                <option value="analysis">جودة التحليل</option>
                <option value="market">حركة السوق العامة</option>
                <option value="luck">عوامل غير متوقعة</option>
              </select>
            </div>
          </div>

          <div className="space-y-2">
            <span className="block text-xs font-medium">هل حدث أي انحراف عن الخطة؟</span>
            <div className="flex flex-wrap gap-2">
              {([
                ['none', 'التزام كامل بالخطة'],
                ['early_exit', 'خروج مبكر قبل الهدف'],
                ['no_stop', 'عدم تنفيذ وقف الخسارة'],
                ['oversize', 'حجم أكبر من الخطة'],
                ['revenge', 'تداول انتقامي'],
                ['fomo', 'مطاردة السعر (FOMO)'],
              ] as const).map(([tag, lbl]) => {
                const active = revTags.includes(tag);
                return (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => toggleTag(tag)}
                    className={`px-3 py-1.5 rounded-md text-xs font-medium border transition-colors ${
                      active
                        ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 border-slate-900'
                        : 'border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    {lbl}
                  </button>
                );
              })}
            </div>
          </div>

          <button
            type="submit"
            className="px-5 py-2.5 rounded-lg text-xs font-semibold bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900"
          >
            تسجيل الإغلاق وحساب التكلفة الصافية
          </button>
        </form>
      )}
    </div>
  );
};
