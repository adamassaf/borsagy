import React, { useEffect, useState } from 'react';
import { AppRoute } from '../components/Navbar';
import { api } from '../lib/api';
import { NumeralMode, formatDateAr, formatInt, formatNum, formatPct } from '../lib/formatters';

export const TrackRecordPage: React.FC<{
  numerals: NumeralMode;
  onNavigate: (r: AppRoute, param?: string) => void;
}> = ({ numerals, onNavigate }) => {
  const [data, setData] = useState<Awaited<ReturnType<typeof api.getTrackRecord>> | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api
      .getTrackRecord()
      .then(setData)
      .catch((e) => setError(e instanceof Error ? e.message : 'تعذر تحميل السجل العام.'))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="py-12 text-center text-sm text-slate-500">جاري التحقق من سلسلة الختم الرقمي...</div>;
  if (error || !data) return <div className="rounded-xl border border-rose-300 bg-rose-50 p-6 text-sm text-rose-800">{error}</div>;

  const { seal_verification, summary, calibration_curve, outcomes, advices } = data;

  return (
    <div className="space-y-8 py-4">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <div className="text-xs text-slate-500 dark:text-slate-400">
            ميثاق الشفافية: ننشر أخطاءنا كما ننشر نجاحنا · سلسلة SHA-256 متصلة
          </div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-50 mt-0.5">
            السجل العام المنشور ومنحنى المعايرة (Calibration)
          </h1>
        </div>
        <div
          className={`text-xs font-semibold px-3 py-2 rounded-lg border ${
            seal_verification.valid
              ? 'border-emerald-300 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/30 text-emerald-900 dark:text-emerald-200'
              : 'border-rose-300 bg-rose-50 text-rose-800'
          }`}
        >
          {seal_verification.valid
            ? `سلامة السلسلة موثقة (${formatInt(seal_verification.total, numerals)} سجل مختوم)`
            : 'تنبيه: خلل في سلسلة التوثيق'}
        </div>
      </div>

      {/* KPI Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
          <div className="text-xs text-slate-500">توصيات رابحة (بعد التكلفة)</div>
          <div className="text-2xl font-bold text-emerald-700 tabular-nums mt-1">{formatInt(summary.wins, numerals)}</div>
        </div>
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
          <div className="text-xs text-slate-500">توصيات خاسرة (منشورة)</div>
          <div className="text-2xl font-bold text-rose-700 tabular-nums mt-1">{formatInt(summary.losses, numerals)}</div>
        </div>
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
          <div className="text-xs text-slate-500">قرارات امتناع وقائية ناجحة</div>
          <div className="text-2xl font-bold text-slate-900 dark:text-slate-100 tabular-nums mt-1">
            {formatInt(summary.abstained_correctly, numerals)}
          </div>
        </div>
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
          <div className="text-xs text-slate-500">نسبة الإصابة الفعلية</div>
          <div className="text-2xl font-bold tabular-nums mt-1">{formatNum(summary.win_rate_pct, numerals, 0)}%</div>
        </div>
      </div>

      {/* Calibration Curve (SVG) + Outcomes List */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
          <div>
            <h2 className="text-sm font-bold">دقة توقع الثقة (Brier Calibration)</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              مقارنة نسبة الثقة المتوقعة مقابل التحقق الفعلي للنتائج
            </p>
          </div>
          <div className="space-y-3">
            {calibration_curve.map((row) => (
              <div key={row.bucket_label} className="space-y-1 text-xs">
                <div className="flex justify-between tabular-nums">
                  <span className="text-slate-600 dark:text-slate-300">نطاق ثقة {row.bucket_label}</span>
                  <span className="font-semibold">تحقق فعلي: {formatNum(row.actual_hit_pct, numerals, 0)}%</span>
                </div>
                <div className="h-2 w-full bg-slate-100 dark:bg-slate-800 rounded-sm overflow-hidden">
                  <div className="h-full bg-slate-900 dark:bg-slate-100" style={{ width: `${row.actual_hit_pct}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-7 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
          <h2 className="text-sm font-bold">دفتر النتائج المختومة (يشمل الخسائر والامتناع)</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-right border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500">
                  <th className="py-2 font-medium">السهم</th>
                  <th className="py-2 font-medium">النتيجة</th>
                  <th className="py-2 font-medium text-left">الصافي</th>
                  <th className="py-2 font-medium">السبب</th>
                  <th className="py-2 font-medium">بصمة الختم (SHA-256)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {outcomes.map((o) => {
                  const adv = advices.find((a) => a.id === o.advice_id);
                  return (
                    <tr key={o.advice_id}>
                      <td className="py-2.5 font-bold">
                        <button
                          type="button"
                          onClick={() => onNavigate('advice', o.advice_id)}
                          className="hover:underline"
                        >
                          {o.symbol}
                        </button>
                      </td>
                      <td
                        className={`py-2.5 font-semibold ${
                          o.result === 'win'
                            ? 'text-emerald-700'
                            : o.result === 'loss'
                              ? 'text-rose-700'
                              : 'text-slate-600'
                        }`}
                      >
                        {o.result === 'win' ? 'ربح' : o.result === 'loss' ? 'خسارة' : 'امتناع صائب'}
                      </td>
                      <td className="py-2.5 text-left font-mono tabular-nums">{formatPct(o.net_return_pct, numerals)}</td>
                      <td className="py-2.5 text-slate-500">{o.cause} · {formatDateAr(o.resolved_at)}</td>
                      <td className="py-2.5 font-mono text-slate-400">
                        {adv?.seal_hash ? `${adv.seal_hash.slice(0, 12)}…` : '—'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </div>
  );
};
