import React, { useEffect, useState } from 'react';
import { AppRoute } from '../components/Navbar';
import { api } from '../lib/api';
import { NumeralMode, formatNum } from '../lib/formatters';

export const SettingsPage: React.FC<{
  traderId: string;
  onTraderPreferencesUpdated: () => void;
  onAccountDeleted: () => void;
  onNavigate: (r: AppRoute) => void;
}> = ({ traderId, onTraderPreferencesUpdated, onAccountDeleted, onNavigate }) => {
  const [data, setData] = useState<Awaited<ReturnType<typeof api.getPortfolioRisk>> | null>(null);
  const [dialect, setDialect] = useState<'egyptian' | 'gulf' | 'levantine'>('egyptian');
  const [numerals, setNumerals] = useState<NumeralMode>('western');
  const [lowBandwidth, setLowBandwidth] = useState(false);
  const [quietStart, setQuietStart] = useState('23:00');
  const [quietEnd, setQuietEnd] = useState('08:00');
  const [budget, setBudget] = useState(5);
  const [dailyLoss, setDailyLoss] = useState(2);
  const [weeklyLoss, setWeeklyLoss] = useState(5);
  const [observerName, setObserverName] = useState('');
  const [observerContact, setObserverContact] = useState('');
  const [observerConsent, setObserverConsent] = useState(false);

  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);
  const [exportJson, setExportJson] = useState<string | null>(null);

  useEffect(() => {
    api.getPortfolioRisk(traderId).then((res) => {
      setData(res);
      setDialect(res.trader.dialect);
      setNumerals(res.trader.numerals);
      setLowBandwidth(res.trader.low_bandwidth);
      setQuietStart(res.trader.quiet_hours.start);
      setQuietEnd(res.trader.quiet_hours.end);
      setBudget(res.trader.daily_alert_budget);
      setDailyLoss(res.profile.daily_loss_limit_pct);
      setWeeklyLoss(res.profile.weekly_loss_limit_pct);
      setObserverName(res.trader.trusted_observer?.name ?? '');
      setObserverContact(res.trader.trusted_observer?.contact ?? '');
      setObserverConsent(Boolean(res.trader.trusted_observer?.consented));
    });
  }, [traderId]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setMsg(null);
    setErr(null);
    try {
      await api.updateSettings(
        {
          dialect,
          numerals,
          low_bandwidth: lowBandwidth,
          quiet_hours: { start: quietStart, end: quietEnd },
          daily_alert_budget: budget,
          daily_loss_limit_pct: dailyLoss,
          weekly_loss_limit_pct: weeklyLoss,
          trusted_observer:
            observerConsent && observerName.trim()
              ? { name: observerName.trim(), contact: observerContact.trim(), consented: true }
              : null,
        },
        traderId
      );
      setMsg('تم حفظ الإعدادات وتحديث التفضيلات.');
      onTraderPreferencesUpdated();
    } catch (e2) {
      setErr(e2 instanceof Error ? e2.message : 'تعذر حفظ الإعدادات.');
    }
  };

  const handleExport = async () => {
    const dump = await api.exportMyData(traderId);
    setExportJson(JSON.stringify(dump, null, 2));
  };

  const handleDeleteCascade = async () => {
    try {
      const res = await api.deleteMeCascade(traderId);
      setConfirmDeleteOpen(false);
      setMsg(res.message_ar);
      onAccountDeleted();
      onNavigate('welcome');
    } catch (e2) {
      setErr(e2 instanceof Error ? e2.message : 'تعذر حذف الحساب.');
    }
  };

  if (!data) return <div className="py-12 text-center text-sm text-slate-500">جاري تحميل الإعدادات...</div>;

  return (
    <div className="max-w-3xl mx-auto space-y-8 py-4">
      <div>
        <div className="text-xs text-slate-500">اللغة الرسمية المبسطة · سيادة كاملة على بياناتك</div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-50 mt-0.5">الإعدادات والخصوصية</h1>
      </div>

      {msg && (
        <div className="rounded-xl border border-emerald-300 bg-emerald-50 p-4 text-sm text-emerald-900">{msg}</div>
      )}
      {err && <div className="rounded-xl border border-rose-300 bg-rose-50 p-4 text-sm text-rose-900">{err}</div>}

      <form
        onSubmit={handleSave}
        className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-5"
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium mb-1">اللهجة المفضلة للمرافق</label>
            <select
              value={dialect}
              onChange={(e) => setDialect(e.target.value as typeof dialect)}
              className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm"
            >
              <option value="egyptian">مصري (افتراضي)</option>
              <option value="gulf">خليجي</option>
              <option value="levantine">شامي</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium mb-1">شكل الأرقام</label>
            <select
              value={numerals}
              onChange={(e) => setNumerals(e.target.value as NumeralMode)}
              className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm"
            >
              <option value="western">أرقام غربية (123.45)</option>
              <option value="arabic_indic">أرقام عربية هندية (١٢٣٫٤٥)</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium mb-1">
              حد الخسارة اليومي (%) — الحالي {formatNum(dailyLoss, numerals, 1)}%
            </label>
            <input
              type="number"
              step="0.5"
              min={0.5}
              max={data.profile.experience === 'beginner' ? 3 : 5}
              value={dailyLoss}
              onChange={(e) => setDailyLoss(Number(e.target.value))}
              className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm tabular-nums"
            />
          </div>
          <div>
            <label className="block text-xs font-medium mb-1">
              حد الخسارة الأسبوعي (%) — الحالي {formatNum(weeklyLoss, numerals, 1)}%
            </label>
            <input
              type="number"
              step="0.5"
              min={1}
              max={data.profile.experience === 'beginner' ? 8 : 12}
              value={weeklyLoss}
              onChange={(e) => setWeeklyLoss(Number(e.target.value))}
              className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm tabular-nums"
            />
          </div>
          <div>
            <label className="block text-xs font-medium mb-1">بداية ساعات الهدوء</label>
            <input
              type="time"
              value={quietStart}
              onChange={(e) => setQuietStart(e.target.value)}
              className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-medium mb-1">نهاية ساعات الهدوء</label>
            <input
              type="time"
              value={quietEnd}
              onChange={(e) => setQuietEnd(e.target.value)}
              className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-medium mb-1">ميزانية التنبيهات اليومية (بحد أقصى ١٠)</label>
            <input
              type="number"
              min={1}
              max={10}
              value={budget}
              onChange={(e) => setBudget(Number(e.target.value))}
              className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm tabular-nums"
            />
          </div>
          <label className="flex items-center gap-2 text-xs pt-5 cursor-pointer">
            <input type="checkbox" checked={lowBandwidth} onChange={(e) => setLowBandwidth(e.target.checked)} />
            <span>وضع توفير الإنترنت (Low-Bandwidth Mode)</span>
          </label>
        </div>

        <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
          <h2 className="text-sm font-bold">مراقب عائلي موثوق (اختياري وبموافقتك فقط)</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <input
              type="text"
              placeholder="اسم الشخص الموثوق"
              value={observerName}
              onChange={(e) => setObserverName(e.target.value)}
              className="rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm"
            />
            <input
              type="text"
              placeholder="وسيلة التواصل الاختيارية"
              value={observerContact}
              onChange={(e) => setObserverContact(e.target.value)}
              className="rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm"
            />
          </div>
          <label className="flex items-center gap-2 text-xs cursor-pointer">
            <input
              type="checkbox"
              checked={observerConsent}
              onChange={(e) => setObserverConsent(e.target.checked)}
            />
            <span>أوافق على مشاركة ملخص حالة الإيقاف الوقائي فقط عند كسر حدود الخسارة</span>
          </label>
        </div>

        <button
          type="submit"
          className="px-5 py-2.5 rounded-lg text-xs font-semibold bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900"
        >
          حفظ الإعدادات
        </button>
      </form>

      {/* Privacy & Cascade Delete */}
      <section className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
        <h2 className="text-base font-bold">تصدير بياناتك أو الحذف النهائي الكامل</h2>
        <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
          طبقاً للبند العاشر من الميثاق، يمكنك تنزيل نسخة كاملة من بياناتك أو حذف حسابك مع جميع مراكزك وخططك ونصائحك الشخصية وما اشتُق منها بضغطة واحدة.
        </p>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={handleExport}
            className="px-4 py-2 rounded-lg text-xs font-semibold border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800"
          >
            تصدير بياناتي (JSON)
          </button>

          {!confirmDeleteOpen ? (
            <button
              type="button"
              onClick={() => setConfirmDeleteOpen(true)}
              className="px-4 py-2 rounded-lg text-xs font-semibold border border-rose-300 text-rose-700 hover:bg-rose-50"
            >
              حذف بياناتي نهائياً
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleDeleteCascade}
                className="px-4 py-2 rounded-lg text-xs font-semibold bg-rose-700 text-white"
              >
                تأكيد الحذف الكامل الآن
              </button>
              <button
                type="button"
                onClick={() => setConfirmDeleteOpen(false)}
                className="px-3 py-2 rounded-lg text-xs border border-slate-300"
              >
                إلغاء
              </button>
            </div>
          )}
        </div>

        {exportJson && (
          <pre className="p-3 rounded-lg bg-slate-950 text-slate-100 text-[11px] overflow-x-auto max-h-64 font-mono">
            {exportJson}
          </pre>
        )}
      </section>
    </div>
  );
};
