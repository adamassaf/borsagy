import React, { useEffect, useState } from 'react';
import { api } from '../lib/api';
import { NumeralMode, formatEgp, formatInt, formatNum } from '../lib/formatters';

export const BrokersPage: React.FC<{ numerals: NumeralMode }> = ({ numerals }) => {
  const [data, setData] = useState<Awaited<ReturnType<typeof api.getBrokers>> | null>(null);
  const [ticket, setTicket] = useState(15000);
  const [tradesMonth, setTradesMonth] = useState(6);
  const [calcRows, setCalcRows] = useState<
    Array<{ broker_id: string; name_ar: string; verified: boolean; per_order_total_egp: number | null; annual_cost_egp: number | null; note_ar?: string }>
  >([]);

  useEffect(() => {
    api.getBrokers().then(setData);
  }, []);

  useEffect(() => {
    api.calculateBrokerFees(ticket, tradesMonth).then((r) => setCalcRows(r.rows));
  }, [ticket, tradesMonth]);

  if (!data) return <div className="py-12 text-center text-sm text-slate-500">جاري تحميل بيانات شركات السمسرة...</div>;

  return (
    <div className="space-y-8 py-4">
      <div className="space-y-1">
        <div className="text-xs text-slate-500 dark:text-slate-400">
          تقييم محايد بالكامل · لا إعلانات ولا ترتيب مدفوع لشركات التداول
        </div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-50">
          اختر شركة السمسرة المناسبة (تصنيف الربع الثالث ٢٠٢٦)
        </h1>
        <p className="text-xs text-slate-600 dark:text-slate-300">
          تنويه الصدق: نعرض الرسوم المؤكدة رسمياً فقط، وأي جدول رسوم لم يوثق من قائمة الأسعار الرسمية يبقى بحالة «قيد الجمع الرسمي» بدون تخمين.
        </p>
      </div>

      {/* Personalized Fee Calculator */}
      <section className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
        <h2 className="text-base font-bold">حاسبة التكلفة السنوية المخصصة</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-xl">
          <div>
            <label className="block text-xs font-medium mb-1">متوسط حجم الصفقة الواحدة (ج.م)</label>
            <input
              type="number"
              min={500}
              step={1000}
              value={ticket}
              onChange={(e) => setTicket(Number(e.target.value))}
              className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm tabular-nums"
            />
          </div>
          <div>
            <label className="block text-xs font-medium mb-1">عدد الصفقات شهرياً</label>
            <input
              type="number"
              min={1}
              max={100}
              value={tradesMonth}
              onChange={(e) => setTradesMonth(Number(e.target.value))}
              className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm tabular-nums"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-right border-collapse">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500">
                <th className="py-2 font-medium">الشركة</th>
                <th className="py-2 font-medium">حالة الرسوم</th>
                <th className="py-2 font-medium text-left">تكلفة الصفقة (عمولة + رسوم)</th>
                <th className="py-2 font-medium text-left">التكلفة السنوية المقدرة</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {calcRows.map((r) => (
                <tr key={r.broker_id}>
                  <td className="py-2.5 font-semibold text-slate-900 dark:text-slate-100">{r.name_ar}</td>
                  <td className="py-2.5">
                    {r.verified ? (
                      <span className="text-emerald-700 dark:text-emerald-400 font-semibold">موثق من السعر الرسمي</span>
                    ) : (
                      <span className="text-amber-700 dark:text-amber-400">غير مؤكد — قيد الجمع الرسمي</span>
                    )}
                  </td>
                  <td className="py-2.5 text-left font-mono tabular-nums">
                    {r.per_order_total_egp !== null ? formatEgp(r.per_order_total_egp, numerals) : '—'}
                  </td>
                  <td className="py-2.5 text-left font-mono tabular-nums font-bold">
                    {r.annual_cost_egp !== null ? formatEgp(r.annual_cost_egp, numerals) : 'لم يُفترض رقم'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Top 10 EGX Brokers Q3 2026 Table */}
      <section className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
        <h2 className="text-base font-bold">أكبر ١٠ شركات سمسرة في البورصة المصرية</h2>
        <div className="divide-y divide-slate-100 dark:divide-slate-800">
          {data.brokers.map((b) => {
            const comm = b.fees.find((f) => f.fee_type === 'commission');
            return (
              <div key={b.id} className="py-4 grid grid-cols-1 md:grid-cols-12 gap-4 items-start text-xs">
                <div className="md:col-span-4 space-y-1">
                  <div className="text-sm font-bold text-slate-900 dark:text-slate-100">
                    #{formatInt(b.rank_q3_2026, numerals)} · {b.name_ar}
                  </div>
                  <div className="text-slate-500">
                    الحصة السوقية: {formatNum(b.market_share_pct, numerals, 1)}% · {formatNum(b.traded_value_bn_egp, numerals, 1)} مليار ج.م
                  </div>
                  <div className="text-slate-400">المصدر: {b.share_source} ({b.share_period})</div>
                </div>

                <div className="md:col-span-4 space-y-1 text-slate-600 dark:text-slate-300">
                  <div>
                    <span className="font-semibold">الأنسب لـ: </span>
                    {b.best_for_ar}
                  </div>
                  <div>{b.app_quality_note_ar}</div>
                </div>

                <div className="md:col-span-4 space-y-1">
                  <div className="font-semibold text-slate-900 dark:text-slate-100">
                    العمولة المعلنة:{' '}
                    {comm?.status === 'verified' && comm.value !== null ? (
                      <span className="text-emerald-700 dark:text-emerald-400">
                        {formatNum(comm.value, numerals, 2)}% (موثق: {comm.conditions_ar})
                      </span>
                    ) : (
                      <span className="text-amber-700 dark:text-amber-400">غير مؤكد — قيد الجمع الرسمي</span>
                    )}
                  </div>
                  <div className="text-slate-500">{b.referral_disclosure_ar}</div>
                </div>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
};
