import React, { useEffect, useRef, useState } from 'react';
import { Bot, ChevronLeft, ChevronRight, ExternalLink, Play, ShieldCheck, Sparkles, X } from 'lucide-react';
import { AppRoute } from '../components/Navbar';
import { getAgentUsageGuide } from '../core/agentsCatalog';
import { AgentDefinition, SubscriptionTierId } from '../core/types';
import { api } from '../lib/api';
import { NumeralMode, formatInt, formatNum } from '../lib/formatters';

const TIER_LABELS: Record<SubscriptionTierId, string> = {
  free: 'المجانية (Free)',
  plus: 'بلس (Plus)',
  pro: 'برو (Pro)',
  b2b: 'المؤسسات (B2B)',
};

const TIER_SHORT: Record<SubscriptionTierId, string> = {
  free: 'المجانية',
  plus: 'بلس',
  pro: 'برو',
  b2b: 'B2B',
};

type AgentCatalogItem = AgentDefinition & { unlocked: boolean };
type RunResult = Awaited<ReturnType<typeof api.runAgent>>;

interface CopilotMessage {
  role: 'user' | 'assistant';
  text: string;
  usedAi?: boolean;
  aiError?: string;
}

export const AgentsPage: React.FC<{
  traderId: string;
  numerals: NumeralMode;
  onSubscriptionChanged?: () => void;
  onNavigate: (route: AppRoute, param?: string) => void;
}> = ({ traderId, numerals, onSubscriptionChanged, onNavigate }) => {
  const [group, setGroup] = useState('all');
  const [tier, setTier] = useState('all');
  const [q, setQ] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [catalog, setCatalog] = useState<Awaited<ReturnType<typeof api.getAgents>> | null>(null);
  const [allAgents, setAllAgents] = useState<AgentCatalogItem[]>([]);

  const [stocks, setStocks] = useState<Array<{ symbol: string; name_ar: string }>>([]);
  const [selectedSymbol, setSelectedSymbol] = useState('COMI');
  const [runningId, setRunningId] = useState<number | null>(null);
  const [runResult, setRunResult] = useState<RunResult | null>(null);
  const [tierNotice, setTierNotice] = useState<string | null>(null);
  const [activatingTier, setActivatingTier] = useState<SubscriptionTierId | null>(null);

  // Copilot & Interactive Agent Drawer State
  const [drawerAgent, setDrawerAgent] = useState<AgentCatalogItem | null>(null);
  const [copilotInput, setCopilotInput] = useState('');
  const [copilotBusy, setCopilotBusy] = useState(false);
  const [copilotError, setCopilotError] = useState<string | null>(null);
  const [copilotHistory, setCopilotHistory] = useState<Record<number, CopilotMessage[]>>({});
  const [copilotSuggestions, setCopilotSuggestions] = useState<Record<number, string[]>>({});
  const copilotEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    api
      .getMovers({ timeframe: '1d' })
      .then((res) => setStocks(res.stocks.map((s) => ({ symbol: s.symbol, name_ar: s.name_ar }))))
      .catch(() => {});
  }, []);

  const loadCatalog = async (silent = false) => {
    if (!silent) setLoading(true);
    setError(null);
    try {
      const res = await api.getAgents({ group, tier, q }, traderId);
      setCatalog(res);
      if (group === 'all' && tier === 'all' && !q.trim()) {
        setAllAgents(res.agents);
      } else if (allAgents.length === 0) {
        const full = await api.getAgents({ group: 'all', tier: 'all', q: '' }, traderId);
        setAllAgents(full.agents);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'تعذر تحميل كتالوج الوكلاء.');
    } finally {
      if (!silent) setLoading(false);
    }
  };

  useEffect(() => {
    loadCatalog(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [group, tier, q, traderId]);

  useEffect(() => {
    if (!drawerAgent) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setDrawerAgent(null);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [drawerAgent]);

  const activeAgentHistoryLen = drawerAgent ? (copilotHistory[drawerAgent.number] ?? []).length : 0;
  useEffect(() => {
    if (activeAgentHistoryLen > 0) {
      copilotEndRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }, [activeAgentHistoryLen]);

  const openAgentAndRun = async (agentItem: AgentCatalogItem, sym = selectedSymbol) => {
    setDrawerAgent(agentItem);
    setCopilotError(null);
    setTierNotice(null);
    setRunningId(agentItem.number);
    setError(null);
    try {
      const res = await api.runAgent(agentItem.number, sym, traderId);
      setRunResult(res);
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'تعذر تشغيل الوكيل.';
      setError(msg);
      setCopilotError(msg);
    } finally {
      setRunningId(null);
    }
  };

  const handleActivateTierPreview = async (targetTier: SubscriptionTierId) => {
    setActivatingTier(targetTier);
    setTierNotice(null);
    setError(null);
    try {
      const res = await api.selectSubscription(targetTier, 'monthly', traderId);
      setTierNotice(
        `تم تفعيل باقة ${TIER_LABELS[targetTier]} بنجاح — متاح لك الآن ${formatInt(res.unlocked_agents_count, numerals)} وكيلاً مفعّلاً للتشغيل المباشر.`
      );
      if (drawerAgent) {
        setDrawerAgent((prev) => (prev ? { ...prev, unlocked: true } : prev));
      }
      const full = await api.getAgents({ group: 'all', tier: 'all', q: '' }, traderId);
      setAllAgents(full.agents);
      await loadCatalog(true);
      onSubscriptionChanged?.();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'تعذر تفعيل الباقة.');
    } finally {
      setActivatingTier(null);
    }
  };

  const askCopilot = async (agentItem: AgentCatalogItem, questionText: string) => {
    const cleanQ = questionText.trim();
    if (!cleanQ) return;
    setCopilotBusy(true);
    setCopilotError(null);
    const prevMsgs = copilotHistory[agentItem.number] ?? [];
    const nextWithUser: CopilotMessage[] = [...prevMsgs, { role: 'user', text: cleanQ }];
    setCopilotHistory((h) => ({ ...h, [agentItem.number]: nextWithUser }));
    setCopilotInput('');

    try {
      const res = await api.askAgentCopilot(
        agentItem.number,
        {
          symbol: selectedSymbol,
          question: cleanQ,
          history: prevMsgs.map((m) => ({ role: m.role, text: m.text })),
        },
        traderId
      );
      setRunResult(res.execution);
      setCopilotHistory((h) => ({
        ...h,
        [agentItem.number]: [
          ...nextWithUser,
          { role: 'assistant', text: res.answer_ar, usedAi: res.used_ai, aiError: res.ai_error },
        ],
      }));
      setCopilotSuggestions((s) => ({ ...s, [agentItem.number]: res.suggested_questions_ar }));
    } catch (e) {
      setCopilotError(e instanceof Error ? e.message : 'تعذر الحصول على رد المساعد.');
    } finally {
      setCopilotBusy(false);
    }
  };

  const walkthroughList = (catalog?.agents && catalog.agents.length > 0 ? catalog.agents : allAgents) ?? [];
  const currentWalkthroughIndex = drawerAgent
    ? walkthroughList.findIndex((a) => a.number === drawerAgent.number)
    : -1;
  const fallbackPool = allAgents.length > 0 ? allAgents : walkthroughList;

  const stepAgent = (delta: -1 | 1) => {
    if (!drawerAgent || fallbackPool.length === 0) return;
    if (currentWalkthroughIndex >= 0 && walkthroughList.length > 1) {
      const nextIdx = (currentWalkthroughIndex + delta + walkthroughList.length) % walkthroughList.length;
      openAgentAndRun(walkthroughList[nextIdx]);
      return;
    }
    const poolIdx = fallbackPool.findIndex((a) => a.number === drawerAgent.number);
    const baseIdx = poolIdx >= 0 ? poolIdx : 0;
    const nextIdx = (baseIdx + delta + fallbackPool.length) % fallbackPool.length;
    openAgentAndRun(fallbackPool[nextIdx]);
  };

  const activeStockName = stocks.find((s) => s.symbol === selectedSymbol)?.name_ar ?? 'التجاري الدولي';
  const drawerGuide = drawerAgent
    ? runResult && runResult.agent.number === drawerAgent.number && runResult.symbol === selectedSymbol
      ? runResult.usage_guide
      : getAgentUsageGuide(drawerAgent, selectedSymbol, activeStockName)
    : null;
  const drawerRunMatches =
    drawerAgent && runResult && runResult.agent.number === drawerAgent.number ? runResult : null;

  return (
    <div className="space-y-8 py-4">
      {/* Header */}
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-6">
        <div className="space-y-1.5 max-w-3xl">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
            منظومة بورصجي المعرفية (borsagy.si) · ذكاء اصطناعي متقدم فوق أنطولوجيا ثنائية الزمن
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-slate-50">
            كتالوج الوكلاء الكامل ({formatInt(catalog?.total_agents ?? 84, numerals)} وكيلاً تحليلياً ورقابياً)
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
            شغّل أي وكيل على أي سهم، أو افتح المساعد التفاعلي (Copilot) لتصفح جميع الوكلاء الـ 84 واحداً تلو الآخر وفهم وظيفته وطريقة استخدامه خطوة بخطوة.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3.5 py-2 text-xs">
            <span className="text-slate-500">باقتك النشطة: </span>
            <span className="font-bold text-slate-900 dark:text-slate-100">
              {TIER_LABELS[catalog?.active_tier ?? 'free']}
            </span>
          </div>
          {catalog?.active_tier !== 'pro' && catalog?.active_tier !== 'b2b' && (
            <button
              type="button"
              disabled={activatingTier === 'pro'}
              onClick={() => handleActivateTierPreview('pro')}
              className="px-4 py-2 rounded-lg text-xs font-semibold bg-emerald-700 text-white hover:bg-emerald-800 transition-colors whitespace-nowrap disabled:opacity-60"
            >
              {activatingTier === 'pro' ? 'جاري التفعيل...' : 'تجربة باقة برو (Pro) الآن'}
            </button>
          )}
          <button
            type="button"
            onClick={() => onNavigate('pricing')}
            className="px-4 py-2 rounded-lg text-xs font-semibold bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 hover:bg-slate-800 transition-colors whitespace-nowrap"
          >
            مقارنة الباقات
          </button>
        </div>
      </div>

      {tierNotice && (
        <div
          role="status"
          className="rounded-xl border border-emerald-300 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/30 p-4 text-xs sm:text-sm text-emerald-900 dark:text-emerald-100 flex flex-wrap items-center justify-between gap-3"
        >
          <span className="font-semibold">{tierNotice}</span>
          <button
            type="button"
            onClick={() => setTierNotice(null)}
            className="text-xs underline underline-offset-4 text-emerald-800 dark:text-emerald-300"
          >
            إغلاق التنبيه
          </button>
        </div>
      )}

      {/* Guided Copilot Tour + Live Stock Runner Control Bar */}
      <section className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-1">
            <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <Bot className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
              <span>مختبر التشغيل الفوري + جولة المساعد التفاعلي (Copilot)</span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              اختر السهم المستهدف ثم اضغط «تشغيل على {selectedSymbol}» أو «دليل + Copilot» على أي بطاقة، أو ابدأ الجولة التفاعلية من الوكيل #1 حتى #84.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <label htmlFor="agent-runner-symbol" className="text-xs text-slate-600 dark:text-slate-300 whitespace-nowrap">
              السهم المستهدف:
            </label>
            <select
              id="agent-runner-symbol"
              value={selectedSymbol}
              onChange={(e) => {
                const sym = e.target.value;
                setSelectedSymbol(sym);
                if (drawerAgent) {
                  openAgentAndRun(drawerAgent, sym);
                }
              }}
              className="rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-xs font-semibold"
            >
              {(stocks.length > 0 ? stocks : [{ symbol: 'COMI', name_ar: 'التجاري الدولي' }]).map((s) => (
                <option key={s.symbol} value={s.symbol}>
                  {s.symbol} — {s.name_ar}
                </option>
              ))}
            </select>

            <button
              type="button"
              disabled={walkthroughList.length === 0}
              onClick={() => {
                const startTarget = walkthroughList[0] ?? fallbackPool[0];
                if (startTarget) openAgentAndRun(startTarget);
              }}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 hover:bg-slate-800 disabled:opacity-50"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>ابدأ جولة Copilot (واحداً تلو الآخر)</span>
            </button>
          </div>
        </div>

        {runResult && (
          <div className="rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="text-sm font-bold text-slate-900 dark:text-slate-100">
                #{formatInt(runResult.agent.number, numerals)} · {runResult.headline_ar}
              </div>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => {
                    const found = fallbackPool.find((a) => a.number === runResult.agent.number);
                    if (found) setDrawerAgent(found);
                  }}
                  className="text-xs font-semibold text-emerald-800 dark:text-emerald-300 underline underline-offset-4"
                >
                  افتح شرح Copilot والخطوات
                </button>
                <button
                  type="button"
                  onClick={() => onNavigate('stock', runResult.symbol)}
                  className="text-xs font-semibold underline underline-offset-4 text-slate-700 dark:text-slate-300"
                >
                  فتح بطاقة {runResult.symbol}
                </button>
              </div>
            </div>
            <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed">{runResult.summary_ar}</p>
            <p className="text-xs font-medium text-emerald-800 dark:text-emerald-300">{runResult.verdict_ar}</p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
              {runResult.metrics.map((m, idx) => (
                <div key={idx} className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3">
                  <div className="text-[11px] text-slate-500">{m.label_ar}</div>
                  <div className="text-sm font-bold tabular-nums text-slate-900 dark:text-slate-100 mt-0.5">{m.value}</div>
                  <div className="text-[10px] font-mono text-slate-400 mt-1 truncate">Fact: {m.source_fact_id}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </section>

      {/* Filters */}
      <section className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <input
            type="search"
            aria-label="بحث في الوكلاء الـ 84"
            placeholder="ابحث بالاسم أو الرقم أو الوظيفة (مثال: 68، السيولة، محامي الشيطان، الشرعي)..."
            value={q}
            onChange={(e) => setQ(e.target.value)}
            className="w-full sm:w-96 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2 text-sm"
          />

          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="text-slate-500">حسب الباقة:</span>
            {([
              ['all', 'الكل'],
              ['free', 'المجانية'],
              ['plus', 'بلس'],
              ['pro', 'برو'],
              ['b2b', 'B2B'],
            ] as const).map(([tId, label]) => (
              <button
                key={tId}
                type="button"
                onClick={() => setTier(tId)}
                className={`px-3 py-1.5 rounded-md font-medium border transition-colors ${
                  tier === tId
                    ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 border-slate-900 dark:border-slate-100'
                    : 'bg-white dark:bg-slate-900 border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* 11 Groups Navigation Tabs */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setGroup('all')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold border whitespace-nowrap shrink-0 ${
              group === 'all'
                ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 border-slate-900 dark:border-slate-100'
                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            كل المجموعات ({formatInt(84, numerals)})
          </button>
          {(catalog?.groups ?? []).map((g) => (
            <button
              key={g.key}
              type="button"
              onClick={() => setGroup(g.key)}
              className={`px-3 py-1.5 rounded-md text-xs font-medium border whitespace-nowrap shrink-0 ${
                group === g.key
                  ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 border-slate-900 dark:border-slate-100'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300'
              }`}
            >
              {g.code_ar}. {g.title_ar} ({g.range_label})
            </button>
          ))}
        </div>
      </section>

      {error && <div className="rounded-xl border border-rose-300 bg-rose-50 p-4 text-xs text-rose-900">{error}</div>}

      {loading ? (
        <div className="py-12 text-center text-sm text-slate-500">جاري تحميل منظومة الوكلاء...</div>
      ) : (
        <section className="space-y-3">
          <div className="text-xs text-slate-500 tabular-nums">
            المعروض حالياً: {formatInt(catalog?.filtered_count ?? 0, numerals)} من أصل {formatInt(catalog?.total_agents ?? 84, numerals)} وكيل
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {(catalog?.agents ?? []).map((ag) => (
              <article
                key={ag.id}
                className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 flex flex-col justify-between space-y-4"
              >
                <div className="space-y-2.5">
                  <div className="flex items-start justify-between gap-2 text-xs">
                    <span className="font-mono font-bold text-slate-500 tabular-nums">#{formatInt(ag.number, numerals)}</span>
                    <span className="text-[11px] text-slate-500 font-medium">
                      {TIER_LABELS[ag.tier]} · {ag.unlocked ? 'مفعّل بحسابك' : ag.enabled ? 'معاينة متاحة' : 'متوقف حوكمة'}
                    </span>
                  </div>

                  <div>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">{ag.name_ar}</h3>
                    <div className="text-[11px] font-mono text-slate-400">{ag.name_en}</div>
                  </div>

                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">{ag.output_ar}</p>

                  <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-1 text-[11px] text-slate-500">
                    <div>
                      <span className="font-semibold text-slate-700 dark:text-slate-300">يقرأ: </span>
                      {ag.reads_ar}
                    </div>
                    <div>
                      <span className="font-semibold text-slate-700 dark:text-slate-300">يكتب: </span>
                      {ag.writes_ar}
                    </div>
                  </div>
                </div>

                <div className="space-y-2.5 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
                  <div className="flex items-center justify-between text-[11px] text-slate-500 tabular-nums">
                    <span>دقة المعايرة: {formatNum(ag.calibration_hit_rate * 100, numerals, 0)}%</span>
                    <span>{ag.mode === 'deterministic' ? 'محرك حتمي' : ag.mode === 'hybrid' ? 'هجين منضبط' : 'نموذج ذكي/API'}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      disabled={!ag.enabled || runningId === ag.number}
                      onClick={() => openAgentAndRun(ag)}
                      className={`flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-md font-semibold text-xs transition-colors whitespace-nowrap ${
                        !ag.enabled
                          ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                          : ag.unlocked
                            ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 hover:bg-slate-800'
                            : 'bg-emerald-700 text-white hover:bg-emerald-800'
                      }`}
                    >
                      <Play className="w-3 h-3" />
                      <span>
                        {runningId === ag.number
                          ? 'جاري التشغيل...'
                          : ag.unlocked
                            ? `تشغيل على ${selectedSymbol}`
                            : `تجربة ${TIER_SHORT[ag.tier]} (${selectedSymbol})`}
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={() => openAgentAndRun(ag)}
                      className="inline-flex items-center gap-1 px-2.5 py-2 rounded-md border border-slate-300 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 whitespace-nowrap"
                      title="افتح دليل الاستخدام والمحادثة مع Copilot لهذا الوكيل"
                    >
                      <Bot className="w-3.5 h-3.5" />
                      <span>Copilot</span>
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </section>
      )}

      {/* Interactive One-by-One Agent Execution + Copilot Drawer */}
      {drawerAgent && (
        <div
          className="fixed inset-0 z-50 flex justify-end bg-slate-950/50 backdrop-blur-xs"
          onClick={(e) => {
            if (e.target === e.currentTarget) setDrawerAgent(null);
          }}
        >
          <aside
            role="dialog"
            aria-modal="true"
            aria-label={`تشغيل وشرح الوكيل #${drawerAgent.number}`}
            className="w-full max-w-2xl bg-white dark:bg-slate-900 h-full overflow-y-auto shadow-2xl border-r border-slate-200 dark:border-slate-800 flex flex-col"
          >
            {/* Sticky Top Header + One-by-One Stepper */}
            <div className="sticky top-0 z-10 bg-white/95 dark:bg-slate-900/95 backdrop-blur border-b border-slate-200 dark:border-slate-800 p-4 sm:p-5 space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="text-[11px] font-medium text-slate-500 flex flex-wrap items-center gap-2">
                    <span className="font-mono font-bold text-slate-700 dark:text-slate-300">
                      #{formatInt(drawerAgent.number, numerals)} / {formatInt(84, numerals)}
                    </span>
                    <span>·</span>
                    <span>{drawerAgent.group_ar}</span>
                    <span>·</span>
                    <span>{TIER_LABELS[drawerAgent.tier]}</span>
                  </div>
                  <h2 className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-slate-50 mt-0.5">
                    {drawerAgent.name_ar}
                  </h2>
                  <div className="text-xs font-mono text-slate-400">{drawerAgent.name_en}</div>
                </div>

                <button
                  type="button"
                  aria-label="إغلاق نافذة الوكيل"
                  onClick={() => setDrawerAgent(null)}
                  className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* One-by-One Walkthrough Controls */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => stepAgent(-1)}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-md border border-slate-300 dark:border-slate-700 text-xs font-semibold hover:bg-slate-50 dark:hover:bg-slate-800"
                  >
                    <ChevronRight className="w-3.5 h-3.5" />
                    <span>الوكيل السابق</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => stepAgent(1)}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-md bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 text-xs font-semibold hover:bg-slate-800"
                  >
                    <span>الوكيل التالي</span>
                    <ChevronLeft className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <select
                    aria-label="تغيير السهم داخل النافذة"
                    value={selectedSymbol}
                    onChange={(e) => {
                      const sym = e.target.value;
                      setSelectedSymbol(sym);
                      openAgentAndRun(drawerAgent, sym);
                    }}
                    className="rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-2.5 py-1.5 text-xs font-semibold"
                  >
                    {(stocks.length > 0 ? stocks : [{ symbol: 'COMI', name_ar: 'التجاري الدولي' }]).map((s) => (
                      <option key={s.symbol} value={s.symbol}>
                        {s.symbol} — {s.name_ar}
                      </option>
                    ))}
                  </select>
                  <button
                    type="button"
                    disabled={!drawerAgent.enabled || runningId === drawerAgent.number}
                    onClick={() => openAgentAndRun(drawerAgent, selectedSymbol)}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-md bg-emerald-700 text-white text-xs font-semibold hover:bg-emerald-800 disabled:opacity-50"
                  >
                    <Play className="w-3 h-3" />
                    <span>{runningId === drawerAgent.number ? 'جاري الفحص...' : `تشغيل على ${selectedSymbol}`}</span>
                  </button>
                </div>
              </div>
            </div>

            <div className="p-4 sm:p-6 space-y-6 flex-1">
              {tierNotice && (
                <div className="rounded-xl border border-emerald-300 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/30 p-3.5 text-xs font-semibold text-emerald-900 dark:text-emerald-100">
                  {tierNotice}
                </div>
              )}

              {/* Pro / Plus / B2B Preview Activation Banner */}
              {!drawerAgent.unlocked && (
                <div className="rounded-xl border border-amber-300 dark:border-amber-700 bg-amber-50 dark:bg-amber-950/30 p-4 flex flex-wrap items-center justify-between gap-3">
                  <div className="space-y-1 text-xs">
                    <div className="font-bold text-amber-950 dark:text-amber-100">
                      معاينة حية لوكيل ضمن باقة {TIER_LABELS[drawerAgent.tier]}
                    </div>
                    <p className="text-amber-900/90 dark:text-amber-200/90">
                      يمكنك تشغيل المعاينة الآن أو تفعيل باقة {TIER_SHORT[drawerAgent.tier]} في حسابك لفتح جميع وكلاء الباقة مباشرة.
                    </p>
                  </div>
                  <button
                    type="button"
                    disabled={activatingTier === drawerAgent.tier}
                    onClick={() => handleActivateTierPreview(drawerAgent.tier)}
                    className="px-3.5 py-2 rounded-lg text-xs font-semibold bg-amber-900 text-white hover:bg-amber-800 whitespace-nowrap disabled:opacity-60"
                  >
                    {activatingTier === drawerAgent.tier
                      ? 'جاري التفعيل...'
                      : `تفعيل باقة ${TIER_SHORT[drawerAgent.tier]} الآن`}
                  </button>
                </div>
              )}

              {/* Live Execution Card */}
              <section className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-4 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <h3 className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
                    <span>نتيجة التشغيل الحي على {selectedSymbol}</span>
                  </h3>
                  {drawerGuide?.related_route && (
                    <button
                      type="button"
                      onClick={() => {
                        const target = drawerGuide.related_route!;
                        setDrawerAgent(null);
                        onNavigate(target.route, target.route === 'stock' ? selectedSymbol : undefined);
                      }}
                      className="inline-flex items-center gap-1 text-xs font-semibold text-slate-800 dark:text-slate-200 underline underline-offset-4"
                    >
                      <span>{drawerGuide.related_route.label_ar}</span>
                      <ExternalLink className="w-3 h-3" />
                    </button>
                  )}
                </div>

                {runningId === drawerAgent.number && !drawerRunMatches ? (
                  <div className="py-6 text-center text-xs text-slate-500">جاري تنفيذ الفحص على سهم {selectedSymbol}...</div>
                ) : drawerRunMatches ? (
                  <div className="space-y-3">
                    <div className="text-sm font-bold text-slate-900 dark:text-slate-100">{drawerRunMatches.headline_ar}</div>
                    <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                      {drawerRunMatches.summary_ar}
                    </p>
                    <p className="text-xs font-medium text-emerald-800 dark:text-emerald-300">{drawerRunMatches.verdict_ar}</p>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
                      {drawerRunMatches.metrics.map((m, i) => (
                        <div key={i} className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-2.5">
                          <div className="text-[11px] text-slate-500">{m.label_ar}</div>
                          <div className="text-sm font-bold tabular-nums text-slate-900 dark:text-slate-100 mt-0.5">{m.value}</div>
                          <div className="text-[10px] font-mono text-slate-400 truncate mt-0.5">Fact: {m.source_fact_id}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="text-xs text-slate-500">اضغط «تشغيل على {selectedSymbol}» لعرض النتائج الحية.</div>
                )}
              </section>

              {/* Step-by-Step Usage Guide ("فهم الوكيل واستخدامه") */}
              {drawerGuide && (
                <section className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-3">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                    دليل الاستخدام السريع للوكيل #{formatInt(drawerAgent.number, numerals)}
                  </h3>
                  <div className="space-y-2 text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                    <p>
                      <strong className="text-slate-900 dark:text-slate-100">ما فائدته؟ </strong>
                      {drawerGuide.purpose_ar}
                    </p>
                    <p>
                      <strong className="text-slate-900 dark:text-slate-100">كيف يعمل؟ </strong>
                      {drawerGuide.how_it_works_ar}
                    </p>
                  </div>
                  <div className="space-y-1.5 pt-1">
                    <div className="text-xs font-bold text-slate-900 dark:text-slate-100">خطوات الاستخدام عملياً:</div>
                    <ol className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300">
                      {drawerGuide.steps_ar.map((step, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <span className="font-mono font-bold text-emerald-700 dark:text-emerald-400">
                            {formatInt(i + 1, numerals)}.
                          </span>
                          <span>{step}</span>
                        </li>
                      ))}
                    </ol>
                  </div>
                  <div className="rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-3 text-xs text-slate-600 dark:text-slate-300 space-y-1">
                    <div>
                      <strong className="text-slate-900 dark:text-slate-100">مثال: </strong>
                      {drawerGuide.example_ar}
                    </div>
                    <div className="text-[11px] text-amber-800 dark:text-amber-300">
                      <strong>متى نحتاط أو نمتنع؟ </strong>
                      {drawerGuide.caution_ar}
                    </div>
                  </div>
                </section>
              )}

              {/* Interactive Copilot Q&A */}
              <section className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-4">
                <div className="flex items-center justify-between gap-2">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
                    <span>اسأل Copilot عن الوكيل #{formatInt(drawerAgent.number, numerals)}</span>
                  </h3>
                  <span className="text-[11px] text-slate-500">إرشاد مخصص للبورصة المصرية</span>
                </div>

                {/* Quick Question Chips */}
                <div className="flex flex-wrap gap-2">
                  {(
                    copilotSuggestions[drawerAgent.number] ?? [
                      `اشرح لي الوكيل #${drawerAgent.number} بمثال على ${selectedSymbol}`,
                      `كيف أستفيد من «${drawerAgent.name_ar}» قبل الشراء؟`,
                      `متى يرفض هذا الوكيل أو يمتنع عن الإشارة؟`,
                    ]
                  ).map((suggestion, idx) => (
                    <button
                      key={idx}
                      type="button"
                      disabled={copilotBusy}
                      onClick={() => askCopilot(drawerAgent, suggestion)}
                      className="px-3 py-1.5 rounded-md border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 text-right disabled:opacity-50"
                    >
                      {suggestion}
                    </button>
                  ))}
                </div>

                {/* Messages Thread */}
                {(copilotHistory[drawerAgent.number] ?? []).length > 0 && (
                  <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
                    {(copilotHistory[drawerAgent.number] ?? []).map((msg, i) => (
                      <div
                        key={i}
                        className={`rounded-lg p-3 text-xs leading-relaxed whitespace-pre-line ${
                          msg.role === 'user'
                            ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 mr-6'
                            : 'bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200 ml-4'
                        }`}
                      >
                        <div className="text-[10px] opacity-70 mb-1 font-semibold">
                          {msg.role === 'user'
                            ? 'سؤالك'
                            : msg.usedAi
                              ? 'Copilot (ذكاء اصطناعي منضبط)'
                              : 'Copilot (دليل تشغيلي موثق)'}
                        </div>
                        <div>{msg.text}</div>
                        {msg.aiError && (
                          <div className="mt-2 pt-1.5 border-t border-slate-200 dark:border-slate-800 text-[11px] text-amber-800 dark:text-amber-300">
                            ملاحظة: {msg.aiError.includes('{') ? 'يشهد خادم الذكاء الاصطناعي ضغطاً مؤقتاً حالياً، لذا عُرض الشرح التشغيلي المعتمد من بيانات المنصة.' : msg.aiError}
                          </div>
                        )}
                      </div>
                    ))}
                    <div ref={copilotEndRef} />
                  </div>
                )}

                {copilotError && (
                  <div className="rounded-lg border border-rose-300 bg-rose-50 p-2.5 text-xs text-rose-900">{copilotError}</div>
                )}

                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    askCopilot(drawerAgent, copilotInput);
                  }}
                  className="flex items-center gap-2"
                >
                  <input
                    type="text"
                    value={copilotInput}
                    onChange={(e) => setCopilotInput(e.target.value)}
                    placeholder={`اسأل Copilot عن الوكيل #${drawerAgent.number} وكيفية استخدامه...`}
                    className="flex-1 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-xs"
                  />
                  <button
                    type="submit"
                    disabled={copilotBusy || !copilotInput.trim()}
                    className="px-4 py-2 rounded-lg text-xs font-semibold bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 hover:bg-slate-800 disabled:opacity-50 whitespace-nowrap"
                  >
                    {copilotBusy ? 'جاري الشرح...' : 'اسأل Copilot'}
                  </button>
                </form>
              </section>
            </div>
          </aside>
        </div>
      )}
    </div>
  );
};
