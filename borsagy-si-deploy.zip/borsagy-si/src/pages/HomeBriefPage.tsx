import React, { useEffect, useState } from 'react';
import { AppRoute } from '../components/Navbar';
import { DataAgeBadge, RiskMeter } from '../components/SignalMeters';
import { api } from '../lib/api';
import { NumeralMode, formatDateAr, formatEgp, formatNum, formatPct } from '../lib/formatters';

export const HomeBriefPage: React.FC<{
  traderId: string;
  numerals: NumeralMode;
  onNavigate: (route: AppRoute, param?: string) => void;
}> = ({ traderId, numerals, onNavigate }) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<Awaited<ReturnType<typeof api.getPortfolioRisk>> | null>(null);
  const [stocks, setStocks] = useState<Array<{ symbol: string; name_ar: string; price: number; change_1d_pct: number; data_age_seconds: number }>>([]);
  const [askSymbol, setAskSymbol] = useState('COMI');
  const [askBusy, setAskBusy] = useState(false);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError(null);
    Promise.all([api.getPortfolioRisk(traderId), api.getMovers({ timeframe: '1d' })])
      .then(([pRes, mRes]) => {
        if (!active) return;
        setData(pRes);
        setStocks(mRes.stocks);
      })
      .catch((e) => {
        if (active) setError(e instanceof Error ? e.message : 'تعذر تحميل الموجز اليومي.');
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [traderId]);

  const handleAskBorsagy = async () => {
    setAskBusy(true);
    setError(null);
    try {
      const res = await api.requestAdvice(askSymbol, traderId);
      onNavigate('advice', res.advice.id);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'تعذر استخراج نصيحة السهم.');
    } finally {
      setAskBusy(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-6 py-4" aria-busy="true">
        <div className="h-28 rounded-xl bg-slate-200/70 dark:bg-slate-800/70 animate-pulse" />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 h-64 rounded-xl bg-slate-200/70 dark:bg-slate-800/70 animate-pulse" />
          <div className="h-64 rounded-xl bg-slate-200/70 dark:bg-slate-800/70 animate-pulse" />
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="rounded-xl border border-rose-300 dark:border-rose-800 bg-rose-50 dark:bg-rose-950/30 p-6 text-sm text-rose-800 dark:text-rose-200">
        {error ?? 'تعذر قراءة بيانات المحفظة.'}
      </div>
    );
  }

  const { trader, profile, traderState, metrics, recentAdvices, remaining_alert_budget } = data;

  return (
    <div className="space-y-8 py-4">
      {/* Calm HALT / Tilt Banner if active */}
      {(traderState.halted || traderState.tilt_score >= 60) && (
        <div className="rounded-xl border border-rose-300 dark:border-rose-800 bg-rose-50/70 dark:bg-rose-950/30 p-5 flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="text-sm font-bold text-rose-900 dark:text-rose-100">
              {traderState.halted
                ? 'تم تفعيل الإيقاف الوقائي (HALT) لحد الخسارة'
                : 'تم رصد ارتفاع في مؤشر الانفعال التداولي (Tilt)'}
            </div>
            <p className="text-xs text-rose-800 dark:text-rose-200">
              الإشارات الجديدة متوقفة مؤقتاً لحماية رأس مالك (الخسارة اليومية {formatPct(traderState.day_pnl_pct, numerals)} · درجة التوتر {formatNum(traderState.tilt_score, numerals, 0)}/100).
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('discipline')}
            className="px-4 py-2 rounded-lg text-xs font-semibold bg-rose-800 text-white hover:bg-rose-900 whitespace-nowrap shrink-0"
          >
            مراجعة الانضباط والمزاج
          </button>
        </div>
      )}

      {/* Brief Hero + Ask Companion */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        <div className="lg:col-span-7 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 flex flex-col justify-between space-y-6">
          <div className="space-y-2">
            <div className="text-xs text-slate-500 dark:text-slate-400">
              الموجز اليومي السريع (٣ دقائق) · وضع {traderState.active_mode === 'manager' ? 'مدير المحفظة' : 'المستشار'}
            </div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-50">
              أهلاً {trader.handle} — حالة محفظتك قبل أي قرار
            </h1>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-2 border-t border-slate-100 dark:border-slate-800">
            <div>
              <div className="text-xs text-slate-500">قيمة المراكز</div>
              <div className="text-base font-bold text-slate-900 dark:text-slate-100 tabular-nums mt-0.5">
                {formatEgp(metrics.total_market_value_egp, numerals)}
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-500">الربح/الخسارة</div>
              <div
                className={`text-base font-bold tabular-nums mt-0.5 ${
                  metrics.unrealized_pnl_egp >= 0 ? 'text-emerald-700 dark:text-emerald-400' : 'text-rose-700 dark:text-rose-400'
                }`}
              >
                {formatPct(metrics.unrealized_pnl_pct, numerals)}
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-500">درجة الانضباط</div>
              <div className="text-base font-bold text-slate-900 dark:text-slate-100 tabular-nums mt-0.5">
                {formatNum(traderState.discipline_score * 100, numerals, 0)}%
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-500">ميزانية التنبيهات</div>
              <div className="text-base font-bold text-slate-900 dark:text-slate-100 tabular-nums mt-0.5">
                متبقي{' '}
                <span dir="ltr" className="inline-block">
                  {formatNum(remaining_alert_budget, numerals, 0)} / {formatNum(trader.daily_alert_budget, numerals, 0)}
                </span>
              </div>
            </div>
          </div>

          <RiskMeter level={metrics.risk_meter_1_to_5} labelAr={metrics.risk_label_ar} numerals={numerals} />
        </div>

        {/* Ask Companion Card */}
        <div className="lg:col-span-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 flex flex-col justify-between space-y-4">
          <div className="space-y-1.5">
            <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">اسأل بورصجي قبل الدخول</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              يفحص القيود الصلبة وحدك الشخصي وسيولة السهم وعمر البيانات أولاً، ثم يصدر خطة بأرقام موثقة أو يمتنع بوضوح.
            </p>
          </div>

          <div className="space-y-3">
            <label htmlFor="brief-ask-symbol" className="block text-xs font-medium text-slate-700 dark:text-slate-300">
              اختر سهماً للفحص الفوري
            </label>
            <select
              id="brief-ask-symbol"
              value={askSymbol}
              onChange={(e) => setAskSymbol(e.target.value)}
              className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2.5 text-sm text-slate-900 dark:text-slate-100"
            >
              {stocks.map((s) => (
                <option key={s.symbol} value={s.symbol}>
                  {s.symbol} — {s.name_ar} ({formatNum(s.price, numerals, 2)} ج.م)
                </option>
              ))}
            </select>

            <div className="flex flex-wrap items-center gap-3 pt-1">
              <button
                type="button"
                disabled={askBusy}
                onClick={handleAskBorsagy}
                className="flex-1 px-4 py-2.5 rounded-lg text-sm font-semibold bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 hover:bg-slate-800 disabled:opacity-50 whitespace-nowrap"
              >
                {askBusy ? 'جاري فحص القيود والأدلة...' : 'افحص السهم الآن'}
              </button>
              <button
                type="button"
                onClick={() => onNavigate('stock', askSymbol)}
                className="px-4 py-2.5 rounded-lg text-xs font-medium border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 whitespace-nowrap"
              >
                بطاقة السهم
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Why did my portfolio move today + Recent Sealed Advices */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
          <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">ليه محفظتي اتحركت النهاردة؟</h2>
          {metrics.hidden_group_warning_ar && (
            <div className="rounded-lg border border-amber-300 dark:border-amber-800 bg-amber-50/70 dark:bg-amber-950/30 p-3 text-xs text-amber-950 dark:text-amber-100">
              {metrics.hidden_group_warning_ar}
            </div>
          )}
          <ul className="space-y-2.5 text-sm text-slate-700 dark:text-slate-300">
            {metrics.portfolio_move_reasons_ar.map((r, i) => (
              <li key={i} className="pb-2 border-b border-slate-100 dark:border-slate-800 last:border-0">
                {r}
              </li>
            ))}
          </ul>
          <div className="text-xs text-slate-500 dark:text-slate-400">
            حدك اليومي: {formatNum(profile.daily_loss_limit_pct, numerals, 1)}% · سقف السهم الواحد: {formatNum(profile.single_stock_cap_pct, numerals, 0)}%
          </div>
        </div>

        <div className="lg:col-span-7 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
          <div className="flex items-center justify-between gap-4">
            <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">أحدث الملاحظات والخطط المختومة</h2>
            <button
              type="button"
              onClick={() => onNavigate('track_record')}
              className="text-xs font-medium text-slate-600 dark:text-slate-300 underline underline-offset-4"
            >
              كل السجل المنشور
            </button>
          </div>

          {recentAdvices.length === 0 ? (
            <div className="py-8 text-center text-sm text-slate-500">
              لا توجد توصيات مسجلة لهذا الحساب بعد. استخدم أداة «اسأل بورصجي» أعلاه لبدء أول فحص.
            </div>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {recentAdvices.map((adv) => (
                <div key={adv.id} className="py-3.5 flex flex-wrap items-center justify-between gap-4">
                  <div className="space-y-1 max-w-xl">
                    <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                      <span className="font-semibold text-slate-900 dark:text-slate-100">{adv.symbol ?? 'عام'}</span>
                      <span aria-hidden="true">·</span>
                      <span>
                        {adv.kind === 'plan'
                          ? 'خطة تداول'
                          : adv.kind === 'abstain'
                            ? 'امتناع وقائي'
                            : adv.kind === 'calm_down'
                              ? 'تهدئة وإيقاف'
                              : adv.kind}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{formatDateAr(adv.sealed_at)}</span>
                    </div>
                    <p className="text-sm text-slate-800 dark:text-slate-200 leading-relaxed">{adv.text_ar}</p>
                    <DataAgeBadge seconds={adv.data_age_seconds} numerals={numerals} />
                  </div>
                  <button
                    type="button"
                    onClick={() => onNavigate('advice', adv.id)}
                    className="px-3.5 py-2 rounded-lg text-xs font-semibold border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 whitespace-nowrap shrink-0"
                  >
                    عرض الأدلة والخطة
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
};
