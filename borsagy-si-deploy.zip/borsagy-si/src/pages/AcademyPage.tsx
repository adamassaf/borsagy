import React, { useEffect, useState } from 'react';
import { AppRoute } from '../components/Navbar';
import { api } from '../lib/api';
import { NumeralMode, formatInt } from '../lib/formatters';

export const AcademyPage: React.FC<{
  numerals: NumeralMode;
  onNavigate: (r: AppRoute, param?: string) => void;
}> = ({ numerals, onNavigate }) => {
  const [data, setData] = useState<Awaited<ReturnType<typeof api.getAcademy>> | null>(null);
  const [fraudInput, setFraudInput] = useState(
    'اشترك الآن في جروب التوصيات الذهبية! ربح مضمون ٢٠٠% أسبوعياً بدون مخاطرة أو تداول فوركس وعملات رقمية!'
  );
  const [fraudRes, setFraudRes] = useState<Awaited<ReturnType<typeof api.checkFraud>> | null>(null);
  const [termExplain, setTermExplain] = useState<{ term: string; text: string } | null>(null);
  const [busyTerm, setBusyTerm] = useState<string | null>(null);

  useEffect(() => {
    api.getAcademy().then(setData);
  }, []);

  const handleFraudCheck = async () => {
    const res = await api.checkFraud(fraudInput);
    setFraudRes(res);
  };

  const handleExplain = async (term: string) => {
    setBusyTerm(term);
    try {
      const res = await api.explainTerm(term);
      setTermExplain({ term, text: res.explanation_ar });
    } finally {
      setBusyTerm(null);
    }
  };

  if (!data) return <div className="py-12 text-center text-sm text-slate-500">جاري تحميل الأكاديمية...</div>;

  return (
    <div className="space-y-8 py-4">
      <div className="space-y-1">
        <div className="text-xs text-slate-500">تعليم مالي مجاني بالعامية المصرية · بدون مصطلحات معقدة</div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-50">
          الأكاديمية، القاموس التفاعلي، وكاشف الاحتيال
        </h1>
      </div>

      {/* Fraud & Scam Message Analyzer */}
      <section className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
        <div className="space-y-1">
          <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
            كاشف الاحتيال ورسائل النصب المالي
          </h2>
          <p className="text-xs text-slate-500">
            الصق أي رسالة أو إعلان توصيات مشبوه لفحص علامات الاحتيال، وعود الربح المضمون، أو الترويج غير المرخص للعملات الرقمية.
          </p>
        </div>

        <textarea
          rows={3}
          value={fraudInput}
          onChange={(e) => setFraudInput(e.target.value)}
          className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 p-3 text-sm"
        />

        <button
          type="button"
          onClick={handleFraudCheck}
          className="px-4 py-2 rounded-lg text-xs font-semibold bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900"
        >
          افحص الرسالة الآن
        </button>

        {fraudRes && (
          <div
            className={`rounded-lg border p-4 space-y-2 text-xs ${
              fraudRes.risk_level === 'high'
                ? 'border-rose-300 dark:border-rose-800 bg-rose-50 dark:bg-rose-950/30 text-rose-900 dark:text-rose-100'
                : fraudRes.risk_level === 'medium'
                  ? 'border-amber-300 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/30 text-amber-950 dark:text-amber-100'
                  : 'border-emerald-300 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/30 text-emerald-900 dark:text-emerald-100'
            }`}
          >
            <div className="font-bold text-sm tabular-nums">
              درجة الخطورة: {formatInt(fraudRes.score, numerals)} / 100 · {fraudRes.recommendation_ar}
            </div>
            {fraudRes.flags_ar.length > 0 && (
              <ul className="space-y-1">
                {fraudRes.flags_ar.map((f, i) => (
                  <li key={i}>• {f}</li>
                ))}
              </ul>
            )}
          </div>
        )}
      </section>

      {/* Lessons + Interactive Glossary */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
          <h2 className="text-base font-bold">دروس سريعة على أمثلة مصرية</h2>
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {data.lessons.map((l) => (
              <div key={l.id} className="py-3.5 space-y-1.5 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-slate-900 dark:text-slate-100">{l.title_ar}</span>
                  <span className="text-slate-500 tabular-nums">{formatInt(l.duration_min, numerals)} دقائق</span>
                </div>
                <p className="text-slate-600 dark:text-slate-300 leading-relaxed">{l.summary_ar}</p>
                <p className="text-slate-500">{l.example_ar}</p>
                <button
                  type="button"
                  onClick={() => onNavigate('stock', l.linked_symbol)}
                  className="text-slate-900 dark:text-slate-100 font-semibold underline underline-offset-4"
                >
                  تطبيق عملي على سهم {l.linked_symbol}
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
          <h2 className="text-base font-bold">القاموس البسيط (اضغط للشرح)</h2>
          {termExplain && (
            <div className="rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 p-3.5 text-xs space-y-1">
              <div className="font-bold text-slate-900 dark:text-slate-100">{termExplain.term}</div>
              <p className="text-slate-700 dark:text-slate-300 leading-relaxed">{termExplain.text}</p>
            </div>
          )}
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {data.glossary.map((g) => (
              <div key={g.term_en} className="py-3 flex items-start justify-between gap-3 text-xs">
                <div className="space-y-1">
                  <div className="font-bold text-sm text-slate-900 dark:text-slate-100">
                    {g.term_ar} ({g.term_en})
                  </div>
                  <p className="text-slate-600 dark:text-slate-300">{g.simple_ar}</p>
                  <p className="text-slate-500">{g.egyptian_example_ar}</p>
                </div>
                <button
                  type="button"
                  disabled={busyTerm === g.term_ar}
                  onClick={() => handleExplain(g.term_ar)}
                  className="px-3 py-1.5 rounded-md border border-slate-300 dark:border-slate-700 text-xs font-medium shrink-0 hover:bg-slate-50 dark:hover:bg-slate-800"
                >
                  {busyTerm === g.term_ar ? '...' : 'بسطها لي'}
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};
