import React, { useEffect, useState } from 'react';
import { AGENT_GROUPS, SUBSCRIPTION_PLANS } from '../core/agentsCatalog';
import { PUBLIC_SAFETY_CHARTER_10, SHORT_DISCLAIMER_AR } from '../core/marketPack';
import { LiveFeedStatus } from '../core/types';
import { api } from '../lib/api';
import { AppRoute } from '../components/Navbar';

export const WelcomePage: React.FC<{
  onNavigate: (route: AppRoute) => void;
}> = ({ onNavigate }) => {
  const [liveStatus, setLiveStatus] = useState<LiveFeedStatus | null>(null);

  useEffect(() => {
    api
      .getHealth()
      .then((h) => {
        if (h.live_feed_status) setLiveStatus(h.live_feed_status);
      })
      .catch(() => {});
  }, []);

  return (
    <div className="space-y-12 py-6">
      {/* Executive Live Macro Strip */}
      <section className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 sm:px-6 grid grid-cols-2 sm:grid-cols-5 gap-4 text-xs">
        <div>
          <div className="text-slate-500">النطاق الرسمي</div>
          <div className="font-mono font-bold text-slate-900 dark:text-slate-50 mt-0.5">borsagy.si</div>
        </div>
        <div>
          <div className="text-slate-500">الأسهم المحدثة حياً</div>
          <div className="font-bold text-emerald-700 dark:text-emerald-400 tabular-nums mt-0.5">
            {liveStatus?.live_symbols_count ? `${liveStatus.live_symbols_count} سهم EGX مباشر` : '33 سهم EGX + 7 اختبارات'}
          </div>
        </div>
        <div>
          <div className="text-slate-500">الدولار مقابل الجنيه</div>
          <div className="font-mono font-bold text-slate-900 dark:text-slate-50 tabular-nums mt-0.5">
            {liveStatus?.usd_egp ? `${liveStatus.usd_egp} ج.م` : 'قيد المزامنة'}
          </div>
        </div>
        <div>
          <div className="text-slate-500">الذهب عيار 21 (فوري)</div>
          <div className="font-mono font-bold text-slate-900 dark:text-slate-50 tabular-nums mt-0.5">
            {liveStatus?.gold_21k_egp ? `${liveStatus.gold_21k_egp.toLocaleString('en-US')} ج/جم` : 'قيد المزامنة'}
          </div>
        </div>
        <div>
          <div className="text-slate-500">منظومة الوكلاء</div>
          <div className="font-bold text-slate-900 dark:text-slate-50 tabular-nums mt-0.5">84 وكيلاً (11 مجموعة)</div>
        </div>
      </section>

      {/* Editorial Hero Split */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
        <div className="lg:col-span-7 flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            <div className="text-xs font-medium text-emerald-800 dark:text-emerald-400">
              بورصجي (borsagy.si) · منصة البورصة المصرية المدعومة بالذكاء الاصطناعي المتقدم والأنطولوجيا
            </div>
            <h1 className="text-3xl sm:text-5xl font-extrabold text-slate-900 dark:text-slate-50 leading-tight">
              قرارك في البورصة بيبقى أوضح لما الحماية تيجي قبل أي توصية
            </h1>
            <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed max-w-2xl">
              منصة <strong>بورصجي</strong> مبنية على ٨٤ وكيلاً تحليلياً ورقابياً فوق أنطولوجيا ثنائية الزمن. لا نحتفظ بأموالك، ولا نطلب كلمة سر شركة الوساطة، ولا نصدر رقماً دون معرّف حقيقة (Fact ID) وتاريخ، بينما يظل الذكاء الفائق (SI) رؤية بحثية مستقبلية لثقافة العمل.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              type="button"
              onClick={() => onNavigate('onboarding')}
              className="px-6 py-3 rounded-lg text-sm font-semibold bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 hover:bg-slate-800 dark:hover:bg-slate-200 transition-colors whitespace-nowrap shrink-0"
            >
              ابدأ تقييم المخاطر (٥ خطوات)
            </button>
            <button
              type="button"
              onClick={() => onNavigate('agents')}
              className="px-5 py-3 rounded-lg text-sm font-semibold border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
            >
              تصفح جميع الوكلاء (84)
            </button>
            <button
              type="button"
              onClick={() => onNavigate('pricing')}
              className="px-5 py-3 rounded-lg text-sm font-medium border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
            >
              الباقات والأسعار
            </button>
          </div>
        </div>

        {/* Non-negotiable Guardrails Summary */}
        <div className="lg:col-span-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 flex flex-col justify-between space-y-5">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
              ٣ قواعد لا يتنازل عنها بورصجي
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              مبنية في صلب النظام قبل تشغيل أي وكيل تحليلي
            </p>
          </div>
          <div className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
            <div className="py-3">
              <div className="font-semibold text-slate-900 dark:text-slate-100">٠١. القيود تسبق النصيحة</div>
              <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 leading-relaxed">
                حد الخسارة اليومي، سقف التركز في السهم والمجموعة المالكة، وسيولة الخروج تحجب أي اقتراح غير آمن قبل أن يظهر لك.
              </p>
            </div>
            <div className="py-3">
              <div className="font-semibold text-slate-900 dark:text-slate-100">٠٢. لا رقم بلا دليل</div>
              <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 leading-relaxed">
                أي رقم تشوفه مربوط بمعرّف حقيقة زمني (Fact ID) ومصدر وتاريخ، والامتناع عن التوصية نتيجة طبيعية وموثقة.
              </p>
            </div>
            <div className="py-3">
              <div className="font-semibold text-slate-900 dark:text-slate-100">٠٣. الشفافية في الربح والخسارة</div>
              <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 leading-relaxed">
                كل توصية تُختم رقمياً بسلسلة SHA-256 وتُنشر نتائجها في السجل العام بما فيها الصفقات الخاسرة.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 11 Groups / 84 Agents Architecture Summary */}
      <section className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 sm:p-8 space-y-5">
        <div className="flex flex-wrap items-baseline justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
          <div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100">
              بنية الـ ٨٤ وكيلاً في ١١ مجموعة متخصصة
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              موحدة تشغيلياً فوق أنطولوجيا مشتركة بحيث لا يتعارض وكيل التحليل مع حارس المخاطر أو الامتثال
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('agents')}
            className="text-xs font-semibold text-slate-900 dark:text-slate-100 underline underline-offset-4"
          >
            افتح مختبر وتشغيل الـ 84 وكيلاً
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          {AGENT_GROUPS.map((g) => (
            <button
              key={g.key}
              type="button"
              onClick={() => onNavigate('agents')}
              className="text-right rounded-lg border border-slate-200 dark:border-slate-800 p-3.5 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors"
            >
              <div className="flex items-center justify-between font-mono text-[11px] text-slate-500">
                <span>المجموعة {g.code_ar}</span>
                <span>#{g.range_label}</span>
              </div>
              <div className="font-bold text-slate-900 dark:text-slate-100 mt-1">{g.title_ar}</div>
            </button>
          ))}
        </div>
      </section>

      {/* Subscription Plans Preview Strip */}
      <section className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 sm:p-8 space-y-5">
        <div className="flex flex-wrap items-baseline justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
          <div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100">
              باقات الاشتراك الشفافة (بالجنيه المصري)
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              تمويل ذاتي من الاشتراكات فقط — بلا إعلانات وبلا عمولات وساطة
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('pricing')}
            className="text-xs font-semibold text-slate-900 dark:text-slate-100 underline underline-offset-4"
          >
            مقارنة تفصيلية وتفعيل الباقة
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
          {SUBSCRIPTION_PLANS.map((p) => (
            <div
              key={p.id}
              className={`rounded-lg border p-4 flex flex-col justify-between space-y-3 ${
                p.recommended ? 'border-emerald-700 dark:border-emerald-500' : 'border-slate-200 dark:border-slate-800'
              }`}
            >
              <div>
                <div className="font-bold text-sm text-slate-900 dark:text-slate-100">{p.name_ar}</div>
                <div className="text-xl font-extrabold text-slate-900 dark:text-slate-50 tabular-nums mt-1">
                  {p.monthly_egp === 0 ? 'مجاناً' : `${p.monthly_egp.toLocaleString('en-US')} ج.م/شهر`}
                </div>
                <p className="text-slate-500 mt-1.5 leading-relaxed">{p.agent_limit_label_ar}</p>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('pricing')}
                className="w-full py-2 rounded-md font-semibold border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800"
              >
                تفاصيل الباقة
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* 10-Pledge Public Safety Charter */}
      <section className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 sm:p-8 space-y-5">
        <div className="flex flex-wrap items-baseline justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
          <div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100">
              ميثاق الأمان والشفافية العام (١٠ التزامات)
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              التزامات منشورة وقابلة للمراجعة في السجل العام وتاريخ كل توصية
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('track_record')}
            className="text-xs font-semibold text-slate-800 dark:text-slate-200 underline underline-offset-4 hover:text-slate-600"
          >
            اطلع على السجل العام المختوم رقمياً
          </button>
        </div>

        <ol className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-3 text-sm">
          {PUBLIC_SAFETY_CHARTER_10.map((item, idx) => (
            <li key={idx} className="flex items-start gap-3 py-1.5">
              <span className="font-mono text-xs font-semibold text-slate-400 tabular-nums mt-0.5">
                {String(idx + 1).padStart(2, '0')}.
              </span>
              <span className="text-slate-800 dark:text-slate-200 leading-relaxed">{item}</span>
            </li>
          ))}
        </ol>

        <p className="text-xs text-slate-500 dark:text-slate-400 pt-3 border-t border-slate-100 dark:border-slate-800">
          {SHORT_DISCLAIMER_AR}
        </p>
      </section>
    </div>
  );
};
