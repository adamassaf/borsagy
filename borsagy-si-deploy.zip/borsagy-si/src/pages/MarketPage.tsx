import React, { useEffect, useState } from 'react';
import { AppRoute } from '../components/Navbar';
import { DataAgeBadge } from '../components/SignalMeters';
import { api } from '../lib/api';
import { NumeralMode, formatInt, formatNum, formatPct } from '../lib/formatters';

export const MarketPage: React.FC<{
  numerals: NumeralMode;
  onNavigate: (route: AppRoute, param?: string) => void;
}> = ({ numerals, onNavigate }) => {
  const [timeframe, setTimeframe] = useState<'1h' | '1d' | '1w' | '1m'>('1d');
  const [sector, setSector] = useState('all');
  const [shariaOnly, setShariaOnly] = useState(false);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<Awaited<ReturnType<typeof api.getMovers>> | null>(null);
  const [syncBusy, setSyncBusy] = useState(false);

  const loadMovers = (activeRef?: { current: boolean }) => {
    setLoading(true);
    api
      .getMovers({ timeframe, sector, sharia: shariaOnly, q: search })
      .then((res) => {
        if (!activeRef || activeRef.current) setData(res);
      })
      .catch((e) => {
        if (!activeRef || activeRef.current) {
          setError(e instanceof Error ? e.message : 'تعذر تحميل بيانات السوق.');
        }
      })
      .finally(() => {
        if (!activeRef || activeRef.current) setLoading(false);
      });
  };

  useEffect(() => {
    const activeRef = { current: true };
    loadMovers(activeRef);
    return () => {
      activeRef.current = false;
    };
  }, [timeframe, sector, shariaOnly, search]);

  const handleRefreshLive = async () => {
    setSyncBusy(true);
    setError(null);
    try {
      await api.refreshLiveMarket();
      loadMovers();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'تعذر تحديث الأسعار الحية.');
    } finally {
      setSyncBusy(false);
    }
  };

  const changeKey =
    timeframe === '1h'
      ? 'change_1h_pct'
      : timeframe === '1w'
        ? 'change_1w_pct'
        : timeframe === '1m'
          ? 'change_1m_pct'
          : 'change_1d_pct';

  const liveInfo = data?.live_feed_status;

  return (
    <div className="space-y-6 py-4">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div className="space-y-1">
          <div className="text-xs text-slate-500 dark:text-slate-400">
            {data?.data_notice ?? 'بيانات السوق المصري (EGX)'}
          </div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-50">رادار السوق المصري (٤٠ سهم)</h1>
        </div>

        {/* Timeframe + Sharia + Live Sync Controls */}
        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            disabled={syncBusy}
            onClick={handleRefreshLive}
            className="px-3.5 py-2 rounded-lg text-xs font-semibold bg-emerald-700 text-white hover:bg-emerald-800 disabled:opacity-50 transition-colors whitespace-nowrap shrink-0"
          >
            {syncBusy ? 'جاري جلب الأسعار الحية...' : 'تحديث الأسعار المباشرة الآن'}
          </button>

          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
            {([
              ['1h', 'ساعة'],
              ['1d', 'يوم'],
              ['1w', 'أسبوع'],
              ['1m', 'شهر'],
            ] as const).map(([tf, lbl]) => (
              <button
                key={tf}
                type="button"
                onClick={() => setTimeframe(tf)}
                className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                  timeframe === tf
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                {lbl}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={() => setShariaOnly((v) => !v)}
            className={`px-3.5 py-2 rounded-lg text-xs font-semibold border transition-colors whitespace-nowrap shrink-0 ${
              shariaOnly
                ? 'bg-emerald-700 text-white border-emerald-700'
                : 'border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-900'
            }`}
          >
            {shariaOnly ? 'الأسهم المتوافقة شرعياً فقط' : 'فلتر الشرعية: الكل'}
          </button>
        </div>
      </div>

      {/* Live Macro Strip */}
      {liveInfo && (
        <section className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-5 py-3.5 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
          <div>
            <div className="text-slate-500">المصدر الحي</div>
            <div className="font-semibold text-slate-900 dark:text-slate-100 mt-0.5 truncate">{liveInfo.provider}</div>
          </div>
          <div>
            <div className="text-slate-500">أسهم EGX المحدثة حياً</div>
            <div className="font-bold text-emerald-700 dark:text-emerald-400 tabular-nums mt-0.5">
              {formatInt(liveInfo.live_symbols_count, numerals)} / {formatInt(liveInfo.total_live_eligible, numerals)}
            </div>
          </div>
          <div>
            <div className="text-slate-500">الدولار الفوري</div>
            <div className="font-mono font-bold tabular-nums mt-0.5">
              {liveInfo.usd_egp ? `${formatNum(liveInfo.usd_egp, numerals, 2)} ج.م` : '—'}
            </div>
          </div>
          <div>
            <div className="text-slate-500">الذهب المحلي (21 / 24)</div>
            <div className="font-mono font-bold tabular-nums mt-0.5">
              {liveInfo.gold_21k_egp
                ? `${formatInt(liveInfo.gold_21k_egp, numerals)} / ${formatInt(liveInfo.gold_24k_egp ?? 0, numerals)} ج`
                : '—'}
            </div>
          </div>
        </section>
      )}

      {/* Fear & Greed + Sector Heatmap */}
      {data && (
        <section className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
            <div className="text-xs text-slate-500">مؤشر الخوف والطمع (EGX)</div>
            <div className="flex items-baseline justify-between">
              <span dir="ltr" className="inline-block text-3xl font-extrabold text-slate-900 dark:text-slate-50 tabular-nums">
                {formatNum(data.fear_greed.score, numerals, 0)} / 100
              </span>
              <span className="text-sm font-semibold text-slate-700 dark:text-slate-300">{data.fear_greed.label_ar}</span>
            </div>
            <div className="h-2.5 w-full rounded-sm bg-slate-200 dark:bg-slate-800 overflow-hidden">
              <div
                className="h-full bg-slate-900 dark:bg-slate-100"
                style={{ width: `${data.fear_greed.score}%` }}
              />
            </div>
            <ul className="space-y-1 text-xs text-slate-500 dark:text-slate-400">
              {data.fear_greed.factors_ar.map((f, i) => (
                <li key={i}>• {f}</li>
              ))}
            </ul>
          </div>

          <div className="lg:col-span-8 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100">خريطة القطاعات (٨ قطاعات)</h2>
              {sector !== 'all' && (
                <button
                  type="button"
                  onClick={() => setSector('all')}
                  className="text-xs text-slate-600 underline"
                >
                  عرض كل القطاعات
                </button>
              )}
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {data.sector_heatmap.map((sec) => {
                const selected = sector === sec.sector_id;
                const up = sec.avgChange >= 0;
                return (
                  <button
                    key={sec.sector_id}
                    type="button"
                    onClick={() => setSector(selected ? 'all' : sec.sector_id)}
                    className={`p-3 rounded-lg border text-right transition-colors ${
                      selected
                        ? 'border-slate-900 dark:border-slate-100 bg-slate-100 dark:bg-slate-800'
                        : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50'
                    }`}
                  >
                    <div className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate">{sec.sector_ar}</div>
                    <div
                      className={`text-sm font-bold tabular-nums mt-1 ${
                        up ? 'text-emerald-700 dark:text-emerald-400' : 'text-rose-700 dark:text-rose-400'
                      }`}
                    >
                      {formatPct(sec.avgChange, numerals)}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </section>
      )}

      {/* Search & Full Market Table */}
      <section className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <input
            type="search"
            aria-label="بحث برمز أو اسم السهم"
            placeholder="ابحث بالرمز أو اسم الشركة (مثال: COMI أو طلعت مصطفى)..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full sm:w-96 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3.5 py-2 text-sm text-slate-900 dark:text-slate-100"
          />
          <div className="text-xs text-slate-500 tabular-nums">
            المعروض: {formatInt(data?.stocks.length ?? 0, numerals)} سهم
          </div>
        </div>

        {loading && <div className="py-10 text-center text-sm text-slate-500">جاري تحديث بيانات السوق...</div>}
        {error && <div className="py-6 text-center text-sm text-rose-700">{error}</div>}

        {!loading && !error && data && data.stocks.length === 0 && (
          <div className="py-10 text-center text-sm text-slate-500">
            لا توجد أسهم مطابقة لخيارات البحث الحالية.
          </div>
        )}

        {!loading && !error && data && data.stocks.length > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-right border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-xs text-slate-500">
                  <th className="py-2.5 px-2 font-medium">السهم</th>
                  <th className="py-2.5 px-2 font-medium">القطاع</th>
                  <th className="py-2.5 px-2 font-medium text-left">السعر</th>
                  <th className="py-2.5 px-2 font-medium text-left">التغير</th>
                  <th className="py-2.5 px-2 font-medium text-left">متوسط التداول اليومي</th>
                  <th className="py-2.5 px-2 font-medium">حالة البيانات والشرعية</th>
                  <th className="py-2.5 px-2 font-medium text-left">إجراء</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {data.stocks.map((st) => {
                  const chg = st[changeKey];
                  const isBad = st.quality !== 'valid' || st.data_age_seconds > 1200;
                  return (
                    <tr key={st.symbol} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors">
                      <td className="py-3 px-2">
                        <div className="font-bold text-slate-900 dark:text-slate-100">{st.symbol}</div>
                        <div className="text-xs text-slate-500">{st.name_ar}</div>
                      </td>
                      <td className="py-3 px-2 text-xs text-slate-600 dark:text-slate-300">{st.sector_ar}</td>
                      <td className="py-3 px-2 text-left font-mono tabular-nums font-semibold">
                        {formatNum(st.price, numerals, 2)}
                      </td>
                      <td
                        className={`py-3 px-2 text-left font-mono tabular-nums font-semibold ${
                          chg >= 0 ? 'text-emerald-700 dark:text-emerald-400' : 'text-rose-700 dark:text-rose-400'
                        }`}
                      >
                        {formatPct(chg, numerals)}
                      </td>
                      <td className="py-3 px-2 text-left font-mono tabular-nums text-xs text-slate-600 dark:text-slate-300">
                        {formatInt(Math.round(st.adv_30d / 1_000_000), numerals)} مليون
                      </td>
                      <td className="py-3 px-2 text-xs">
                        <div className={isBad ? 'text-rose-700 dark:text-rose-400 font-semibold' : 'text-slate-600 dark:text-slate-300'}>
                          {st.quality === 'halted'
                            ? 'موقوف التداول'
                            : st.data_age_seconds > 1200
                              ? 'بيانات متأخرة'
                              : st.unexplained_spike
                                ? 'ارتفاع غير مبرر'
                                : 'بيانات سليمة'}
                          <span aria-hidden="true"> · </span>
                          <span>{st.sharia_compliant ? 'متوافق شرعياً' : 'غير متوافق'}</span>
                        </div>
                        <DataAgeBadge seconds={st.data_age_seconds} isDemo={Boolean(st.is_demo)} numerals={numerals} />
                      </td>
                      <td className="py-3 px-2 text-left">
                        <button
                          type="button"
                          onClick={() => onNavigate('stock', st.symbol)}
                          className="px-3 py-1.5 rounded-md text-xs font-semibold border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap"
                        >
                          تفاصيل السهم
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
};
