import React, { useEffect, useState } from 'react';
import { AppRoute } from '../components/Navbar';
import { PriceCandleChart } from '../components/PriceCandleChart';
import { DataAgeBadge } from '../components/SignalMeters';
import { TrapScoreGauge } from '../components/TrapScoreGauge';
import { api } from '../lib/api';
import { NumeralMode, formatEgp, formatInt, formatNum, formatPct } from '../lib/formatters';

export const StockDetailPage: React.FC<{
  symbol: string;
  traderId: string;
  numerals: NumeralMode;
  onNavigate: (route: AppRoute, param?: string) => void;
}> = ({ symbol, traderId, numerals, onNavigate }) => {
  const [tab, setTab] = useState<'quality' | 'id_card' | 'disclosures' | 'tools'>('quality');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [detail, setDetail] = useState<Awaited<ReturnType<typeof api.getStockDetail>> | null>(null);
  const [askBusy, setAskBusy] = useState(false);

  // Disclosure Extractor state
  const [discText, setDiscText] = useState(
    'أفصحت الشركة عن مقترح توزيع كوبون نقدي بواقع ١.٢٥ جنيه للسهم مع زيادة الإيرادات السنوية بنسبة ١٨٪.'
  );
  const [discResult, setDiscResult] = useState<Awaited<ReturnType<typeof api.extractDisclosure>> | null>(null);
  const [discBusy, setDiscBusy] = useState(false);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError(null);
    api
      .getStockDetail(symbol)
      .then((res) => {
        if (active) setDetail(res);
      })
      .catch((e) => {
        if (active) setError(e instanceof Error ? e.message : 'تعذر تحميل تفاصيل السهم.');
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [symbol]);

  const handleAskBorsagy = async () => {
    setAskBusy(true);
    try {
      const res = await api.requestAdvice(symbol, traderId);
      onNavigate('advice', res.advice.id);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'تعذر تحليل السهم.');
    } finally {
      setAskBusy(false);
    }
  };

  const handleExtractDisclosure = async () => {
    setDiscBusy(true);
    try {
      const res = await api.extractDisclosure(symbol, discText);
      setDiscResult(res);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'تعذر تحليل الإفصاح.');
    } finally {
      setDiscBusy(false);
    }
  };

  if (loading) {
    return <div className="py-12 text-center text-sm text-slate-500">جاري تحميل ملف السهم {symbol}...</div>;
  }

  if (error || !detail) {
    return (
      <div className="rounded-xl border border-rose-300 bg-rose-50 p-6 text-sm text-rose-800">
        {error ?? 'السهم غير موجود.'}
      </div>
    );
  }

  const { stock, quality, trap, sharia, backtest, is_blocked } = detail;

  return (
    <div className="space-y-6 py-4">
      {/* Header */}
      <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div className="space-y-1.5">
          <div className="text-xs text-slate-500 dark:text-slate-400">
            {stock.sector_ar} · {stock.owner_group_ar} · {stock.sharia_compliant ? 'متوافق شرعياً' : 'غير متوافق شرعياً'}
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-slate-50">
            {stock.name_ar} ({stock.symbol})
          </h1>
          <DataAgeBadge seconds={stock.data_age_seconds} isDemo={stock.is_demo} numerals={numerals} />
        </div>

        <div className="flex flex-wrap items-center gap-4">
          <div className="text-left">
            <div className="text-2xl font-extrabold text-slate-900 dark:text-slate-50 tabular-nums">
              {formatNum(stock.price, numerals, 2)} ج.م
            </div>
            <div
              className={`text-xs font-semibold tabular-nums ${
                stock.change_1d_pct >= 0 ? 'text-emerald-700 dark:text-emerald-400' : 'text-rose-700 dark:text-rose-400'
              }`}
            >
              اليوم: {formatPct(stock.change_1d_pct, numerals)} · أسبوع: {formatPct(stock.change_1w_pct, numerals)}
            </div>
          </div>

          <button
            type="button"
            disabled={askBusy}
            onClick={handleAskBorsagy}
            className="px-5 py-2.5 rounded-lg text-sm font-semibold bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 hover:bg-slate-800 disabled:opacity-50 whitespace-nowrap shrink-0"
          >
            {askBusy ? 'جاري فحص القيود...' : 'اسأل بورصجي عن السهم'}
          </button>
        </div>
      </div>

      {/* Blocked Banner if Halted/Stale/Admin Blocked */}
      {(quality.blocked || is_blocked) && (
        <div className="rounded-xl border border-rose-300 dark:border-rose-800 bg-rose-50/70 dark:bg-rose-950/30 p-4 text-sm text-rose-900 dark:text-rose-100">
          <span className="font-bold">تم حجب درجة الجودة والتوصية: </span>
          {quality.block_reason_ar ?? 'هذا السهم موقوف حالياً بقرار من الحوكمة أو لسلامة البيانات.'}
        </div>
      )}

      {/* Price Chart */}
      <PriceCandleChart bars={stock.bars} symbol={stock.symbol} numerals={numerals} />

      {/* Section Tabs */}
      <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg w-fit">
        {([
          ['quality', 'الجودة ومقياس الفخاخ'],
          ['id_card', 'بطاقة هوية السهم'],
          ['disclosures', 'الإفصاحات ومحلل الإفصاح'],
          ['tools', 'الاختبار التاريخي والشرعية'],
        ] as const).map(([id, lbl]) => (
          <button
            key={id}
            type="button"
            onClick={() => setTab(id)}
            className={`px-3.5 py-2 rounded-md text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
              tab === id
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            {lbl}
          </button>
        ))}
      </div>

      {tab === 'quality' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100">درجة جودة السهم</h2>
              <span className="text-2xl font-extrabold tabular-nums text-slate-900 dark:text-slate-50">
                {quality.total !== null ? `${formatNum(quality.total, numerals, 0)} / 100` : 'محجوبة'}
              </span>
            </div>

            {quality.total !== null ? (
              <div className="grid grid-cols-3 gap-3 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
                <div>
                  <div className="text-slate-500">أساسي</div>
                  <div className="text-base font-bold tabular-nums mt-0.5">{formatNum(quality.fundamental, numerals, 0)}</div>
                </div>
                <div>
                  <div className="text-slate-500">فني</div>
                  <div className="text-base font-bold tabular-nums mt-0.5">{formatNum(quality.technical, numerals, 0)}</div>
                </div>
                <div>
                  <div className="text-slate-500">سيولة</div>
                  <div className="text-base font-bold tabular-nums mt-0.5">{formatNum(quality.liquidity, numerals, 0)}</div>
                </div>
              </div>
            ) : (
              <p className="text-xs text-rose-700 dark:text-rose-400">{quality.block_reason_ar}</p>
            )}

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-3 border-t border-slate-100 dark:border-slate-800 text-xs">
              <div>
                <span className="text-slate-500 block">مضاعف الربحية (P/E)</span>
                <span className="font-semibold tabular-nums">{formatNum(stock.pe, numerals, 1)}</span>
              </div>
              <div>
                <span className="text-slate-500 block">العائد على الحقوق (ROE)</span>
                <span className="font-semibold tabular-nums">{formatNum(stock.roe, numerals, 1)}%</span>
              </div>
              <div>
                <span className="text-slate-500 block">العائد النقدي</span>
                <span className="font-semibold tabular-nums">{formatNum(stock.dividend_yield_pct, numerals, 1)}%</span>
              </div>
              <div>
                <span className="text-slate-500 block">التداول الحر</span>
                <span className="font-semibold tabular-nums">{formatNum(stock.free_float_pct, numerals, 0)}%</span>
              </div>
              <div>
                <span className="text-slate-500 block">متوسط السيولة اليومي</span>
                <span className="font-semibold tabular-nums">{formatInt(stock.adv_30d, numerals)} ج.م</span>
              </div>
              <div>
                <span className="text-slate-500 block">مؤشر RSI 14</span>
                <span className="font-semibold tabular-nums">{formatNum(stock.rsi_14, numerals, 1)}</span>
              </div>
            </div>
          </div>

          <TrapScoreGauge trap={trap} numerals={numerals} />
        </div>
      )}

      {tab === 'id_card' && (
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4 text-sm">
          <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">بطاقة هوية الشركة</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h3 className="text-xs font-semibold text-slate-500 mb-1">نشاط الشركة</h3>
              <p className="text-slate-800 dark:text-slate-200 leading-relaxed">{stock.business_summary_ar}</p>
            </div>
            <div>
              <h3 className="text-xs font-semibold text-slate-500 mb-1">مصادر الإيراد</h3>
              <p className="text-slate-800 dark:text-slate-200 leading-relaxed">{stock.revenue_sources_ar}</p>
            </div>
            <div>
              <h3 className="text-xs font-semibold text-slate-500 mb-1">أبرز المخاطر التشغيلية</h3>
              <p className="text-slate-800 dark:text-slate-200 leading-relaxed">{stock.key_risks_ar}</p>
            </div>
          </div>
        </div>
      )}

      {tab === 'disclosures' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
            <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100">أحدث الإفصاحات المسجلة</h2>
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {stock.disclosures.map((d) => (
                <div key={d.id} className="py-3 space-y-1 text-xs">
                  <div className="text-slate-500">
                    {d.date} · {d.type} · {d.direction === 'positive' ? 'إيجابي' : d.direction === 'negative' ? 'سلبي' : 'محايد'}
                  </div>
                  <div className="font-semibold text-sm text-slate-900 dark:text-slate-100">{d.title_ar}</div>
                  <p className="text-slate-600 dark:text-slate-300">{d.summary_ar}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
            <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100">محلل الإفصاح العربي الفوري</h2>
            <textarea
              rows={4}
              value={discText}
              onChange={(e) => setDiscText(e.target.value)}
              className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 p-3 text-sm"
            />
            <button
              type="button"
              disabled={discBusy}
              onClick={handleExtractDisclosure}
              className="px-4 py-2 rounded-lg text-xs font-semibold bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 disabled:opacity-50"
            >
              {discBusy ? 'جاري التحليل...' : 'استخراج الأحداث والمخاطر'}
            </button>
            {discResult && (
              <div className="p-3.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 space-y-2 text-xs">
                <div className="font-semibold text-slate-900 dark:text-slate-100">
                  التصنيف: {discResult.event_type} · الاتجاه: {discResult.direction}
                  {discResult.requires_human_review ? ' · أُدرج في قائمة المراجعة البشرية' : ''}
                </div>
                <p className="text-slate-700 dark:text-slate-300 leading-relaxed">{discResult.summary_ar}</p>
                <ul className="space-y-1 text-slate-600 dark:text-slate-400">
                  {discResult.key_points_ar.map((k, i) => (
                    <li key={i}>• {k}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
      )}

      {tab === 'tools' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
            <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              الاختبار التاريخي بنقطة الزمن (Point-in-Time Backtest)
            </h2>
            {backtest.ok ? (
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <span className="text-slate-500 block">العائد الصافي بعد التكاليف</span>
                  <span className={`text-base font-bold tabular-nums ${backtest.net_return_pct >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                    {formatPct(backtest.net_return_pct, numerals)}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">أقصى تراجع (Drawdown)</span>
                  <span className="text-base font-bold text-rose-700 tabular-nums">
                    -{formatNum(backtest.max_drawdown_pct, numerals, 2)}%
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">عدد الصفقات ونسبة النجاح</span>
                  <span className="font-semibold tabular-nums">
                    {formatInt(backtest.trades_count, numerals)} صفقة ({formatNum(backtest.win_rate_pct, numerals, 1)}%)
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">العمولات والرسوم المخصومة</span>
                  <span className="font-semibold tabular-nums">{formatEgp(backtest.total_fees_egp, numerals)}</span>
                </div>
              </div>
            ) : (
              <p className="text-xs text-rose-700">{backtest.error_ar}</p>
            )}
            <p className="text-xs text-slate-500 leading-relaxed">{backtest.note_ar}</p>
          </div>

          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
            <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              حاسبة التطهير الشرعي والزكاة (لكل ١٠٠ سهم)
            </h2>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <span className="text-slate-500 block">حالة التوافق (AAOIFI)</span>
                <span className="font-semibold">{sharia.compliant ? 'متوافق مبدئياً' : 'غير متوافق'}</span>
              </div>
              <div>
                <span className="text-slate-500 block">نسبة الإيراد غير المطابق</span>
                <span className="font-semibold tabular-nums">{formatNum(sharia.non_halal_pct, numerals, 1)}%</span>
              </div>
              <div>
                <span className="text-slate-500 block">تطهير ١٠٠ سهم تقديري</span>
                <span className="font-semibold tabular-nums">{formatEgp(sharia.total_purification_egp, numerals)}</span>
              </div>
              <div>
                <span className="text-slate-500 block">تقدير الزكاة السنوي (٢.٥%)</span>
                <span className="font-semibold tabular-nums">{formatEgp(sharia.zakat_estimate_egp, numerals)}</span>
              </div>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed">{sharia.note_ar}</p>
          </div>
        </div>
      )}
    </div>
  );
};
