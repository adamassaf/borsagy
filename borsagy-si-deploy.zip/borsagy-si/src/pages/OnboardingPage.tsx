import React, { useState } from 'react';
import { AppRoute } from '../components/Navbar';
import { ExperienceLevel, TraderMode } from '../core/types';
import { api } from '../lib/api';
import { NumeralMode, formatEgp, formatNum } from '../lib/formatters';

export const OnboardingPage: React.FC<{
  traderId: string;
  numerals: NumeralMode;
  onCompleted: () => void;
  onNavigate: (r: AppRoute) => void;
}> = ({ traderId, numerals, onCompleted, onNavigate }) => {
  const [step, setStep] = useState(1);
  const [maxAffordableLoss, setMaxAffordableLoss] = useState(15000);
  const [portfolioSize, setPortfolioSize] = useState(100000);
  const [borrowedMoney, setBorrowedMoney] = useState(false);
  const [moneyNotToRiskAck, setMoneyNotToRiskAck] = useState(false);
  const [experience, setExperience] = useState<ExperienceLevel>('beginner');
  const [goal, setGoal] = useState<'income' | 'growth' | 'speculation' | 'learning'>('growth');
  const [horizon, setHorizon] = useState<'days' | 'weeks' | 'months' | 'years'>('months');
  const [dailyLossLimit, setDailyLossLimit] = useState(2.0);
  const [weeklyLossLimit, setWeeklyLossLimit] = useState(5.0);
  const [shariaOnly, setShariaOnly] = useState(false);
  const [mode, setMode] = useState<TraderMode>('manager');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async () => {
    setBusy(true);
    setError(null);
    try {
      await api.submitOnboarding(
        {
          experience,
          goal,
          horizon,
          portfolio_size_egp: portfolioSize,
          max_affordable_loss_egp: maxAffordableLoss,
          daily_loss_limit_pct: dailyLossLimit,
          weekly_loss_limit_pct: weeklyLossLimit,
          borrowed_money_flag: borrowedMoney,
          money_not_to_risk_ack: moneyNotToRiskAck,
          preferred_sharia_only: shariaOnly,
          mode,
        },
        traderId
      );
      onCompleted();
      onNavigate('home');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'تعذر حفظ تقييم المخاطر.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto py-6 space-y-6">
      <div className="space-y-2">
        <div className="text-xs text-slate-500 dark:text-slate-400 tabular-nums">
          تقييم المخاطر الإلزامي · خطوة {formatNum(step, numerals, 0)} من {formatNum(5, numerals, 0)}
        </div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-50">
          {step === 1 && 'أول سؤال: ما المبلغ الذي تتحمل خسارته فعلاً؟'}
          {step === 2 && 'الأموال التي لا يجب المخاطرة بها'}
          {step === 3 && 'مستوى خبرتك والهدف الزمني'}
          {step === 4 && 'حدود الخسارة اليومية والأسبوعية'}
          {step === 5 && 'وضع المرافق والتفضيل الشرعي'}
        </h1>
      </div>

      {/* Step progress strip */}
      <div className="grid grid-cols-5 gap-2">
        {[1, 2, 3, 4, 5].map((s) => (
          <div
            key={s}
            className={`h-1.5 rounded-sm ${s <= step ? 'bg-slate-900 dark:bg-slate-100' : 'bg-slate-200 dark:bg-slate-800'}`}
          />
        ))}
      </div>

      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-5">
        {step === 1 && (
          <div className="space-y-4">
            <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              لا نبدأ بالحديث عن الأرباح أبداً. نبدأ بحجم المحفظة والمبلغ الذي إذا تراجع في أسوأ ظرف لن يؤثر على مصاريف بيتك الأساسية.
            </p>
            <div>
              <label htmlFor="onb-portfolio" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                حجم رأس المال المخصص للاستثمار (بالجنيه المصري)
              </label>
              <input
                id="onb-portfolio"
                type="number"
                min={1000}
                step={5000}
                value={portfolioSize}
                onChange={(e) => setPortfolioSize(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3.5 py-2.5 text-sm tabular-nums"
              />
            </div>
            <div>
              <label htmlFor="onb-max-loss" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                أقصى مبلغ إجمالي تتحمل تقلبه أو خسارته ({formatEgp(maxAffordableLoss, numerals)})
              </label>
              <input
                id="onb-max-loss"
                type="number"
                min={500}
                step={1000}
                value={maxAffordableLoss}
                onChange={(e) => setMaxAffordableLoss(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3.5 py-2.5 text-sm tabular-nums"
              />
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4">
            <div className="p-4 rounded-lg border border-amber-300 dark:border-amber-800 bg-amber-50/70 dark:bg-amber-950/30 text-sm text-amber-950 dark:text-amber-100 leading-relaxed">
              تذكير صريح: الإيجار، مصاريف المدارس، أقساط الديون، أو أموال الطوارئ لا مكان لها في البورصة. إذا كانت هذه أموالاً مقترضة فبورصجي سيتوقف عن اقتراح أي صفقات عالية المخاطر.
            </div>
            <label className="flex items-start gap-3 cursor-pointer p-3 rounded-lg border border-slate-200 dark:border-slate-800">
              <input
                type="checkbox"
                checked={borrowedMoney}
                onChange={(e) => setBorrowedMoney(e.target.checked)}
                className="mt-1"
              />
              <span className="text-sm text-slate-800 dark:text-slate-200">
                هذا المبلغ مقترض أو أحتاج إليه قريباً لسداد التزامات أساسية
              </span>
            </label>
            <label className="flex items-start gap-3 cursor-pointer p-3 rounded-lg border border-slate-200 dark:border-slate-800">
              <input
                type="checkbox"
                checked={moneyNotToRiskAck}
                onChange={(e) => setMoneyNotToRiskAck(e.target.checked)}
                className="mt-1"
              />
              <span className="text-sm text-slate-800 dark:text-slate-200">
                أؤكد أنني قرأت تنبيه المخاطر وأفهم أن التداول لا يضمن ربحاً
              </span>
            </label>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-4">
            <div>
              <span className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-2">خبرتك في البورصة المصرية</span>
              <div className="grid grid-cols-3 gap-2">
                {([
                  ['beginner', 'مبتدئ'],
                  ['active', 'متداول نشط'],
                  ['advanced', 'محترف'],
                ] as const).map(([val, lbl]) => (
                  <button
                    key={val}
                    type="button"
                    onClick={() => setExperience(val)}
                    className={`py-2.5 px-3 rounded-lg text-xs font-semibold border transition-colors ${
                      experience === val
                        ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 border-slate-900'
                        : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    {lbl}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">الهدف الأساسي</label>
                <select
                  value={goal}
                  onChange={(e) => setGoal(e.target.value as typeof goal)}
                  className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm"
                >
                  <option value="growth">نمو رأس المال</option>
                  <option value="income">توزيعات ودخل</option>
                  <option value="learning">تعلم منضبط</option>
                  <option value="speculation">تداول قصير الأجل</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">الأفق الزمني</label>
                <select
                  value={horizon}
                  onChange={(e) => setHorizon(e.target.value as typeof horizon)}
                  className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm"
                >
                  <option value="days">أيام</option>
                  <option value="weeks">أسابيع</option>
                  <option value="months">شهور</option>
                  <option value="years">سنوات</option>
                </select>
              </div>
            </div>
          </div>
        )}

        {step === 4 && (
          <div className="space-y-4">
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {experience === 'beginner'
                ? 'لحمايتك كمبتدئ: الحد اليومي مقيّد تلقائياً بحد أقصى ٣% والأسبوعي ٨%.'
                : 'عند الوصول إلى حد الخسارة، تتوقف الإشارات الجديدة تلقائياً لمدة ٢٤ ساعة.'}
            </p>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                حد الخسارة اليومي (%) — الحالي: {formatNum(dailyLossLimit, numerals, 1)}%
              </label>
              <input
                type="range"
                min={0.5}
                max={experience === 'beginner' ? 3 : 5}
                step={0.5}
                value={dailyLossLimit}
                onChange={(e) => setDailyLossLimit(Number(e.target.value))}
                className="w-full"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                حد الخسارة الأسبوعي (%) — الحالي: {formatNum(weeklyLossLimit, numerals, 1)}%
              </label>
              <input
                type="range"
                min={2}
                max={experience === 'beginner' ? 8 : 12}
                step={1}
                value={weeklyLossLimit}
                onChange={(e) => setWeeklyLossLimit(Number(e.target.value))}
                className="w-full"
              />
            </div>
          </div>
        )}

        {step === 5 && (
          <div className="space-y-4">
            <div>
              <span className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-2">
                أسلوب العمل المفضل مع بورصجي
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {([
                  ['manager', 'مدير محفظة (تنظيم وخطة)'],
                  ['advisor', 'مستشار (سؤال وجواب)'],
                  ['hybrid', 'مختلط (يتحول تلقائياً)'],
                ] as const).map(([val, lbl]) => (
                  <button
                    key={val}
                    type="button"
                    onClick={() => setMode(val)}
                    className={`py-2.5 px-3 rounded-lg text-xs font-semibold border transition-colors ${
                      mode === val
                        ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 border-slate-900'
                        : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    {lbl}
                  </button>
                ))}
              </div>
            </div>
            <label className="flex items-start gap-3 cursor-pointer p-3 rounded-lg border border-slate-200 dark:border-slate-800">
              <input
                type="checkbox"
                checked={shariaOnly}
                onChange={(e) => setShariaOnly(e.target.checked)}
                className="mt-1"
              />
              <span className="text-sm text-slate-800 dark:text-slate-200">
                تفضيل الأسهم المتوافقة مع الضوابط الشرعية فقط وإظهار نسبة التطهير والزكاة
              </span>
            </label>
          </div>
        )}

        {error && <p className="text-xs text-rose-700 dark:text-rose-400">{error}</p>}

        <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800">
          <button
            type="button"
            disabled={step === 1}
            onClick={() => setStep((s) => Math.max(1, s - 1))}
            className="px-4 py-2 rounded-lg text-xs font-medium border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 disabled:opacity-40"
          >
            السابق
          </button>

          {step < 5 ? (
            <button
              type="button"
              onClick={() => setStep((s) => s + 1)}
              className="px-5 py-2 rounded-lg text-xs font-semibold bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 hover:bg-slate-800"
            >
              التالي
            </button>
          ) : (
            <button
              type="button"
              disabled={busy}
              onClick={handleSubmit}
              className="px-5 py-2 rounded-lg text-xs font-semibold bg-emerald-700 text-white hover:bg-emerald-800 disabled:opacity-50"
            >
              {busy ? 'جاري الحفظ...' : 'حفظ الحدود والبدء'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
