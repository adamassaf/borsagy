import React, { useEffect, useState } from 'react';
import { AGENT_GROUPS } from '../core/agentsCatalog';
import { Fact, LicencePath, VersionedConfig } from '../core/types';
import { api } from '../lib/api';
import { NumeralMode, formatDateAr, formatInt, formatNum } from '../lib/formatters';

export const AdminPage: React.FC<{
  numerals: NumeralMode;
  onGovernanceChanged: () => void;
}> = ({ numerals, onGovernanceChanged }) => {
  const [authStatus, setAuthStatus] = useState<{ configured: boolean; viaEnv: boolean; bootstrapAllowed: boolean } | null>(null);
  // Bearer token held strictly in React state memory (never localStorage)
  const [adminToken, setAdminToken] = useState<string | null>(null);
  const [passcode, setPasscode] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);

  const [tab, setTab] = useState<'switches' | 'config' | 'ontology' | 'compliance' | 'brokers' | 'audit'>('switches');
  const [overview, setOverview] = useState<Awaited<ReturnType<typeof api.adminOverview>> | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  // Ontology Query state
  const [ontAsOf, setOntAsOf] = useState(new Date().toISOString().slice(0, 16));
  const [ontEntity, setOntEntity] = useState('Stock:COMI');
  const [ontResult, setOntResult] = useState<{ fact_count: number; facts: Fact[]; edges: Array<Record<string, unknown>> } | null>(null);
  const [newFactEntity, setNewFactEntity] = useState('Stock:COMI');
  const [newFactPred, setNewFactPred] = useState('last_price');
  const [newFactVal, setNewFactVal] = useState('85.25');

  // Compliance live tester state
  const [compText, setCompText] = useState('دخول سهم COMI عند 84.5 وهدف 91 مضمون 100%');
  const [compNums, setCompNums] = useState('84.5, 91');
  const [compRes, setCompRes] = useState<{ ok: boolean; errors: string[] } | null>(null);

  // Block symbol input
  const [blockSymbolInput, setBlockSymbolInput] = useState('');

  // Config draft
  const [cfgDraft, setCfgDraft] = useState<Partial<VersionedConfig>>({});

  // Broker fee verify state
  const [feeEdits, setFeeEdits] = useState<Record<string, { value: string; url: string }>>({});

  // 84-agent filter & live sync state
  const [agentSearch, setAgentSearch] = useState('');
  const [agentGroup, setAgentGroup] = useState('all');
  const [syncBusy, setSyncBusy] = useState(false);

  useEffect(() => {
    api.adminStatus().then(setAuthStatus).catch(() => {});
  }, []);

  const loadOverview = async (tok: string) => {
    try {
      const ov = await api.adminOverview(tok);
      setOverview(ov);
      setCfgDraft(ov.config);
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'انتهت جلسة المشرف أو فشل التحميل.');
      setAdminToken(null);
    }
  };

  useEffect(() => {
    if (adminToken) {
      loadOverview(adminToken);
    }
  }, [adminToken]);

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    try {
      const res = authStatus?.bootstrapAllowed
        ? await api.adminBootstrap(passcode)
        : await api.adminLogin(passcode);
      setAdminToken(res.token);
      setPasscode('');
    } catch (e2) {
      setAuthError(e2 instanceof Error ? e2.message : 'فشل التحقق.');
    }
  };

  const handleToggleGlobalPause = async () => {
    if (!adminToken || !overview) return;
    await api.adminKillSwitch({ global_pause_advice: !overview.kill_switches.global_pause_advice }, adminToken);
    setNotice('تم تحديث الإيقاف العام للتوصيات.');
    await loadOverview(adminToken);
    onGovernanceChanged();
  };

  const handleToggleCrisis = async () => {
    if (!adminToken || !overview) return;
    await api.adminKillSwitch({ crisis_mode_manual: !overview.kill_switches.crisis_mode_manual }, adminToken);
    setNotice('تم تحديث وضع الأزمة اليدوي.');
    await loadOverview(adminToken);
    onGovernanceChanged();
  };

  const handleToggleAgent = async (agentId: string) => {
    if (!adminToken || !overview) return;
    const cur = new Set(overview.kill_switches.disabled_agents);
    if (cur.has(agentId)) cur.delete(agentId);
    else cur.add(agentId);
    await api.adminKillSwitch({ disabled_agents: Array.from(cur) }, adminToken);
    setNotice(`تم تحديث حالة الوكيل ${agentId}.`);
    await loadOverview(adminToken);
  };

  const handleToggleBlockedSymbol = async (sym: string, add: boolean) => {
    if (!adminToken || !overview || !sym.trim()) return;
    const upper = sym.trim().toUpperCase();
    const cur = new Set(overview.kill_switches.blocked_symbols);
    if (add) cur.add(upper);
    else cur.delete(upper);
    await api.adminKillSwitch({ blocked_symbols: Array.from(cur) }, adminToken);
    setBlockSymbolInput('');
    setNotice(`تم تحديث قائمة الأسهم المحجوبة (${upper}).`);
    await loadOverview(adminToken);
    onGovernanceChanged();
  };

  const handleSaveConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminToken) return;
    const res = await api.adminUpdateConfig(cfgDraft, adminToken);
    setNotice(`تم إصدار النسخة v${res.config.version} من إعدادات الحوكمة.`);
    await loadOverview(adminToken);
    onGovernanceChanged();
  };

  const handleOntologySearch = async () => {
    if (!adminToken) return;
    const iso = new Date(ontAsOf).toISOString();
    const res = await api.adminOntologyQuery(
      { as_of: iso, entity_id: ontEntity.trim() || undefined },
      adminToken
    );
    setOntResult(res);
  };

  const handleAppendFact = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminToken) return;
    const numVal = Number(newFactVal);
    await api.adminAddFact(
      {
        entity_id: newFactEntity.trim(),
        predicate: newFactPred.trim(),
        value: Number.isNaN(numVal) ? newFactVal : numVal,
        kind: 'observed',
        quality: 'valid',
      },
      adminToken
    );
    setNotice(`تمت إضافة حقيقة زمنية جديدة للكيان ${newFactEntity}.`);
    await handleOntologySearch();
    await loadOverview(adminToken);
  };

  const handleComplianceTest = async () => {
    if (!adminToken) return;
    const nums = compNums
      .split(',')
      .map((s) => Number(s.trim()))
      .filter((n) => !Number.isNaN(n));
    const res = await api.adminComplianceTest(compText, nums, adminToken);
    setCompRes(res);
  };

  const handleReviewDecision = async (id: string, status: 'approved' | 'rejected') => {
    if (!adminToken) return;
    await api.adminResolveReview(id, status, adminToken);
    setNotice(`تم تسجيل قرار المراجعة (${status === 'approved' ? 'موافقة' : 'رفض'}).`);
    await loadOverview(adminToken);
  };

  const handleVerifyBrokerFee = async (brokerId: string, feeId: string) => {
    if (!adminToken) return;
    const edit = feeEdits[feeId];
    const numVal = Number(edit?.value);
    if (Number.isNaN(numVal)) {
      setErr('أدخل قيمة رسوم رقمية صحيحة للتوثيق.');
      return;
    }
    await api.adminUpdateBrokerFee(
      brokerId,
      {
        fee_id: feeId,
        value: numVal,
        status: 'verified',
        source_url: edit?.url || 'https://official-broker.example/fees',
        source_kind: 'official_price_list',
      },
      adminToken
    );
    setNotice('تم توثيق جدول الرسوم من المصدر الرسمي.');
    await loadOverview(adminToken);
  };

  const handleAdminSyncLive = async () => {
    if (!adminToken) return;
    setSyncBusy(true);
    setErr(null);
    try {
      const res = await api.adminSyncLive(adminToken);
      setNotice(
        `تمت مزامنة التغذية الحية (${res.live_feed_status.live_symbols_count} سهم EGX · دولار ${res.live_feed_status.usd_egp ?? '—'} ج.م).`
      );
      await loadOverview(adminToken);
      onGovernanceChanged();
    } catch (e2) {
      setErr(e2 instanceof Error ? e2.message : 'تعذر مزامنة الأسعار الحية.');
    } finally {
      setSyncBusy(false);
    }
  };

  // --- Auth Gate (First-Run Claim OR Bearer Login) ---
  if (!adminToken) {
    if (!authStatus) {
      return (
        <div className="max-w-md mx-auto py-16 text-center text-sm text-slate-500">
          جاري التحقق من حالة أمان المشرف...
        </div>
      );
    }
    return (
      <div className="max-w-md mx-auto py-12 space-y-5">
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
          <div className="space-y-1">
            <div className="text-xs text-slate-500">لوحة الحوكمة والتحكم (Admin Console)</div>
            <h1 className="text-xl font-bold text-slate-900 dark:text-slate-50">
              {authStatus?.bootstrapAllowed ? 'التهيئة الأولية لرمز المشرف' : 'تسجيل دخول المشرف'}
            </h1>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              {authStatus?.bootstrapAllowed
                ? 'لم يتم تعيين رمز دخول بعد. أنشئ رمز المشرف (٨ أحرف فأكثر) ليُحفظ مشفراً بالخادم باستخدام scrypt وتُقفل التهيئة تلقائياً.'
                : authStatus?.viaEnv
                  ? 'المصادقة مفعلة عبر متغير البيئة ADMIN_PASSCODE. أدخل الرمز للمتابعة.'
                  : 'أدخل رمز المشرف المعتمد لفتح مفاتيح الطوارئ والأنطولوجيا وإدارة الامتثال.'}
            </p>
          </div>

          <form onSubmit={handleAuthSubmit} className="space-y-3">
            <div>
              <label htmlFor="admin-passcode-input" className="block text-xs font-medium mb-1">
                {authStatus?.bootstrapAllowed ? 'رمز المشرف الجديد (٨+ أحرف)' : 'رمز الدخول'}
              </label>
              <input
                id="admin-passcode-input"
                type="password"
                required
                minLength={authStatus?.bootstrapAllowed ? 8 : 1}
                value={passcode}
                onChange={(e) => setPasscode(e.target.value)}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm"
              />
            </div>

            {authError && <p className="text-xs text-rose-700 dark:text-rose-400">{authError}</p>}

            <button
              type="submit"
              className="w-full px-4 py-2.5 rounded-lg text-xs font-semibold bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900"
            >
              {authStatus?.bootstrapAllowed ? 'تعيين رمز المشرف والدخول' : 'دخول لوحة الحوكمة'}
            </button>
          </form>
        </div>
      </div>
    );
  }

  if (!overview) return <div className="py-12 text-center text-sm text-slate-500">جاري تحميل وحدة الحوكمة...</div>;

  return (
    <div className="space-y-6 py-4">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="text-xs text-slate-500">
            borsagy.si · إصدار السياسات v{formatInt(overview.config.version, numerals)} · مسار الترخيص {overview.config.licence_path}
          </div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-50">لوحة الحوكمة والإدارة الكاملة</h1>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            disabled={syncBusy}
            onClick={handleAdminSyncLive}
            className="px-3.5 py-2 rounded-lg text-xs font-semibold bg-emerald-700 text-white hover:bg-emerald-800 disabled:opacity-50"
          >
            {syncBusy ? 'جاري المزامنة الحية...' : 'مزامنة السوق الحية'}
          </button>
          <a
            href="/api/export-repo.zip"
            download="borsagy-si-deploy.zip"
            className="px-3.5 py-2 rounded-lg text-xs font-semibold bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 hover:bg-slate-800"
          >
            تحميل حزمة الرفع (.zip)
          </a>
          <button
            type="button"
            onClick={() => setAdminToken(null)}
            className="px-3.5 py-2 rounded-lg text-xs font-medium border border-slate-300 dark:border-slate-700"
          >
            تسجيل خروج المشرف
          </button>
        </div>
      </div>

      {notice && <div className="rounded-xl border border-emerald-300 bg-emerald-50 p-3.5 text-xs text-emerald-900">{notice}</div>}
      {err && <div className="rounded-xl border border-rose-300 bg-rose-50 p-3.5 text-xs text-rose-900">{err}</div>}

      {/* Executive KPI Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-6 gap-3">
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
          <div className="text-xs text-slate-500">الأسهم بالمنصة</div>
          <div className="text-xl font-bold tabular-nums mt-1">{formatInt(Number(overview.kpis.total_stocks), numerals)}</div>
        </div>
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
          <div className="text-xs text-slate-500">الوكلاء المفعّلون</div>
          <div className="text-xl font-bold tabular-nums mt-1">
            {formatInt(Number(overview.kpis.enabled_agents ?? overview.agents.length), numerals)} / {formatInt(overview.agents.length, numerals)}
          </div>
        </div>
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
          <div className="text-xs text-slate-500">الحقائق الزمنية</div>
          <div className="text-xl font-bold tabular-nums mt-1">{formatInt(Number(overview.kpis.total_facts), numerals)}</div>
        </div>
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
          <div className="text-xs text-slate-500">النصائح المختومة</div>
          <div className="text-xl font-bold tabular-nums mt-1">{formatInt(Number(overview.kpis.total_advices), numerals)}</div>
        </div>
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
          <div className="text-xs text-slate-500">مراجعات معلقة</div>
          <div className="text-xl font-bold text-amber-700 tabular-nums mt-1">{formatInt(Number(overview.kpis.pending_reviews), numerals)}</div>
        </div>
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
          <div className="text-xs text-slate-500">سلامة سلسلة الختم</div>
          <div className={`text-sm font-bold mt-1.5 ${overview.kpis.seal_chain_valid ? 'text-emerald-700' : 'text-rose-700'}`}>
            {overview.kpis.seal_chain_valid ? 'SHA-256 موثقة' : 'خلل في السلسلة'}
          </div>
        </div>
      </div>

      {/* Admin Sub-tabs */}
      <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg w-fit max-w-full overflow-x-auto">
        {([
          ['switches', `مفاتيح الطوارئ والوكلاء (${overview.agents.length})`],
          ['config', 'الحدود المرقمة ومسار الترخيص'],
          ['ontology', 'استعلام الأنطولوجيا الزمني'],
          ['compliance', 'فاحص الامتثال وقائمة المراجعة'],
          ['brokers', 'توثيق رسوم الوسطاء'],
          ['audit', 'سجل التدقيق'],
        ] as const).map(([id, lbl]) => (
          <button
            key={id}
            type="button"
            onClick={() => setTab(id)}
            className={`px-3 py-2 rounded-md text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
              tab === id
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            {lbl}
          </button>
        ))}
      </div>

      {tab === 'switches' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
              <div className="text-sm font-bold">إيقاف عام لكل النصائح (Kill Switch)</div>
              <p className="text-xs text-slate-500">يحول أي طلب نصيحة فوراً إلى امتناع آمن عند الطوارئ.</p>
              <button
                type="button"
                onClick={handleToggleGlobalPause}
                className={`px-4 py-2 rounded-lg text-xs font-semibold ${
                  overview.kill_switches.global_pause_advice
                    ? 'bg-rose-700 text-white'
                    : 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900'
                }`}
              >
                {overview.kill_switches.global_pause_advice ? 'مفعّل (اضغط لإلغاء الإيقاف)' : 'غير مفعّل (اضغط لتفعيل الإيقاف)'}
              </button>
            </div>

            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
              <div className="text-sm font-bold">وضع الأزمة اليدوي (Crisis Mode)</div>
              <p className="text-xs text-slate-500">ينشط شريط التهدئة ويحول جميع النصائح إلى calm_down.</p>
              <button
                type="button"
                onClick={handleToggleCrisis}
                className={`px-4 py-2 rounded-lg text-xs font-semibold ${
                  overview.kill_switches.crisis_mode_manual
                    ? 'bg-amber-700 text-white'
                    : 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900'
                }`}
              >
                {overview.kill_switches.crisis_mode_manual ? 'وضع الأزمة نشط (إيقاف)' : 'تفعيل وضع الأزمة يدوياً'}
              </button>
            </div>

            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
              <div className="text-sm font-bold">الأسهم المحجوبة</div>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="رمز مثل SWDY"
                  value={blockSymbolInput}
                  onChange={(e) => setBlockSymbolInput(e.target.value)}
                  className="flex-1 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-2.5 py-1.5 text-xs"
                />
                <button
                  type="button"
                  onClick={() => handleToggleBlockedSymbol(blockSymbolInput, true)}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 text-white"
                >
                  حجب
                </button>
              </div>
              <div className="flex flex-wrap gap-2 text-xs">
                {overview.kill_switches.blocked_symbols.map((sym) => (
                  <button
                    key={sym}
                    type="button"
                    onClick={() => handleToggleBlockedSymbol(sym, false)}
                    className="px-2 py-1 rounded border border-rose-300 text-rose-700 hover:bg-rose-50"
                  >
                    {sym} ×
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Namecheap & GitHub ZIP Deployment Card */}
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 flex flex-wrap items-center justify-between gap-4 text-xs">
            <div className="space-y-1 max-w-2xl">
              <div className="text-sm font-bold text-slate-900 dark:text-slate-100">
                جاهزية الاستضافة والنشر — Namecheap / GitHub (<span className="font-mono">borsagy.si</span>)
              </div>
              <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                يشمل الأرشيف جميع ملفات الواجهة الأمامية والخادم والتغذية الحية ودليل النشر (<span className="font-mono">DEPLOY_NAMECHEAP.md</span>) مع استبعاد <span className="font-mono">node_modules</span> وملفات المفاتيح السرية.
              </p>
            </div>
            <a
              href="/api/export-repo.zip"
              download="borsagy-si-deploy.zip"
              className="px-4 py-2.5 rounded-lg text-xs font-semibold bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 hover:bg-slate-800 whitespace-nowrap"
            >
              تنزيل borsagy-si-deploy.zip
            </a>
          </div>

          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h2 className="text-sm font-bold">كتالوج الوكلاء الكامل ({formatInt(overview.agents.length, numerals)} وكيلاً — تشغيل / تعطيل فردي)</h2>
              <div className="flex flex-wrap items-center gap-2">
                <input
                  type="search"
                  placeholder="بحث برقم أو اسم الوكيل..."
                  value={agentSearch}
                  onChange={(e) => setAgentSearch(e.target.value)}
                  className="rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-1.5 text-xs"
                />
                <select
                  value={agentGroup}
                  onChange={(e) => setAgentGroup(e.target.value)}
                  className="rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-1.5 text-xs"
                >
                  <option value="all">كل المجموعات (84)</option>
                  {AGENT_GROUPS.map((g) => (
                    <option key={g.key} value={g.key}>
                      {g.code_ar}. {g.title_ar}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div className="overflow-x-auto max-h-[520px] overflow-y-auto">
              <table className="w-full text-xs text-right border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500">
                    <th className="py-2 px-2">#</th>
                    <th className="py-2 px-2">الوكيل</th>
                    <th className="py-2 px-2">المجموعة</th>
                    <th className="py-2 px-2">الباقة / الوحدة</th>
                    <th className="py-2 px-2">دقة المعايرة</th>
                    <th className="py-2 px-2">الحالة</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {overview.agents
                    .filter((ag) => (agentGroup === 'all' ? true : ag.group_key === agentGroup))
                    .filter(
                      (ag) =>
                        !agentSearch.trim() ||
                        ag.name_ar.toLowerCase().includes(agentSearch.trim().toLowerCase()) ||
                        ag.name_en.toLowerCase().includes(agentSearch.trim().toLowerCase()) ||
                        String(ag.number) === agentSearch.trim()
                    )
                    .map((ag) => (
                      <tr key={ag.id}>
                        <td className="py-2.5 px-2 font-mono">{ag.number}</td>
                        <td className="py-2.5 px-2 font-semibold whitespace-nowrap">{ag.name_ar}</td>
                        <td className="py-2.5 px-2 text-slate-500 whitespace-nowrap">{ag.group_ar}</td>
                        <td className="py-2.5 px-2 text-slate-500 font-mono">
                          {ag.tier.toUpperCase()} · {ag.v4_consolidated_to}
                        </td>
                        <td className="py-2.5 px-2 font-mono tabular-nums">
                          {formatNum(ag.calibration_hit_rate * 100, numerals, 0)}%
                        </td>
                        <td className="py-2.5 px-2">
                          <button
                            type="button"
                            onClick={() => handleToggleAgent(ag.id)}
                            className={`px-2.5 py-1 rounded text-xs font-semibold ${
                              ag.enabled
                                ? 'bg-emerald-700 text-white'
                                : 'bg-rose-700 text-white'
                            }`}
                          >
                            {ag.enabled ? 'مفعّل' : 'معطّل'}
                          </button>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {tab === 'config' && (
        <form
          onSubmit={handleSaveConfig}
          className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-5"
        >
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="block font-medium mb-1">مسار الترخيص التنظيمي (FRA)</label>
              <select
                value={cfgDraft.licence_path ?? 'PATH_B'}
                onChange={(e) => setCfgDraft({ ...cfgDraft, licence_path: e.target.value as LicencePath })}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm"
              >
                <option value="PATH_A">PATH_A (تعليم وتحليل فقط)</option>
                <option value="PATH_B">PATH_B (بيئة تجريبية / شريك مرخص)</option>
                <option value="PATH_C">PATH_C (ترخيص استثماري مستقل)</option>
              </select>
            </div>
            <div>
              <label className="block font-medium mb-1">الحد الأقصى لعمر البيانات (ثانية)</label>
              <input
                type="number"
                value={cfgDraft.age_max_intraday_seconds ?? 1200}
                onChange={(e) => setCfgDraft({ ...cfgDraft, age_max_intraday_seconds: Number(e.target.value) })}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm tabular-nums"
              />
            </div>
            <div>
              <label className="block font-medium mb-1">سقف التركز للمبتدئ (%)</label>
              <input
                type="number"
                value={cfgDraft.single_stock_cap_beginner_pct ?? 15}
                onChange={(e) => setCfgDraft({ ...cfgDraft, single_stock_cap_beginner_pct: Number(e.target.value) })}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm tabular-nums"
              />
            </div>
            <div>
              <label className="block font-medium mb-1">أدنى ثقة قبل الامتناع (0..1)</label>
              <input
                type="number"
                step="0.05"
                value={cfgDraft.abstain_min_confidence ?? 0.55}
                onChange={(e) => setCfgDraft({ ...cfgDraft, abstain_min_confidence: Number(e.target.value) })}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm tabular-nums"
              />
            </div>
            <div>
              <label className="block font-medium mb-1">عتبة الانفعال Tilt (0..100)</label>
              <input
                type="number"
                value={cfgDraft.tilt_threshold ?? 60}
                onChange={(e) => setCfgDraft({ ...cfgDraft, tilt_threshold: Number(e.target.value) })}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm tabular-nums"
              />
            </div>
            <div>
              <label className="block font-medium mb-1">نسبة هبوط المؤشر للأزمة (%)</label>
              <input
                type="number"
                step="0.5"
                value={cfgDraft.crisis_index_drop_pct ?? 3.0}
                onChange={(e) => setCfgDraft({ ...cfgDraft, crisis_index_drop_pct: Number(e.target.value) })}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm tabular-nums"
              />
            </div>
          </div>

          <button
            type="submit"
            className="px-5 py-2.5 rounded-lg text-xs font-semibold bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900"
          >
            اعتماد التحديث كنسخة جديدة (Versioned Config)
          </button>
        </form>
      )}

      {tab === 'ontology' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
            <h2 className="text-sm font-bold">الاستعلام الثنائي الزمني ("كما كانت معروفة عند T")</h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <input
                type="datetime-local"
                value={ontAsOf}
                onChange={(e) => setOntAsOf(e.target.value)}
                className="rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-2.5 py-2"
              />
              <input
                type="text"
                placeholder="الكيان مثل Stock:COMI"
                value={ontEntity}
                onChange={(e) => setOntEntity(e.target.value)}
                className="rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-2.5 py-2"
              />
              <button
                type="button"
                onClick={handleOntologySearch}
                className="px-4 py-2 rounded-lg font-semibold bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900"
              >
                تشغيل الاستعلام الزمني
              </button>
            </div>

            {ontResult && (
              <div className="space-y-2 text-xs">
                <div className="font-semibold">النتائج عند اللحظة المحددة: {ontResult.fact_count} حقيقة</div>
                <div className="max-h-72 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
                  {ontResult.facts.map((f) => (
                    <div key={f.id} className="py-2 flex justify-between gap-3 font-mono">
                      <span>{f.entity_id} · {f.predicate}</span>
                      <span className="font-bold">{String(f.value)}</span>
                      <span className="text-slate-500">{f.known_at.slice(0, 16)}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <form
            onSubmit={handleAppendFact}
            className="lg:col-span-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3"
          >
            <h2 className="text-sm font-bold">إضافة حقيقة جديدة (Append-Only Fact)</h2>
            <input
              type="text"
              value={newFactEntity}
              onChange={(e) => setNewFactEntity(e.target.value)}
              placeholder="Stock:COMI"
              className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-xs"
            />
            <input
              type="text"
              value={newFactPred}
              onChange={(e) => setNewFactPred(e.target.value)}
              placeholder="last_price"
              className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-xs"
            />
            <input
              type="text"
              value={newFactVal}
              onChange={(e) => setNewFactVal(e.target.value)}
              placeholder="القيمة"
              className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-xs"
            />
            <button
              type="submit"
              className="px-4 py-2 rounded-lg text-xs font-semibold bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900"
            >
              إلحاق الحقيقة بالسجل الزمني
            </button>
          </form>
        </div>
      )}

      {tab === 'compliance' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
            <h2 className="text-sm font-bold">مختبر بوابة الامتثال (Banned Phrases & Untraced Numbers)</h2>
            <textarea
              rows={3}
              value={compText}
              onChange={(e) => setCompText(e.target.value)}
              className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 p-2.5 text-xs"
            />
            <input
              type="text"
              value={compNums}
              onChange={(e) => setCompNums(e.target.value)}
              placeholder="الأرقام المسموح بها مفصولة بفاصلة"
              className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-xs font-mono"
            />
            <button
              type="button"
              onClick={handleComplianceTest}
              className="px-4 py-2 rounded-lg text-xs font-semibold bg-slate-900 text-white"
            >
              فحص النص ضد البوابة
            </button>
            {compRes && (
              <div className={`p-3 rounded-lg text-xs ${compRes.ok ? 'bg-emerald-50 text-emerald-900' : 'bg-rose-50 text-rose-900'}`}>
                {compRes.ok ? 'النص مطابق لجميع قواعد الامتثال.' : `محظور (${compRes.errors.join(' · ')})`}
              </div>
            )}
          </div>

          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
            <h2 className="text-sm font-bold">قائمة المراجعة البشرية ({overview.review_queue.length})</h2>
            <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
              {overview.review_queue.map((item) => (
                <div key={item.id} className="py-3 space-y-2">
                  <div className="flex justify-between font-semibold">
                    <span>{item.subject} · {item.kind}</span>
                    <span>{item.status}</span>
                  </div>
                  <p className="text-slate-600 dark:text-slate-300">{item.summary_ar}</p>
                  {item.status === 'pending' && (
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => handleReviewDecision(item.id, 'approved')}
                        className="px-3 py-1 rounded bg-emerald-700 text-white"
                      >
                        اعتماد
                      </button>
                      <button
                        type="button"
                        onClick={() => handleReviewDecision(item.id, 'rejected')}
                        className="px-3 py-1 rounded bg-rose-700 text-white"
                      >
                        رفض
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {tab === 'brokers' && (
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
          <h2 className="text-sm font-bold">إدارة توثيق رسوم شركات التداول</h2>
          <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
            {overview.brokers.map((b) => {
              const comm = b.fees.find((f) => f.fee_type === 'commission');
              if (!comm) return null;
              return (
                <div key={b.id} className="py-3 flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <div className="font-bold">{b.name_ar}</div>
                    <div className="text-slate-500">
                      الحالة: {comm.status === 'verified' ? `موثق (${comm.value}%)` : 'غير مؤكد (to_collect)'}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      step="0.01"
                      placeholder="العمولة %"
                      value={feeEdits[comm.id]?.value ?? (comm.value ?? '')}
                      onChange={(e) =>
                        setFeeEdits({
                          ...feeEdits,
                          [comm.id]: { value: e.target.value, url: feeEdits[comm.id]?.url ?? comm.source_url },
                        })
                      }
                      className="w-24 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-2 py-1"
                    />
                    <button
                      type="button"
                      onClick={() => handleVerifyBrokerFee(b.id, comm.id)}
                      className="px-3 py-1.5 rounded bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-semibold"
                    >
                      توثيق من قائمة رسمية
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {tab === 'audit' && (
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
          <h2 className="text-sm font-bold">سجل التدقيق غير القابل للتعديل (Audit Log)</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-right border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500">
                  <th className="py-2">#</th>
                  <th className="py-2">الفاعل</th>
                  <th className="py-2">الإجراء</th>
                  <th className="py-2">الهدف</th>
                  <th className="py-2">التوقيت</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {overview.audit_logs.map((log) => (
                  <tr key={log.id}>
                    <td className="py-2 font-mono">{log.id}</td>
                    <td className="py-2 font-semibold">{log.actor}</td>
                    <td className="py-2">{log.action}</td>
                    <td className="py-2 font-mono text-slate-500">{log.subject}</td>
                    <td className="py-2 text-slate-500">{formatDateAr(log.at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
