import React, { useEffect, useState } from 'react';
import { EvidenceDrawer } from '../components/EvidenceDrawer';
import { OrderPrepModal } from '../components/Modals';
import { AppRoute } from '../components/Navbar';
import { PlanCard } from '../components/PlanCard';
import { AgreementDots, ConfidenceBar, ConflictBanner, DataAgeBadge } from '../components/SignalMeters';
import { api } from '../lib/api';
import { NumeralMode, formatDateAr } from '../lib/formatters';

export const AdvicePage: React.FC<{
  adviceId: string;
  traderId: string;
  numerals: NumeralMode;
  onNavigate: (route: AppRoute, param?: string) => void;
}> = ({ adviceId, traderId, numerals, onNavigate }) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<Awaited<ReturnType<typeof api.getAdvice>> | null>(null);
  const [prepOpen, setPrepOpen] = useState(false);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError(null);
    api
      .getAdvice(adviceId)
      .then((res) => {
        if (active) setData(res);
      })
      .catch((e) => {
        if (active) setError(e instanceof Error ? e.message : 'تعذر تحميل التوصية.');
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [adviceId]);

  const handleDismiss = async () => {
    try {
      const res = await api.dismissAdvice(adviceId);
      setData((prev) => (prev ? { ...prev, advice: res.advice } : prev));
      setStatusMsg('تم تسجيل التريث وتجاهل الخطة باحترام كامل لقرارك.');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'تعذر التحديث.');
    }
  };

  if (loading) {
    return <div className="py-12 text-center text-sm text-slate-500">جاري تحميل النصيحة وسلسلة الأدلة...</div>;
  }

  if (error || !data) {
    return (
      <div className="rounded-xl border border-rose-300 bg-rose-50 p-6 text-sm text-rose-800 space-y-3">
        <p>{error ?? 'النصيحة غير موجودة.'}</p>
        <button
          type="button"
          onClick={() => onNavigate('home')}
          className="px-4 py-2 rounded-lg text-xs font-semibold bg-slate-900 text-white"
        >
          العودة للموجز
        </button>
      </div>
    );
  }

  const { advice, stock_name_ar } = data;
  const isCalmOrAbstain = advice.kind === 'abstain' || advice.kind === 'calm_down' || advice.kind === 'alternative';

  return (
    <div className="max-w-4xl mx-auto space-y-6 py-4">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="text-xs text-slate-500 dark:text-slate-400">
            {stock_name_ar ?? advice.symbol} · وضع {advice.mode === 'manager' ? 'مدير المحفظة' : 'المستشار'} · {formatDateAr(advice.sealed_at)}
          </div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-50">
            {advice.kind === 'calm_down'
              ? 'إيقاف وقائي وتهدئة'
              : advice.kind === 'abstain'
                ? 'امتناع مدروس عن التوصية'
                : `مراجعة خطة سهم ${advice.symbol}`}
          </h1>
        </div>
        <DataAgeBadge seconds={advice.data_age_seconds} numerals={numerals} />
      </div>

      {statusMsg && (
        <div className="rounded-xl border border-emerald-300 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/30 p-4 text-sm text-emerald-900 dark:text-emerald-100">
          {statusMsg}
        </div>
      )}

      {/* Companion 3-Sentence Card */}
      <div
        className={`rounded-xl border p-6 space-y-5 ${
          advice.kind === 'calm_down'
            ? 'border-amber-300 dark:border-amber-800 bg-amber-50/70 dark:bg-amber-950/20'
            : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
        }`}
      >
        <p className="text-lg font-medium text-slate-900 dark:text-slate-100 leading-relaxed">
          {advice.text_ar}
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-100 dark:border-slate-800">
          <ConfidenceBar confidence={advice.confidence} numerals={numerals} />
          <AgreementDots agreement={advice.agent_agreement} conflictFlags={advice.conflict_flags} numerals={numerals} />
        </div>

        <ConflictBanner flags={advice.conflict_flags} />

        {advice.red_team_ar && (
          <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 p-4 text-xs text-slate-700 dark:text-slate-300 space-y-1">
            <div className="font-semibold text-slate-900 dark:text-slate-100">رأي محامي الشيطان (أقوى حجة مضادة)</div>
            <p className="leading-relaxed">{advice.red_team_ar}</p>
          </div>
        )}

        <p className="text-[11px] text-slate-500 dark:text-slate-400">{advice.disclaimer_ar}</p>
      </div>

      {/* Plan Card if permitted */}
      {!isCalmOrAbstain && advice.plan_draft && (
        <PlanCard
          plan={advice.plan_draft}
          numerals={numerals}
          approved={advice.status === 'approved'}
          onApprovePrep={() => setPrepOpen(true)}
          onDismiss={handleDismiss}
        />
      )}

      {/* 3-Level Progressive Evidence Drawer */}
      <EvidenceDrawer adviceId={advice.id} numerals={numerals} />

      <OrderPrepModal
        open={prepOpen}
        onClose={() => setPrepOpen(false)}
        plan={advice.plan_draft ?? null}
        adviceId={advice.id}
        traderId={traderId}
        numerals={numerals}
        onPaperExecuted={(msg) => {
          setStatusMsg(msg);
          setData((prev) => (prev ? { ...prev, advice: { ...prev.advice, status: 'approved' } } : prev));
        }}
      />
    </div>
  );
};
