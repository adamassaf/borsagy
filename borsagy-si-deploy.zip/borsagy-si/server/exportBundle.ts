import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

export const BUNDLE_FILENAME = 'borsagy-si-deploy.zip';

export function getBundlePath(): string {
  return path.resolve(process.cwd(), 'public', BUNDLE_FILENAME);
}

export function buildRepoDeployZip(): { path: string; sizeBytes: number } {
  const outPath = getBundlePath();
  const outDir = path.dirname(outPath);
  if (!fs.existsSync(outDir)) {
    fs.mkdirSync(outDir, { recursive: true });
  }

  const pyScript = `
import os, zipfile

root = os.getcwd()
out_path = ${JSON.stringify(outPath)}
tmp_path = out_path + ".tmp"

exclude_dirs = {
  "node_modules", "dist", "dist-server", "data",
  ".playwright-cli", ".git", ".next", "__pycache__",
  ".aistudio", "aistudio"
}
exclude_files = {
  ".env", "borsagy-si-deploy.zip", "borsagy-si-deploy.zip.tmp"
}

with zipfile.ZipFile(tmp_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
  for dirpath, dirnames, filenames in os.walk(root):
    dirnames[:] = [d for d in dirnames if d not in exclude_dirs]
    for fn in filenames:
      if fn in exclude_files or fn.endswith(".zip") or fn.endswith(".log"):
        continue
      full = os.path.join(dirpath, fn)
      rel = os.path.relpath(full, root)
      zf.write(full, os.path.join("borsagy-si", rel))

os.replace(tmp_path, out_path)
print(os.path.getsize(out_path))
`.trim();

  execFileSync('python3', ['-c', pyScript], { cwd: process.cwd(), stdio: 'pipe' });
  const stat = fs.statSync(outPath);
  return { path: outPath, sizeBytes: stat.size };
}
