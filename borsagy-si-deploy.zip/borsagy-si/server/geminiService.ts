import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';
import { SHORT_DISCLAIMER_AR } from '../src/core/marketPack';
import { AdviceKind } from '../src/core/types';

function getAiClient(): GoogleGenAI | null {
  const apiKey = (process.env.GEMINI_API_KEY ?? '').trim();
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

const COMPLIANCE_SYSTEM_PROMPT = `أنت المساعد اللغوي لمنصة "بورصجي" لمرافقة المستثمر في البورصة المصرية.
القواعد الست الملزمة:
1. لا تنفذ أي صفقة ولا تدّع القدرة على التنفيذ ولا تطلب كلمات مرور.
2. لا تستخدم أي رقم غير موجود في القيم المزوّدة لك (أعد الرموز النائبة {slot} كما هي دون تغيير أو اختراع أرقام).
3. لا تستخدم عبارات الضمان أو اليقين أو التحفيز (ممنوع: مضمون، ربح أكيد، بدون مخاطرة، 100% آمن، فرصة متتكررش، الحل الوحيد، أفضل شركة، ذكاء فائق).
4. لا تتجاوز 3 جمل قصيرة وواضحة بالعامية المصرية الدافئة والمهذبة (أو العربية البسيطة للمصطلحات).
5. شجّع دائماً على الانضباط ووقف الخسارة واحترم حق التوقف والانتظار.
6. التزم بالإطار المعرفي: لا تتحدث في العملات الرقمية نهائياً.`;

function sleepMs(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

interface ResilientAttempt {
  model: string;
  useThinking: boolean;
  delayBeforeMs: number;
}

const DEFAULT_ATTEMPTS: ResilientAttempt[] = [
  { model: 'gemini-4-hydrogen', useThinking: true, delayBeforeMs: 0 },
  { model: 'gemini-4-hydrogen', useThinking: true, delayBeforeMs: 700 },
  { model: 'gemini-3.1-flash-lite', useThinking: false, delayBeforeMs: 450 },
];

async function generateWithResilience(
  ai: GoogleGenAI,
  buildParams: (attempt: ResilientAttempt) => Parameters<typeof ai.models.generateContent>[0]
): Promise<{ text: string | null; lastErr: unknown }> {
  let lastErr: unknown = null;
  for (const attempt of DEFAULT_ATTEMPTS) {
    if (attempt.delayBeforeMs > 0) {
      await sleepMs(attempt.delayBeforeMs);
    }
    try {
      const response = await ai.models.generateContent(buildParams(attempt));
      const text = (response.text ?? '').trim();
      if (text.length > 0) {
        return { text, lastErr: null };
      }
    } catch (err) {
      lastErr = err;
      const rawMsg = (err instanceof Error ? err.message : String(err ?? '')).toUpperCase();
      if (rawMsg.includes('API_KEY_INVALID') || rawMsg.includes('PERMISSION_DENIED')) {
        break;
      }
    }
  }
  return { text: null, lastErr };
}

/**
 * Composes warm Egyptian dialect prose around strict placeholder slots ({entry}, {stop}, {target1}, {size_pct})
 * so zero unverified numbers can be hallucinated. Falls back cleanly to deterministic templates when GEMINI_API_KEY is absent.
 */
export async function composeCompanionWithGemini(params: {
  kind: AdviceKind;
  slots: Record<string, string | number>;
  templateText: string;
  mode: 'manager' | 'advisor';
}): Promise<string | null> {
  const ai = getAiClient();
  if (!ai) return null;

  try {
    const slotKeys = Object.keys(params.slots);
    const prompt = `اكتب رسالة للمستخدم بالعامية المصرية الهادئة (بحد أقصى 3 جمل قصيرة) لنوع النصيحة "${params.kind}" في وضع "${params.mode === 'manager' ? 'مدير المحفظة' : 'المستشار'}".
يجب أن تستخدم كل هذه الرموز حرفياً داخل النص بدون استبدالها بأرقام: ${slotKeys.map((k) => `{${k}}`).join('، ')}.
لا تضف أي رقم آخر من عندك أبداً.
المعنى المرجعي: ${params.templateText}
أعد الناتج في JSON بحقل واحد text_ar.`;

    const { text } = await generateWithResilience(ai, (attempt) => ({
      model: attempt.model,
      contents: prompt,
      config: {
        systemInstruction: COMPLIANCE_SYSTEM_PROMPT,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            text_ar: { type: Type.STRING, description: 'Egyptian Arabic response <= 3 sentences with placeholders intact' },
          },
          required: ['text_ar'],
        },
        ...(attempt.useThinking ? { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } } : {}),
      },
    }));

    if (!text) return null;
    const parsed = JSON.parse(text) as { text_ar?: string };
    if (!parsed.text_ar) return null;

    // Verify every required placeholder survived intact before substituting real numbers
    for (const k of slotKeys) {
      if (!parsed.text_ar.includes(`{${k}}`)) {
        return null;
      }
    }

    let finalStr = parsed.text_ar;
    for (const [k, v] of Object.entries(params.slots)) {
      finalStr = finalStr.replaceAll(`{${k}}`, String(v));
    }
    return finalStr;
  } catch {
    return null;
  }
}

export interface DisclosureExtractionResult {
  used_ai: boolean;
  event_type: 'dividend' | 'capital_increase' | 'results' | 'ownership_change' | 'halt' | 'general';
  direction: 'positive' | 'negative' | 'neutral';
  summary_ar: string;
  key_points_ar: string[];
  requires_human_review: boolean;
  disclaimer_ar: string;
}

export async function extractDisclosureEvents(params: {
  symbol: string;
  disclosureText: string;
}): Promise<DisclosureExtractionResult> {
  const ai = getAiClient();
  const cleanText = params.disclosureText.trim();

  if (ai && cleanText.length > 0) {
    try {
      const { text } = await generateWithResilience(ai, (attempt) => ({
        model: attempt.model,
        contents: `حلل نص الإفصاح التالي الخاص بسهم ${params.symbol} في البورصة المصرية واستخرج نوع الحدث والاتجاه العام والملخص العربي المبسط بدون اختراع أرقام غير مذكورة في النص:\n\n${cleanText}`,
        config: {
          systemInstruction: COMPLIANCE_SYSTEM_PROMPT,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              event_type: {
                type: Type.STRING,
                description: 'One of: dividend, capital_increase, results, ownership_change, halt, general',
              },
              direction: { type: Type.STRING, description: 'positive, negative, or neutral' },
              summary_ar: { type: Type.STRING, description: 'Concise neutral Arabic summary in max 2 sentences' },
              key_points_ar: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              requires_human_review: { type: Type.BOOLEAN },
            },
            required: ['event_type', 'direction', 'summary_ar', 'key_points_ar', 'requires_human_review'],
          },
          ...(attempt.useThinking ? { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } } : {}),
        },
      }));
      if (text) {
        const parsed = JSON.parse(text) as Partial<DisclosureExtractionResult>;
        if (parsed.summary_ar && parsed.event_type) {
          return {
            used_ai: true,
            event_type: parsed.event_type as DisclosureExtractionResult['event_type'],
            direction: (parsed.direction as DisclosureExtractionResult['direction']) ?? 'neutral',
            summary_ar: parsed.summary_ar,
            key_points_ar: Array.isArray(parsed.key_points_ar) ? parsed.key_points_ar.slice(0, 4) : [],
            requires_human_review: Boolean(parsed.requires_human_review),
            disclaimer_ar: SHORT_DISCLAIMER_AR,
          };
        }
      }
    } catch {
      // Fall through to deterministic parser below
    }
  }

  // Deterministic Arabic disclosure rule-based fallback
  const lower = cleanText.toLowerCase();
  let event_type: DisclosureExtractionResult['event_type'] = 'general';
  let direction: DisclosureExtractionResult['direction'] = 'neutral';
  if (lower.includes('توزيع') || lower.includes('كوبون') || lower.includes('أرباح')) {
    event_type = lower.includes('كوبون') || lower.includes('توزيع') ? 'dividend' : 'results';
    direction = lower.includes('تراجع') || lower.includes('خسائر') ? 'negative' : 'positive';
  } else if (lower.includes('زيادة رأس المال') || lower.includes('اكتتاب')) {
    event_type = 'capital_increase';
    direction = 'neutral';
  } else if (lower.includes('إيقاف') || lower.includes('وقف التداول')) {
    event_type = 'halt';
    direction = 'negative';
  } else if (lower.includes('مساهم') || lower.includes('ملكية') || lower.includes('بيع حصة')) {
    event_type = 'ownership_change';
    direction = 'neutral';
  }

  return {
    used_ai: false,
    event_type,
    direction,
    summary_ar: `ملخص آلي للإفصاح الخاص بسهم ${params.symbol}: تم تصنيفه كحدث (${event_type}) ويُنصح بمراجعة نص الإفصاح الرسمي قبل أي قرار.`,
    key_points_ar: [
      `التصنيف الأولي: ${event_type}`,
      'المصدر: قراءة آلية أولية لنص الإفصاح المدخل (تتطلب تحققاً من المستند الأصلي).',
    ],
    requires_human_review: event_type === 'halt' || event_type === 'capital_increase',
    disclaimer_ar: SHORT_DISCLAIMER_AR,
  };
}

export async function explainTermWithGemini(termAr: string, fallbackSimpleAr: string): Promise<{
  used_ai: boolean;
  explanation_ar: string;
}> {
  const ai = getAiClient();
  if (!ai) {
    return { used_ai: false, explanation_ar: fallbackSimpleAr };
  }
  try {
    const { text } = await generateWithResilience(ai, (attempt) => ({
      model: attempt.model,
      contents: `اشرح مصطلح "${termAr}" لمستثمر مبتدئ في البورصة المصرية بالعامية المصرية الواضحة في جملتين مع مثال عملي بدون أرقام موعودة.`,
      config: {
        systemInstruction: COMPLIANCE_SYSTEM_PROMPT,
        ...(attempt.useThinking ? { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } } : {}),
      },
    }));
    if (text && text.length > 10) {
      return { used_ai: true, explanation_ar: text };
    }
  } catch {
    // Fallback
  }
  return { used_ai: false, explanation_ar: fallbackSimpleAr };
}

export interface AgentCopilotResponse {
  used_ai: boolean;
  answer_ar: string;
  suggested_questions_ar: string[];
  disclaimer_ar: string;
  ai_error?: string;
}

function formatFriendlyAiError(err: unknown): string {
  const raw = err instanceof Error ? err.message : String(err ?? '');
  const upper = raw.toUpperCase();
  if (upper.includes('503') || upper.includes('UNAVAILABLE') || upper.includes('HIGH DEMAND')) {
    return 'يشهد خادم الذكاء الاصطناعي ضغطاً مؤقتاً حالياً، لذا عُرض الشرح التشغيلي المعتمد من بيانات المنصة؛ يمكنك إعادة المحاولة بعد لحظات.';
  }
  if (upper.includes('429') || upper.includes('RESOURCE_EXHAUSTED')) {
    return 'تم بلوغ الحد اللحظي لطلبات الذكاء الاصطناعي، وعُرض الشرح التشغيلي المعتمد مؤقتاً.';
  }
  if (upper.includes('403') || upper.includes('API_KEY_INVALID') || upper.includes('PERMISSION_DENIED')) {
    return 'مفتاح Gemini API يحتاج مراجعة في إعدادات البيئة؛ تم عرض الشرح التشغيلي المعتمد.';
  }
  return 'تعذر الوصول الفوري لنموذج الذكاء الاصطناعي، وتم عرض الشرح التشغيلي المعتمد من الأنطولوجيا.';
}

function buildQuestionAwareFallback(params: {
  question: string;
  symbol: string;
  stockNameAr: string;
  agentNumber: number;
  agentNameAr: string;
  readsAr: string;
  writesAr: string;
  outputAr: string;
  summaryAr: string;
  verdictAr: string;
  metrics: Array<{ label_ar: string; value: string; source_fact_id: string }>;
  stepsAr: string[];
  cautionAr: string;
}): string {
  const q = params.question;
  const metricsText = params.metrics
    .map((m) => `• ${m.label_ar}: ${m.value} (Fact: ${m.source_fact_id})`)
    .join('\n');

  if (q.includes('أخطاء') || q.includes('يحميني') || q.includes('يحمي')) {
    return [
      `يحمي الوكيل #${params.agentNumber} (${params.agentNameAr}) المستثمر من التسرع والعشوائية عبر وظيفته: ${params.outputAr}.`,
      `على سهم ${params.symbol} (${params.stockNameAr}) الآن، يقرأ الوكيل (${params.readsAr}) ليكتب (${params.writesAr}) وتظهر القراءة الموثقة كالتالي:\n${metricsText}`,
      `الخلاصة العملية: ${params.verdictAr}`,
    ].join('\n\n');
  }

  if (q.includes('أمتنع') || q.includes('يرفض') || q.includes('متى')) {
    return [
      `يمتنع أو يحذّر الوكيل #${params.agentNumber} (${params.agentNameAr}) تلقائياً عند اختلال شروط الجودة أو تجاوز السقوف الآمنة: ${params.cautionAr}`,
      `حالة ${params.symbol} الحالية في الفحص:\n${metricsText}\n(${params.verdictAr})`,
      `لتأكيد القرار خطوة بخطوة: ${params.stepsAr.join(' ← ')}`,
    ].join('\n\n');
  }

  if (q.includes('أستفيد') || q.includes('قبل الشراء') || q.includes('كيف أستخدم')) {
    return [
      `للاستفادة من الوكيل #${params.agentNumber} (${params.agentNameAr}) قبل فتح أي صفقة على ${params.symbol} (${params.stockNameAr}):\n1) راجع ما يقرأه من الأنطولوجيا (${params.readsAr}).\n2) تأكد من عدم تعارض النتيجة مع سقوف محفظتك (${params.verdictAr}).`,
      `الأرقام المعتمدة الآن لسهم ${params.symbol}:\n${metricsText}`,
      `التطبيق المباشر: ${params.stepsAr.join(' ← ')}`,
    ].join('\n\n');
  }

  if (q.includes('مثال') || q.includes('اشرح')) {
    return [
      `بالمثال الحي على سهم ${params.symbol} (${params.stockNameAr}): دور الوكيل #${params.agentNumber} (${params.agentNameAr}) هو: ${params.outputAr}.`,
      `ما يقرأه الآن من الحقائق المسجلة:\n${metricsText}\nالنتيجة التحليلية: ${params.summaryAr}`,
      `الحكم التشغيلي: ${params.verdictAr}\nتنبيه الأمان: ${params.cautionAr}`,
    ].join('\n\n');
  }

  return [
    `على سهم ${params.symbol} (${params.stockNameAr})، يختص الوكيل #${params.agentNumber} (${params.agentNameAr}) بـ: ${params.outputAr}.`,
    `القيم الموثقة حالياً:\n${metricsText}\nالتفسير: ${params.summaryAr}`,
    `التوصية الانضباطية: ${params.verdictAr}\nتنبيه الحماية: ${params.cautionAr}`,
  ].join('\n\n');
}

export async function askAgentCopilotWithGemini(params: {
  question: string;
  symbol: string;
  stockNameAr: string;
  agentNumber: number;
  agentNameAr: string;
  agentNameEn: string;
  groupAr: string;
  tier: string;
  readsAr: string;
  writesAr: string;
  outputAr: string;
  summaryAr: string;
  verdictAr: string;
  metrics: Array<{ label_ar: string; value: string; source_fact_id: string }>;
  stepsAr: string[];
  cautionAr: string;
  history?: Array<{ role: 'user' | 'assistant'; text: string }>;
}): Promise<AgentCopilotResponse> {
  const ai = getAiClient();
  const defaultSuggestions = [
    `اشرح لي الوكيل #${params.agentNumber} بمثال عملي على سهم ${params.symbol}`,
    `كيف أستفيد من «${params.agentNameAr}» قبل الشراء؟`,
    `متى يرفض هذا الوكيل أو يمتنع عن الإشارة؟`,
  ];

  const deterministicAnswer = buildQuestionAwareFallback(params);

  if (!ai) {
    return {
      used_ai: false,
      answer_ar: deterministicAnswer,
      suggested_questions_ar: defaultSuggestions,
      disclaimer_ar: SHORT_DISCLAIMER_AR,
    };
  }

  const metricsSummary = params.metrics.map((m) => `- ${m.label_ar}: ${m.value} (Fact: ${m.source_fact_id})`).join('\n');
  const historySnippet = (params.history ?? [])
    .slice(-4)
    .map((h) => `${h.role === 'user' ? 'المستثمر' : 'المساعد'}: ${h.text}`)
    .join('\n');

  const prompt = `أنت Copilot تعليمي وتفاعلي داخل منصة بورصجي (borsagy.si) تساعد المستثمر على فهم الوكيل رقم #${params.agentNumber} خطوة بخطوة.
بيانات الوكيل المسجلة:
- الاسم: ${params.agentNameAr} (${params.agentNameEn})
- المجموعة: ${params.groupAr} · الباقة: ${params.tier}
- يقرأ من الأنطولوجيا: ${params.readsAr}
- يكتب: ${params.writesAr}
- الوظيفة: ${params.outputAr}

نتيجة التشغيل الحالية على سهم ${params.symbol} (${params.stockNameAr}):
- الملخص: ${params.summaryAr}
- الحكم المبدئي: ${params.verdictAr}
- المؤشرات المعتمدة:
${metricsSummary}
- خطوات الاستخدام المقترحة: ${params.stepsAr.join(' | ')}

${historySnippet ? `سياق المحادثة السابق:\n${historySnippet}\n` : ''}
سؤال المستثمر الحالي: "${params.question}"

المطلوب:
1. أجب بالعامية المصرية الدافئة والواضحة أو العربية البسيطة (4–6 جمل منظمة) توضح معنى الوكيل، وكيف يقرأ ويستخدم هذه الأرقام على ${params.symbol} الآن، ومتى يلتزم بالامتناع.
2. لا تخترع أي رقم خارج المؤشرات المعتمدة أعلاه، ولا تضمن أي ربح.
3. اقترح 3 أسئلة قصيرة تالية لمواصلة الفهم.`;

  const { text, lastErr } = await generateWithResilience(ai, (attempt) => ({
    model: attempt.model,
    contents: prompt,
    config: {
      systemInstruction: COMPLIANCE_SYSTEM_PROMPT,
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          answer_ar: { type: Type.STRING, description: 'Clear Egyptian Arabic walkthrough explaining the agent and its live output' },
          suggested_questions_ar: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: '3 concise Arabic follow-up questions about this agent',
          },
        },
        required: ['answer_ar', 'suggested_questions_ar'],
      },
      ...(attempt.useThinking ? { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } } : {}),
    },
  }));

  if (text) {
    try {
      const parsed = JSON.parse(text) as {
        answer_ar?: string;
        suggested_questions_ar?: string[];
      };
      if (parsed.answer_ar && parsed.answer_ar.trim().length > 10) {
        return {
          used_ai: true,
          answer_ar: parsed.answer_ar.trim(),
          suggested_questions_ar:
            Array.isArray(parsed.suggested_questions_ar) && parsed.suggested_questions_ar.length > 0
              ? parsed.suggested_questions_ar.slice(0, 3)
              : defaultSuggestions,
          disclaimer_ar: SHORT_DISCLAIMER_AR,
        };
      }
    } catch {
      // Fall through cleanly to structured fallback
    }
  }

  return {
    used_ai: false,
    answer_ar: deterministicAnswer,
    suggested_questions_ar: defaultSuggestions,
    disclaimer_ar: SHORT_DISCLAIMER_AR,
    ai_error: formatFriendlyAiError(lastErr),
  };
}
