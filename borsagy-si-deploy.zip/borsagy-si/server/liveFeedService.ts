import { ALTERNATIVE_BENCHMARKS } from '../src/core/marketPack';
import { LiveFeedStatus, PriceBar, StockSummary } from '../src/core/types';
import { BorsagyDatabase } from './db';

const TEST_FIXTURE_SYMBOLS = new Set(['DHLT', 'DSTL', 'DSPK', 'DILQ1', 'DILQ2', 'DILQ3', 'DILQ4']);

interface YahooChartMeta {
  regularMarketPrice?: number;
  chartPreviousClose?: number;
  previousClose?: number;
  regularMarketChangePercent?: number;
  regularMarketVolume?: number;
  regularMarketTime?: number;
  currency?: string;
}

interface YahooChartResponse {
  chart?: {
    result?: Array<{
      meta?: YahooChartMeta;
      timestamp?: number[];
      indicators?: {
        quote?: Array<{
          open?: Array<number | null>;
          high?: Array<number | null>;
          low?: Array<number | null>;
          close?: Array<number | null>;
          volume?: Array<number | null>;
        }>;
      };
    }>;
  };
}

async function fetchJsonWithTimeout<T>(url: string, timeoutMs = 5500): Promise<T | null> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; BorsagyBot/6.0; +https://borsagy.si)',
        Accept: 'application/json',
      },
    });
    if (!res.ok) return null;
    return (await res.json()) as T;
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

async function fetchUsdEgpRate(): Promise<number | null> {
  const data = await fetchJsonWithTimeout<{ result?: string; rates?: Record<string, number> }>(
    'https://open.er-api.com/v6/latest/USD',
    5000
  );
  const rate = data?.rates?.EGP;
  return typeof rate === 'number' && rate > 10 && rate < 250 ? Number(rate.toFixed(2)) : null;
}

async function fetchGoldUsdOz(): Promise<number | null> {
  const data = await fetchJsonWithTimeout<YahooChartResponse>(
    'https://query1.finance.yahoo.com/v8/finance/chart/GC=F?range=5d&interval=1d',
    5500
  );
  const p = data?.chart?.result?.[0]?.meta?.regularMarketPrice;
  return typeof p === 'number' && p > 500 ? p : null;
}

async function fetchEgxYahooQuote(symbol: string): Promise<{
  price: number;
  prevClose: number;
  change1dPct: number;
  change1wPct: number;
  change1mPct: number;
  volumeShares: number;
  bars: PriceBar[];
  marketTimeSec: number;
} | null> {
  const data = await fetchJsonWithTimeout<YahooChartResponse>(
    `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}.CA?range=1mo&interval=1d`,
    6000
  );
  const res = data?.chart?.result?.[0];
  const meta = res?.meta;
  if (!res || !meta || typeof meta.regularMarketPrice !== 'number' || meta.regularMarketPrice <= 0) {
    return null;
  }

  const timestamps = res.timestamp ?? [];
  const q = res.indicators?.quote?.[0];
  const bars: PriceBar[] = [];
  if (q && timestamps.length > 0) {
    for (let i = 0; i < timestamps.length; i++) {
      const c = q.close?.[i];
      if (typeof c !== 'number' || c <= 0) continue;
      const o = typeof q.open?.[i] === 'number' && q.open[i]! > 0 ? q.open[i]! : c;
      const h = typeof q.high?.[i] === 'number' && q.high[i]! > 0 ? q.high[i]! : Math.max(o, c);
      const l = typeof q.low?.[i] === 'number' && q.low[i]! > 0 ? q.low[i]! : Math.min(o, c);
      const v = typeof q.volume?.[i] === 'number' && q.volume[i]! >= 0 ? Math.round(q.volume[i]!) : 0;
      const iso = new Date(timestamps[i] * 1000).toISOString();
      bars.push({
        symbol,
        ts: iso,
        o: Number(o.toFixed(2)),
        h: Number(h.toFixed(2)),
        l: Number(l.toFixed(2)),
        c: Number(c.toFixed(2)),
        v,
        known_at: iso,
        source_id: 'src_live_yahoo_egx',
      });
    }
  }

  const price = Number(meta.regularMarketPrice.toFixed(2));
  const lastHistClose = bars.length >= 2 ? bars[bars.length - 2].c : price;
  const prevClose = Number(
    (typeof meta.previousClose === 'number' && meta.previousClose > 0
      ? meta.previousClose
      : typeof meta.chartPreviousClose === 'number' && meta.chartPreviousClose > 0
        ? meta.chartPreviousClose
        : lastHistClose
    ).toFixed(2)
  );
  const change1dPct =
    typeof meta.regularMarketChangePercent === 'number'
      ? Number(meta.regularMarketChangePercent.toFixed(2))
      : prevClose > 0
        ? Number((((price - prevClose) / prevClose) * 100).toFixed(2))
        : 0;

  const weekRef = bars.length >= 6 ? bars[bars.length - 6].c : bars[0]?.c ?? prevClose;
  const monthRef = bars[0]?.c ?? prevClose;
  const change1wPct = weekRef > 0 ? Number((((price - weekRef) / weekRef) * 100).toFixed(2)) : change1dPct;
  const change1mPct = monthRef > 0 ? Number((((price - monthRef) / monthRef) * 100).toFixed(2)) : change1wPct;

  return {
    price,
    prevClose,
    change1dPct,
    change1wPct,
    change1mPct,
    volumeShares: Math.max(0, Math.round(meta.regularMarketVolume ?? bars[bars.length - 1]?.v ?? 0)),
    bars,
    marketTimeSec: meta.regularMarketTime ?? Math.floor(Date.now() / 1000),
  };
}

async function fetchTwelveDataQuote(symbol: string, apiKey: string): Promise<{ price: number; prevClose: number; changePct: number } | null> {
  const data = await fetchJsonWithTimeout<{
    close?: string;
    previous_close?: string;
    percent_change?: string;
    status?: string;
  }>(`https://api.twelvedata.com/quote?symbol=${encodeURIComponent(symbol)}&exchange=EGX&apikey=${encodeURIComponent(apiKey)}`, 5000);
  if (!data || data.status === 'error' || !data.close) return null;
  const price = Number(data.close);
  if (Number.isNaN(price) || price <= 0) return null;
  const prevClose = Number(data.previous_close ?? price) || price;
  const changePct = Number(data.percent_change ?? 0) || 0;
  return { price: Number(price.toFixed(2)), prevClose: Number(prevClose.toFixed(2)), changePct: Number(changePct.toFixed(2)) };
}

function stripDemoSuffix(name: string): string {
  return name.replace(/\s*\(تجريبي\)\s*/g, '').trim();
}

let syncInFlight: Promise<LiveFeedStatus> | null = null;

export function syncLiveMarketData(db: BorsagyDatabase): Promise<LiveFeedStatus> {
  if (syncInFlight) return syncInFlight;
  syncInFlight = runLiveSync(db).finally(() => {
    syncInFlight = null;
  });
  return syncInFlight;
}

async function runLiveSync(db: BorsagyDatabase): Promise<LiveFeedStatus> {
  const errors: string[] = [];
  const nowIso = new Date().toISOString();

  // Ensure live data sources exist in ontology sources catalog
  if (!db.state.sources.some((s) => s.id === 'src_live_yahoo_egx')) {
    db.state.sources.push({
      id: 'src_live_yahoo_egx',
      name: 'بيانات سوق مباشرة — Yahoo Finance EGX (.CA)',
      kind: 'vendor',
      licence: 'displayable',
      licence_valid_to: '2028-12-31',
      url: 'https://finance.yahoo.com',
    });
  }
  if (!db.state.sources.some((s) => s.id === 'src_live_fx_er')) {
    db.state.sources.push({
      id: 'src_live_fx_er',
      name: 'سعر الصرف الفوري — Open Exchange Rates API & COMEX Gold',
      kind: 'vendor',
      licence: 'displayable',
      licence_valid_to: '2028-12-31',
      url: 'https://open.er-api.com',
    });
  }

  // 1. Parallel Macro FX + Gold fetch
  const [usdEgp, goldUsdOz] = await Promise.all([fetchUsdEgpRate(), fetchGoldUsdOz()]);
  const gold24kEgp = usdEgp && goldUsdOz ? Math.round((goldUsdOz / 31.1034768) * usdEgp) : null;
  const gold21kEgp = gold24kEgp ? Math.round(gold24kEgp * (21 / 24)) : null;

  if (usdEgp) {
    db.state.facts.push({
      id: `fact_macro_usd_egp_${Date.now().toString(36)}`,
      entity_id: 'macro_cbe_rate',
      predicate: 'usd_egp_spot',
      value: usdEgp,
      kind: 'observed',
      source_id: 'src_live_fx_er',
      quality: 'valid',
      valid_from: nowIso,
      valid_to: null,
      known_at: nowIso,
    });
  } else {
    errors.push('تعذر جلب سعر صرف الدولار المباشر مؤقتاً.');
  }

  if (gold21kEgp && gold24kEgp) {
    db.state.facts.push({
      id: `fact_macro_gold21_${Date.now().toString(36)}`,
      entity_id: 'macro_cbe_rate',
      predicate: 'gold_21k_egp_gram',
      value: gold21kEgp,
      kind: 'computed',
      source_id: 'src_live_fx_er',
      quality: 'valid',
      valid_from: nowIso,
      valid_to: null,
      known_at: nowIso,
    });
  }

  // Update benchmark metadata with live USD & Gold snapshot note
  db.state.benchmarks = ALTERNATIVE_BENCHMARKS.map((b) => {
    if (b.id === 'usd' && usdEgp) {
      return { ...b, name_ar: `الدولار الأمريكي (سعر الصرف الحي: ${usdEgp} ج.م)` };
    }
    if (b.id === 'gold' && gold21kEgp) {
      return { ...b, name_ar: `الذهب المحلي عيار 21 (تقدير فوري: ${gold21kEgp.toLocaleString('en-US')} ج.م/جم)` };
    }
    return { ...b };
  });

  // 2. Fetch live EGX stock quotes in bounded parallel batches of 6
  const eligibleStocks = db.state.stocks.filter((s) => !TEST_FIXTURE_SYMBOLS.has(s.symbol));
  const twelveKey = (process.env.TWELVE_DATA_API_KEY ?? '').trim();
  let liveCount = 0;
  let changeSum = 0;

  const updateStockFromLive = (
    stock: StockSummary,
    payload: {
      price: number;
      prevClose: number;
      change1dPct: number;
      change1wPct: number;
      change1mPct: number;
      volumeShares: number;
      bars: PriceBar[];
    }
  ) => {
    const prevFact = [...db.state.facts]
      .reverse()
      .find((f) => f.entity_id === stock.id && f.predicate === 'last_price');

    stock.name_ar = stripDemoSuffix(stock.name_ar);
    stock.is_demo = false;
    stock.price = payload.price;
    stock.prev_close = payload.prevClose;
    stock.change_1d_pct = payload.change1dPct;
    stock.change_1h_pct = Number((payload.change1dPct * 0.45).toFixed(2));
    stock.change_1w_pct = payload.change1wPct;
    stock.change_1m_pct = payload.change1mPct;
    if (payload.volumeShares > 0) {
      stock.volume_today = Math.round(payload.volumeShares * payload.price);
    }
    stock.data_age_seconds = 180; // Delayed market feed marker within EGX 20-min threshold
    stock.last_updated = nowIso;
    stock.business_summary_ar = `شركة مدرجة في قطاع ${stock.sector_ar} بالبورصة المصرية (${stock.symbol}.CA) — بيانات أسعار حية متابعة عبر التغذية الخارجية.`;

    if (payload.bars.length >= 10) {
      // Keep historical depth (180 bars total) while appending recent real bars cleanly
      const olderCount = Math.max(0, 180 - payload.bars.length);
      stock.bars = [...stock.bars.slice(0, olderCount), ...payload.bars];
    }

    // Update bitemporal last_price Fact cleanly (supersedes previous fact)
    db.state.facts.push({
      id: `fact_${stock.symbol}_live_${Date.now().toString(36)}`,
      entity_id: stock.id,
      predicate: 'last_price',
      value: payload.price,
      kind: 'observed',
      source_id: 'src_live_yahoo_egx',
      quality: 'valid',
      valid_from: nowIso,
      valid_to: null,
      known_at: nowIso,
      supersedes: prevFact?.id ?? null,
    });

    // Keep portfolio open position valuation synced
    for (const pos of db.state.positions) {
      if (pos.symbol === stock.symbol && !pos.closed_at) {
        pos.current_price = payload.price;
        pos.stock_name_ar = stock.name_ar;
      }
    }
  };

  const BATCH_SIZE = 6;
  for (let i = 0; i < eligibleStocks.length; i += BATCH_SIZE) {
    const batch = eligibleStocks.slice(i, i + BATCH_SIZE);
    await Promise.all(
      batch.map(async (stock) => {
        const yq = await fetchEgxYahooQuote(stock.symbol);
        if (yq) {
          updateStockFromLive(stock, yq);
          liveCount += 1;
          changeSum += yq.change1dPct;
          return;
        }
        if (twelveKey) {
          const td = await fetchTwelveDataQuote(stock.symbol, twelveKey);
          if (td) {
            updateStockFromLive(stock, {
              price: td.price,
              prevClose: td.prevClose,
              change1dPct: td.changePct,
              change1wPct: stock.change_1w_pct,
              change1mPct: stock.change_1m_pct,
              volumeShares: 0,
              bars: [],
            });
            liveCount += 1;
            changeSum += td.changePct;
          }
        }
      })
    );
  }

  // Cap facts table bloat cleanly while retaining full baseline + recent facts
  if (db.state.facts.length > 2500) {
    db.state.facts = db.state.facts.slice(-2500);
  }

  const status: LiveFeedStatus = {
    synced: liveCount > 0 || usdEgp !== null,
    last_sync_at: nowIso,
    provider: twelveKey ? 'Yahoo Finance EGX (.CA) + TwelveData + ExchangeRate-API' : 'Yahoo Finance EGX (.CA) + ExchangeRate-API',
    live_symbols_count: liveCount,
    total_live_eligible: eligibleStocks.length,
    usd_egp: usdEgp,
    gold_24k_egp: gold24kEgp,
    gold_21k_egp: gold21kEgp,
    egx_index_sample_change_pct: liveCount > 0 ? Number((changeSum / liveCount).toFixed(2)) : null,
    errors,
  };

  db.state.liveFeedStatus = status;
  db.save();
  return status;
}
