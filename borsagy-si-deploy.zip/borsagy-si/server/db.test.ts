import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import test from 'node:test';
import { BorsagyDatabase } from './db';

function makeTempDb(): { db: BorsagyDatabase; dir: string } {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'borsagy-db-test-'));
  const filePath = path.join(dir, 'store.json');
  return { db: new BorsagyDatabase(filePath), dir };
}

test('DELETE /api/me cascade removes trader, profile, positions, plans, trades, personal advices and edges', () => {
  const { db, dir } = makeTempDb();
  try {
    const targetId = 'trader_main';
    assert.ok(db.state.traders.some((t) => t.id === targetId));
    assert.ok(db.state.positions.some((p) => p.trader_id === targetId));
    assert.ok(db.state.plans.some((p) => p.trader_id === targetId));
    assert.ok(db.state.advices.some((a) => a.trader_id === targetId));

    const res = db.deleteTraderCascade(targetId);
    assert.equal(res.deleted, true);
    assert.ok(res.removedCounts.traders === 1);
    assert.ok(res.removedCounts.positions >= 1);
    assert.ok(res.removedCounts.advices >= 1);

    // Ensure zero remnants for targetId, while other traders remain intact
    assert.equal(db.state.traders.some((t) => t.id === targetId), false);
    assert.equal(db.state.riskProfiles.some((r) => r.trader_id === targetId), false);
    assert.equal(db.state.traderStates.some((s) => s.trader_id === targetId), false);
    assert.equal(db.state.positions.some((p) => p.trader_id === targetId), false);
    assert.equal(db.state.plans.some((p) => p.trader_id === targetId), false);
    assert.equal(db.state.trades.some((t) => t.trader_id === targetId), false);
    assert.equal(db.state.advices.some((a) => a.trader_id === targetId), false);
    assert.ok(db.state.traders.length >= 2);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test('Admin one-time scrypt bootstrap locks after claim and verifies Bearer token in memory', () => {
  const { db, dir } = makeTempDb();
  const prevEnv = process.env.ADMIN_PASSCODE;
  delete process.env.ADMIN_PASSCODE;

  try {
    const statusBefore = db.getAdminAuthStatus();
    assert.equal(statusBefore.bootstrapAllowed, true);

    const shortFail = db.bootstrapAdminPasscode('123');
    assert.equal(shortFail.ok, false);

    const claimed = db.bootstrapAdminPasscode('borsagy-admin-2026');
    assert.equal(claimed.ok, true);
    assert.ok(claimed.token);

    // Second bootstrap attempt must fail
    const secondClaim = db.bootstrapAdminPasscode('another-passcode-99');
    assert.equal(secondClaim.ok, false);

    // Verify valid and invalid bearer tokens
    assert.equal(db.verifyAdminToken(`Bearer ${claimed.token}`).ok, true);
    assert.equal(db.verifyAdminToken('Bearer invalidtoken').ok, false);

    // Verify scrypt login
    const badLogin = db.loginAdmin('wrong-passcode');
    assert.equal(badLogin.ok, false);

    const goodLogin = db.loginAdmin('borsagy-admin-2026');
    assert.equal(goodLogin.ok, true);
    assert.ok(goodLogin.token);
  } finally {
    if (prevEnv !== undefined) {
      process.env.ADMIN_PASSCODE = prevEnv;
    }
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test('SHA-256 seal chain is valid on initial seed and remains valid after sealing new advice', () => {
  const { db, dir } = makeTempDb();
  try {
    const initial = db.verifySealChain();
    assert.equal(initial.valid, true);
    assert.ok(initial.total >= 5);

    const prevSeal = db.getLastSealHash();
    const newest = db.state.advices[0];
    assert.equal(prevSeal, newest.seal_hash);

    db.recordAdvice({
      ...newest,
      id: 'adv_test_chain_next',
      sealed_at: new Date(Date.now() + 1000).toISOString(),
      prev_seal_hash: prevSeal,
      seal_hash: 'a'.repeat(64),
    });

    const after = db.verifySealChain();
    assert.equal(after.valid, true);
    assert.equal(after.total, initial.total + 1);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});
