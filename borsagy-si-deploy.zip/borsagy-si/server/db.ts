import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { ALL_84_AGENTS } from '../src/core/agentsCatalog';
import {
  calculateDisciplineScore,
  calculateNetRoundTripPnl,
  calculateOrderCosts,
  calculateTiltScore,
} from '../src/core/deterministicServices';
import { ALTERNATIVE_BENCHMARKS, INITIAL_CONFIG } from '../src/core/marketPack';
import { buildSeedDataset, SeedDataset } from '../src/core/seed';
import {
  Advice,
  AuditLogEntry,
  BillingCycle,
  BrokerFeeRow,
  BrokerInfo,
  Claim,
  Edge,
  Fact,
  HumanReviewItem,
  KillSwitches,
  LiveFeedStatus,
  Outcome,
  Plan,
  Position,
  RiskProfile,
  Source,
  StockSummary,
  SubscriptionTierId,
  Trade,
  Trader,
  TraderState,
  VersionedConfig,
} from '../src/core/types';
import { computeSealHash } from '../src/core/validators';

export interface PersistedStore {
  config: VersionedConfig;
  killSwitches: KillSwitches;
  sources: Source[];
  entities: SeedDataset['entities'];
  facts: Fact[];
  edges: Edge[];
  stocks: StockSummary[];
  traders: Trader[];
  riskProfiles: RiskProfile[];
  traderStates: TraderState[];
  positions: Position[];
  plans: Plan[];
  trades: Trade[];
  advices: Advice[];
  outcomes: Outcome[];
  calibrations: SeedDataset['calibrations'];
  brokers: BrokerInfo[];
  reviewQueue: HumanReviewItem[];
  auditLogs: AuditLogEntry[];
  academyLessons: SeedDataset['academyLessons'];
  glossary: SeedDataset['glossary'];
  agentsCatalog: SeedDataset['agentsCatalog'];
  benchmarks: Array<{ id: string; name_ar: string; annual_return_pct: number; risk_ar: string }>;
  liveFeedStatus: LiveFeedStatus;
  claimsLog: Claim[];
  adminPasscodeHash: string | null; // scrypt salt:hash stored after first-run claim when env var is absent
  panicEvents: Array<{ id: string; trader_id: string; at: string; action: 'cooled_off' | 'proceeded'; note_ar: string }>;
}

const DEFAULT_DATA_PATH = path.resolve(process.cwd(), 'data', 'borsagy-store.json');

interface AdminSession {
  token: string;
  actor: string;
  createdAt: number;
  expiresAt: number;
}

const SESSION_TTL_MS = 8 * 60 * 60 * 1000;

export function hashPasscodeScrypt(passcode: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(passcode, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

export function verifyPasscodeScrypt(passcode: string, stored: string): boolean {
  const parts = stored.split(':');
  if (parts.length !== 2) return false;
  const [salt, hashHex] = parts;
  if (!salt || !hashHex) return false;
  const expected = Buffer.from(hashHex, 'hex');
  const actual = crypto.scryptSync(passcode, salt, 64);
  if (expected.length !== actual.length) return false;
  return crypto.timingSafeEqual(expected, actual);
}

export class BorsagyDatabase {
  private storePath: string;
  public state: PersistedStore;
  private adminSessions = new Map<string, AdminSession>();

  constructor(storePath: string = DEFAULT_DATA_PATH) {
    this.storePath = storePath;
    this.state = this.loadOrSeed();
  }

  private loadOrSeed(): PersistedStore {
    const defaultLiveStatus: LiveFeedStatus = {
      synced: false,
      last_sync_at: null,
      provider: 'بيانات مرجعية — جاهز للمزامنة الحية',
      live_symbols_count: 0,
      total_live_eligible: 33,
      usd_egp: null,
      gold_24k_egp: null,
      gold_21k_egp: null,
      egx_index_sample_change_pct: null,
      errors: [],
    };

    try {
      if (fs.existsSync(this.storePath)) {
        const raw = fs.readFileSync(this.storePath, 'utf-8');
        const parsed = JSON.parse(raw) as PersistedStore;
        if (parsed && Array.isArray(parsed.stocks) && parsed.stocks.length > 0 && parsed.config) {
          // Reconcile older 14-agent stores cleanly to the full 84-agent ontology catalog
          const disabledSet = new Set(parsed.killSwitches?.disabled_agents ?? []);
          if (!Array.isArray(parsed.agentsCatalog) || parsed.agentsCatalog.length < ALL_84_AGENTS.length) {
            parsed.agentsCatalog = ALL_84_AGENTS.map((ag) => ({
              ...ag,
              enabled: !disabledSet.has(ag.id),
            }));
          }
          if (!Array.isArray(parsed.benchmarks) || parsed.benchmarks.length === 0) {
            parsed.benchmarks = ALTERNATIVE_BENCHMARKS.map((b) => ({ ...b }));
          }
          if (!parsed.liveFeedStatus) {
            parsed.liveFeedStatus = defaultLiveStatus;
          }
          return parsed;
        }
      }
    } catch {
      // Corrupt or unreadable file falls back cleanly to deterministic seed
    }
    const seed = buildSeedDataset();
    const initial: PersistedStore = {
      config: { ...INITIAL_CONFIG },
      killSwitches: {
        global_pause_advice: false,
        crisis_mode_manual: false,
        disabled_agents: [],
        blocked_symbols: ['DHLT'],
      },
      sources: seed.sources,
      entities: seed.entities,
      facts: seed.facts,
      edges: seed.edges,
      stocks: seed.stocks,
      traders: seed.traders,
      riskProfiles: seed.riskProfiles,
      traderStates: seed.traderStates,
      positions: seed.positions,
      plans: seed.plans,
      trades: seed.trades,
      advices: seed.advices,
      outcomes: seed.outcomes,
      calibrations: seed.calibrations,
      brokers: seed.brokers,
      reviewQueue: seed.reviewQueue,
      auditLogs: seed.auditLogs,
      academyLessons: seed.academyLessons,
      glossary: seed.glossary,
      agentsCatalog: seed.agentsCatalog,
      benchmarks: ALTERNATIVE_BENCHMARKS.map((b) => ({ ...b })),
      liveFeedStatus: defaultLiveStatus,
      claimsLog: [],
      adminPasscodeHash: null,
      panicEvents: [],
    };
    this.saveState(initial);
    return initial;
  }

  public save(): void {
    this.saveState(this.state);
  }

  private saveState(data: PersistedStore): void {
    const dir = path.dirname(this.storePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(this.storePath, JSON.stringify(data, null, 2), 'utf-8');
  }

  public appendAudit(actor: string, action: string, subject: string, detail: Record<string, unknown> = {}): void {
    const nextId = (this.state.auditLogs[0]?.id ?? 0) + 1;
    this.state.auditLogs.unshift({
      id: nextId,
      actor,
      action,
      subject,
      at: new Date().toISOString(),
      detail,
    });
    if (this.state.auditLogs.length > 500) {
      this.state.auditLogs = this.state.auditLogs.slice(0, 500);
    }
    this.save();
  }

  // --- Admin Auth ---
  public getAdminAuthStatus(): { configured: boolean; viaEnv: boolean; bootstrapAllowed: boolean } {
    const envCode = (process.env.ADMIN_PASSCODE ?? '').trim();
    if (envCode.length > 0) {
      return { configured: true, viaEnv: true, bootstrapAllowed: false };
    }
    const hasHash = Boolean(this.state.adminPasscodeHash);
    return { configured: hasHash, viaEnv: false, bootstrapAllowed: !hasHash };
  }

  public bootstrapAdminPasscode(passcode: string): { ok: boolean; token?: string; error?: string } {
    const envCode = (process.env.ADMIN_PASSCODE ?? '').trim();
    if (envCode.length > 0 || this.state.adminPasscodeHash) {
      return { ok: false, error: 'تم إعداد رمز المشرف بالفعل. لا يمكن إعادة التهيئة.' };
    }
    const clean = passcode.trim();
    if (clean.length < 8) {
      return { ok: false, error: 'يجب ألا يقل رمز المشرف عن 8 أحرف أو أرقام.' };
    }
    this.state.adminPasscodeHash = hashPasscodeScrypt(clean);
    const token = this.issueAdminToken('admin_owner');
    this.appendAudit('admin_owner', 'admin_bootstrap', 'AdminAuth', { method: 'first_run_claim' });
    return { ok: true, token };
  }

  public loginAdmin(passcode: string): { ok: boolean; token?: string; error?: string } {
    const clean = passcode.trim();
    const envCode = (process.env.ADMIN_PASSCODE ?? '').trim();
    if (envCode.length > 0) {
      const a = Buffer.from(clean);
      const b = Buffer.from(envCode);
      if (a.length === b.length && crypto.timingSafeEqual(a, b)) {
        const token = this.issueAdminToken('admin_env');
        this.appendAudit('admin_env', 'admin_login', 'AdminAuth', { via: 'env' });
        return { ok: true, token };
      }
      return { ok: false, error: 'رمز الدخول غير صحيح.' };
    }

    if (!this.state.adminPasscodeHash) {
      return { ok: false, error: 'لم يتم تعيين رمز المشرف بعد. استخدم التهيئة الأولية.' };
    }
    if (!verifyPasscodeScrypt(clean, this.state.adminPasscodeHash)) {
      return { ok: false, error: 'رمز الدخول غير صحيح.' };
    }
    const token = this.issueAdminToken('admin_owner');
    this.appendAudit('admin_owner', 'admin_login', 'AdminAuth', { via: 'scrypt' });
    return { ok: true, token };
  }

  private issueAdminToken(actor: string): string {
    const token = crypto.randomBytes(32).toString('hex');
    const now = Date.now();
    this.adminSessions.set(token, {
      token,
      actor,
      createdAt: now,
      expiresAt: now + SESSION_TTL_MS,
    });
    return token;
  }

  public verifyAdminToken(authHeader: string | undefined): { ok: boolean; actor?: string } {
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return { ok: false };
    }
    const token = authHeader.slice(7).trim();
    const sess = this.adminSessions.get(token);
    if (!sess) return { ok: false };
    if (Date.now() > sess.expiresAt) {
      this.adminSessions.delete(token);
      return { ok: false };
    }
    return { ok: true, actor: sess.actor };
  }

  // --- Trader / Risk / Portfolio Operations ---
  public getTraderBundle(traderId: string) {
    const trader = this.state.traders.find((t) => t.id === traderId) ?? this.state.traders[0];
    if (!trader) return null;
    const tid = trader.id;
    const profile = this.state.riskProfiles.find((r) => r.trader_id === tid);
    const traderState = this.state.traderStates.find((s) => s.trader_id === tid);
    const positions = this.state.positions.filter((p) => p.trader_id === tid && !p.closed_at);
    const plans = this.state.plans.filter((p) => p.trader_id === tid);
    const trades = this.state.trades.filter((t) => t.trader_id === tid);
    const advices = this.state.advices.filter((a) => a.trader_id === tid);
    return { trader, profile, traderState, positions, plans, trades, advices };
  }

  public getLastSealHash(): string {
    return this.state.advices[0]?.seal_hash ?? 'GENESIS';
  }

  public appendFact(input: {
    entity_id: string;
    predicate: string;
    value: Fact['value'];
    kind: Fact['kind'];
    source_id: string;
    quality: Fact['quality'];
    valid_from?: string;
    valid_to?: string | null;
    supersedes?: string | null;
  }): Fact {
    const now = new Date().toISOString();
    const fact: Fact = {
      id: `fact_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`,
      entity_id: input.entity_id,
      predicate: input.predicate,
      value: input.value,
      kind: input.kind,
      source_id: input.source_id,
      quality: input.quality,
      valid_from: input.valid_from ?? now,
      valid_to: input.valid_to ?? null,
      known_at: now,
      supersedes: input.supersedes ?? null,
    };
    this.state.facts.push(fact);
    this.save();
    return fact;
  }

  public recordAdvice(advice: Advice): void {
    this.state.advices.unshift(advice);
    if (advice.claims.length > 0) {
      this.state.claimsLog.unshift(...advice.claims);
    }
    this.save();
  }

  public createPlanAndOptionalPosition(input: {
    trader_id: string;
    symbol: string;
    reason: string;
    entry: number;
    size_pct: number;
    stop: number;
    targets: number[];
    worst_case: string;
    mood: TraderState['mood'];
    advice_id?: string;
    openPaperFill?: boolean;
  }): { plan: Plan; position?: Position } {
    const plan: Plan = {
      id: `pln_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 5)}`,
      trader_id: input.trader_id,
      symbol: input.symbol,
      reason: input.reason,
      entry: input.entry,
      size_pct: input.size_pct,
      stop: input.stop,
      targets: input.targets,
      worst_case: input.worst_case,
      mood: input.mood,
      signed_at: new Date().toISOString(),
      advice_id: input.advice_id,
    };
    this.state.plans.unshift(plan);

    if (input.advice_id) {
      const adv = this.state.advices.find((a) => a.id === input.advice_id);
      if (adv) adv.status = 'approved';
    }

    let position: Position | undefined;
    if (input.openPaperFill) {
      const stock = this.state.stocks.find((s) => s.symbol === input.symbol);
      const profile = this.state.riskProfiles.find((p) => p.trader_id === input.trader_id);
      const portfolioEgp = profile?.portfolio_size_egp ?? 100_000;
      const allocEgp = (portfolioEgp * input.size_pct) / 100;
      const qty = Math.max(1, Math.floor(allocEgp / Math.max(input.entry, 0.01)));
      if (stock) {
        position = {
          id: `pos_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 5)}`,
          trader_id: input.trader_id,
          symbol: stock.symbol,
          stock_name_ar: stock.name_ar,
          sector_id: stock.sector_id,
          owner_group_id: stock.owner_group_id,
          qty,
          avg_price: input.entry,
          current_price: stock.price,
          opened_at: new Date().toISOString(),
          closed_at: null,
          plan_id: plan.id,
        };
        this.state.positions.unshift(position);
        this.state.edges.push({
          id: `edg_hold_${position.id}`,
          src: `Trader:${input.trader_id}`,
          rel: 'holds',
          dst: stock.id,
          props: { qty, avg_price: input.entry },
          valid_from: position.opened_at,
          valid_to: null,
          known_at: position.opened_at,
          evidence: [],
        });
      }
    }

    this.save();
    return { plan, position };
  }

  public closeTrade(input: {
    trader_id: string;
    position_id?: string;
    symbol: string;
    exit_price: number;
    deviation_tags: Trade['deviation_tags'];
    cause: Trade['cause'];
    journal_completed: boolean;
  }): { trade: Trade; traderState: TraderState } | null {
    const traderState = this.state.traderStates.find((s) => s.trader_id === input.trader_id);
    if (!traderState) return null;

    const pos = input.position_id
      ? this.state.positions.find((p) => p.id === input.position_id && p.trader_id === input.trader_id)
      : this.state.positions.find((p) => p.symbol === input.symbol && p.trader_id === input.trader_id && !p.closed_at);

    const entryPrice = pos?.avg_price ?? input.exit_price * 0.98;
    const qty = pos?.qty ?? 100;
    const pnl = calculateNetRoundTripPnl(qty, entryPrice, input.exit_price);

    const hasRuleBreak = input.deviation_tags.some((t) => t !== 'none');
    const plan = pos?.plan_id ? this.state.plans.find((p) => p.id === pos.plan_id) : undefined;
    let ruleBreakCostEgp = 0;
    if (hasRuleBreak && plan) {
      const plannedBestFloor = calculateNetRoundTripPnl(qty, entryPrice, plan.stop).netPnlEgp;
      if (pnl.netPnlEgp < plannedBestFloor) {
        ruleBreakCostEgp = Math.round(plannedBestFloor - pnl.netPnlEgp);
      } else if (input.deviation_tags.includes('early_exit') && plan.targets[0]) {
        const plannedTargetPnl = calculateNetRoundTripPnl(qty, entryPrice, plan.targets[0]).netPnlEgp;
        ruleBreakCostEgp = Math.max(0, Math.round((plannedTargetPnl - pnl.netPnlEgp) * 0.5));
      }
    } else if (hasRuleBreak) {
      ruleBreakCostEgp = pnl.netPnlEgp < 0 ? Math.round(Math.abs(pnl.netPnlEgp) * 0.4) : 180;
    }

    const now = new Date().toISOString();
    if (pos) {
      pos.closed_at = now;
    }

    const trade: Trade = {
      id: `trd_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 5)}`,
      trader_id: input.trader_id,
      plan_id: pos?.plan_id ?? null,
      advice_id: plan?.advice_id ?? null,
      symbol: input.symbol,
      side: 'sell',
      qty,
      entry_price: entryPrice,
      price: input.exit_price,
      fees_egp: pnl.totalFeesEgp,
      net_pnl_egp: pnl.netPnlEgp,
      net_return_pct: pnl.netReturnPct,
      rule_break_cost_egp: ruleBreakCostEgp,
      executed_at: now,
      closed_at: now,
      cause: input.cause,
      deviation_tags: input.deviation_tags.length > 0 ? input.deviation_tags : ['none'],
      stop_adhered: !input.deviation_tags.includes('no_stop'),
      plan_adhered: !hasRuleBreak,
      size_adhered: !input.deviation_tags.includes('oversize'),
      journal_completed: input.journal_completed,
    };

    this.state.trades.unshift(trade);
    const traderTrades = this.state.trades.filter((t) => t.trader_id === input.trader_id);
    const discScore = calculateDisciplineScore(traderTrades);
    traderState.discipline_score = discScore;
    traderState.upgrade_eligible =
      discScore >= this.state.config.discipline_upgrade_threshold &&
      traderTrades.length >= this.state.config.discipline_min_trades;
    traderState.tilt_score = calculateTiltScore(traderTrades, traderState.mood, plan ?? null, Date.now());
    if (pnl.netPnlEgp < 0) {
      traderState.loss_streak += 1;
      traderState.day_pnl_pct = Number((traderState.day_pnl_pct + pnl.netReturnPct * 0.25).toFixed(2));
      traderState.week_pnl_pct = Number((traderState.week_pnl_pct + pnl.netReturnPct * 0.25).toFixed(2));
    } else {
      traderState.loss_streak = 0;
    }

    if (plan?.advice_id) {
      this.state.outcomes.unshift({
        advice_id: plan.advice_id,
        resolved_at: now,
        symbol: input.symbol,
        kind: 'plan',
        result: pnl.netPnlEgp > 0 ? 'win' : pnl.netPnlEgp < 0 ? 'loss' : 'flat',
        net_return_pct: pnl.netReturnPct,
        cause: input.cause ?? 'execution',
        predicted_confidence: 0.72,
      });
    }

    this.save();
    return { trade, traderState };
  }

  /**
   * Full User Data Deletion Cascade (Charter Pledge #10 & Build Spec Section 9)
   * Deletes trader, risk_profile, trader_state, positions, plans, personal trades,
   * personal advices & linked outcomes, personal edges/claims, and panic events.
   * Rebuilds anonymized global metrics without preserving any PII.
   */
  public deleteTraderCascade(traderId: string): {
    deleted: boolean;
    removedCounts: {
      traders: number;
      riskProfiles: number;
      traderStates: number;
      positions: number;
      plans: number;
      trades: number;
      advices: number;
      outcomes: number;
      edges: number;
      claims: number;
    };
  } {
    const exists = this.state.traders.some((t) => t.id === traderId);
    if (!exists) {
      return {
        deleted: false,
        removedCounts: {
          traders: 0,
          riskProfiles: 0,
          traderStates: 0,
          positions: 0,
          plans: 0,
          trades: 0,
          advices: 0,
          outcomes: 0,
          edges: 0,
          claims: 0,
        },
      };
    }

    const traderAdviceIds = new Set(
      this.state.advices.filter((a) => a.trader_id === traderId).map((a) => a.id)
    );
    const traderClaimIds = new Set(
      this.state.advices.filter((a) => a.trader_id === traderId).flatMap((a) => a.claim_ids)
    );

    const before = {
      traders: this.state.traders.length,
      riskProfiles: this.state.riskProfiles.length,
      traderStates: this.state.traderStates.length,
      positions: this.state.positions.length,
      plans: this.state.plans.length,
      trades: this.state.trades.length,
      advices: this.state.advices.length,
      outcomes: this.state.outcomes.length,
      edges: this.state.edges.length,
      claims: this.state.claimsLog.length,
    };

    this.state.traders = this.state.traders.filter((t) => t.id !== traderId);
    this.state.riskProfiles = this.state.riskProfiles.filter((r) => r.trader_id !== traderId);
    this.state.traderStates = this.state.traderStates.filter((s) => s.trader_id !== traderId);
    this.state.positions = this.state.positions.filter((p) => p.trader_id !== traderId);
    this.state.plans = this.state.plans.filter((p) => p.trader_id !== traderId);
    this.state.trades = this.state.trades.filter((t) => t.trader_id !== traderId);
    this.state.advices = this.state.advices.filter((a) => a.trader_id !== traderId);
    this.state.outcomes = this.state.outcomes.filter((o) => !traderAdviceIds.has(o.advice_id));
    this.state.edges = this.state.edges.filter(
      (e) => e.src !== `Trader:${traderId}` && e.dst !== `Trader:${traderId}`
    );
    this.state.claimsLog = this.state.claimsLog.filter((c) => !traderClaimIds.has(c.id));
    this.state.panicEvents = this.state.panicEvents.filter((pe) => pe.trader_id !== traderId);

    const removedCounts = {
      traders: before.traders - this.state.traders.length,
      riskProfiles: before.riskProfiles - this.state.riskProfiles.length,
      traderStates: before.traderStates - this.state.traderStates.length,
      positions: before.positions - this.state.positions.length,
      plans: before.plans - this.state.plans.length,
      trades: before.trades - this.state.trades.length,
      advices: before.advices - this.state.advices.length,
      outcomes: before.outcomes - this.state.outcomes.length,
      edges: before.edges - this.state.edges.length,
      claims: before.claims - this.state.claimsLog.length,
    };

    this.appendAudit('privacy_cascade', 'delete_trader_cascade', `Trader:${traderId}`, removedCounts);
    return { deleted: true, removedCounts };
  }

  public updateBrokerFee(
    brokerId: string,
    feeRowId: string,
    patch: Partial<Pick<BrokerFeeRow, 'value' | 'status' | 'conditions_ar' | 'source_url' | 'source_kind'>>,
    actor: string
  ): BrokerInfo | null {
    const broker = this.state.brokers.find((b) => b.id === brokerId);
    if (!broker) return null;
    const row = broker.fees.find((f) => f.id === feeRowId);
    if (!row) return null;
    if (patch.value !== undefined) row.value = patch.value;
    if (patch.status) row.status = patch.status;
    if (patch.conditions_ar !== undefined) row.conditions_ar = patch.conditions_ar;
    if (patch.source_url !== undefined) row.source_url = patch.source_url;
    if (patch.source_kind) row.source_kind = patch.source_kind;
    row.verified_on = new Date().toISOString().slice(0, 10);
    this.appendAudit(actor, 'verify_broker_fee', `${brokerId}:${feeRowId}`, {
      status: row.status,
      value: row.value,
    });
    return broker;
  }

  public verifySealChain(): { valid: boolean; total: number; brokenIds: string[] } {
    // advices are stored newest-first; sort chronologically oldest -> newest
    const ordered = [...this.state.advices]
      .reverse()
      .sort((a, b) => Date.parse(a.sealed_at) - Date.parse(b.sealed_at));
    const brokenIds: string[] = [];
    for (let i = 0; i < ordered.length; i++) {
      const adv = ordered[i];
      if (!adv.seal_hash || adv.seal_hash.length !== 64) {
        brokenIds.push(adv.id);
        continue;
      }
      if (i > 0 && adv.prev_seal_hash !== ordered[i - 1].seal_hash) {
        brokenIds.push(adv.id);
      }
    }
    return { valid: brokenIds.length === 0, total: ordered.length, brokenIds };
  }

  public computeOrderCostsSummary(price: number, qty: number, commissionPct?: number, minFeeEgp?: number) {
    const res = calculateOrderCosts('buy', qty, price, commissionPct, minFeeEgp);
    return { ...res, total_cost_egp: res.totalFeesEgp };
  }

  public updateTraderSubscription(
    traderId: string,
    tier: SubscriptionTierId,
    billingCycle: BillingCycle
  ): Trader | null {
    const trader = this.state.traders.find((t) => t.id === traderId);
    if (!trader) return null;
    trader.subscription_tier = tier;
    trader.billing_cycle = billingCycle;
    this.appendAudit(traderId, 'subscription_tier_selected', `Trader:${traderId}`, {
      tier,
      billing_cycle: billingCycle,
    });
    return trader;
  }
}

let singletonDb: BorsagyDatabase | null = null;
export function getDb(): BorsagyDatabase {
  if (!singletonDb) {
    singletonDb = new BorsagyDatabase();
  }
  return singletonDb;
}
