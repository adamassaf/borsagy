import dotenv from 'dotenv';
import express, { NextFunction, Request, Response } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { createServer as createViteServer } from 'vite';
import {
  AGENT_GROUPS,
  executeAgentAnalysis,
  isAgentUnlockedForTier,
  SUBSCRIPTION_PLANS,
} from './src/core/agentsCatalog';
import {
  calculateFearGreedIndex,
  calculatePortfolioRiskMetrics,
  calculateShariaAndPurification,
  calculateStockQualityScore,
  calculateTrapScore,
  checkFraudMessage,
  runPointInTimeBacktest,
} from './src/core/deterministicServices';
import { EGX_MARKET_PACK, PUBLIC_SAFETY_CHARTER_10, SHORT_DISCLAIMER_AR } from './src/core/marketPack';
import { getWhyChain, runAdvicePipeline } from './src/core/pipeline';
import { ActiveMode, BillingCycle, Position, Source, SubscriptionTierId, TraderMode } from './src/core/types';
import { checkComplianceCopy, queryFactsAsOf } from './src/core/validators';
import { getDb } from './server/db';
import { buildRepoDeployZip, BUNDLE_FILENAME } from './server/exportBundle';
import {
  askAgentCopilotWithGemini,
  composeCompanionWithGemini,
  explainTermWithGemini,
  extractDisclosureEvents,
} from './server/geminiService';
import { syncLiveMarketData } from './server/liveFeedService';

dotenv.config();

const PORT = Number(process.env.PORT) || 3000;
const app = express();
app.set('trust proxy', 1);
app.use(express.json({ limit: '2mb' }));

// CORS & security headers configured for Namecheap / borsagy.si reverse proxy
const allowedOrigins = new Set(
  [
    'https://borsagy.si',
    'https://www.borsagy.si',
    'http://localhost:3000',
    process.env.APP_URL,
    ...(process.env.CORS_ALLOWED_ORIGINS ?? '').split(','),
  ]
    .map((s) => (s ?? '').trim())
    .filter(Boolean)
);

app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin && allowedOrigins.has(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
  }
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type,Authorization,x-trader-id');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  if (req.method === 'OPTIONS') {
    res.status(204).end();
    return;
  }
  next();
});

function getTraderIdFromReq(req: Request): string {
  const q = typeof req.query.trader_id === 'string' ? req.query.trader_id.trim() : '';
  const h = typeof req.headers['x-trader-id'] === 'string' ? req.headers['x-trader-id'].trim() : '';
  const b = typeof req.body?.trader_id === 'string' ? req.body.trader_id.trim() : '';
  return b || q || h || 'trader_main';
}

function requireAdminAuth(req: Request, res: Response, next: NextFunction): void {
  const db = getDb();
  const check = db.verifyAdminToken(req.headers.authorization);
  if (!check.ok) {
    res.status(401).json({ error: 'مطلوب تسجيل دخول المشرف بصلاحية سارية.' });
    return;
  }
  (req as Request & { adminActor?: string }).adminActor = check.actor;
  next();
}

// --- Core System Metadata & Personas ---
app.get('/api/health', (_req, res) => {
  const db = getDb();
  res.json({
    ok: true,
    domain: 'borsagy.si',
    market_pack: EGX_MARKET_PACK,
    config_version: db.state.config.version,
    licence_path: db.state.config.licence_path,
    total_agents: db.state.agentsCatalog.length,
    live_feed_status: db.state.liveFeedStatus,
    kill_switches: db.state.killSwitches,
  });
});

app.get('/api/personas', (_req, res) => {
  const db = getDb();
  const list = db.state.traders.map((t) => {
    const profile = db.state.riskProfiles.find((p) => p.trader_id === t.id);
    const state = db.state.traderStates.find((s) => s.trader_id === t.id);
    return { trader: t, profile, traderState: state };
  });
  res.json({ personas: list });
});

// --- All 84 Agents & Subscription Plans API ---
app.get('/api/agents', (req, res) => {
  const db = getDb();
  const traderId = getTraderIdFromReq(req);
  const bundle = db.getTraderBundle(traderId);
  const activeTier: SubscriptionTierId = bundle?.trader.subscription_tier ?? 'free';

  const groupFilter = String(req.query.group ?? 'all');
  const tierFilter = String(req.query.tier ?? 'all');
  const q = String(req.query.q ?? '').trim().toLowerCase();

  const items = db.state.agentsCatalog
    .filter((ag) => (groupFilter === 'all' ? true : ag.group_key === groupFilter))
    .filter((ag) => (tierFilter === 'all' ? true : ag.tier === tierFilter))
    .filter(
      (ag) =>
        !q ||
        ag.name_ar.toLowerCase().includes(q) ||
        ag.name_en.toLowerCase().includes(q) ||
        ag.output_ar.toLowerCase().includes(q) ||
        String(ag.number) === q
    )
    .map((ag) => ({
      ...ag,
      unlocked: isAgentUnlockedForTier(ag.tier, activeTier),
    }));

  res.json({
    total_agents: db.state.agentsCatalog.length,
    filtered_count: items.length,
    active_tier: activeTier,
    groups: AGENT_GROUPS,
    agents: items,
    disclaimer_ar: SHORT_DISCLAIMER_AR,
  });
});

app.post('/api/agents/:id/run', (req, res) => {
  const db = getDb();
  const traderId = getTraderIdFromReq(req);
  const bundle = db.getTraderBundle(traderId);
  const rawId = req.params.id;
  const agent = db.state.agentsCatalog.find((a) => a.id === rawId || String(a.number) === rawId);
  if (!agent) {
    res.status(404).json({ error: 'الوكيل المطلوب غير موجود في الكتالوج.' });
    return;
  }
  if (!agent.enabled) {
    res.status(403).json({ error: `تم تعطيل الوكيل (#${agent.number} ${agent.name_ar}) مؤقتاً من غرفة الحوكمة.` });
    return;
  }
  const symbol = String(req.body?.symbol ?? 'COMI').toUpperCase();
  const stock = db.state.stocks.find((s) => s.symbol === symbol) ?? db.state.stocks[0];
  const result = executeAgentAnalysis({
    agent,
    stock,
    facts: db.state.facts,
    config: db.state.config,
    profile: bundle?.profile,
    traderState: bundle?.traderState,
    as_of: new Date().toISOString(),
  });
  res.json(result);
});

app.post('/api/agents/:id/copilot', async (req, res) => {
  const db = getDb();
  const traderId = getTraderIdFromReq(req);
  const bundle = db.getTraderBundle(traderId);
  const rawId = req.params.id;
  const agent = db.state.agentsCatalog.find((a) => a.id === rawId || String(a.number) === rawId);
  if (!agent) {
    res.status(404).json({ error: 'الوكيل المطلوب غير موجود في الكتالوج.' });
    return;
  }
  const symbol = String(req.body?.symbol ?? 'COMI').toUpperCase();
  const stock = db.state.stocks.find((s) => s.symbol === symbol) ?? db.state.stocks[0];
  const question =
    typeof req.body?.question === 'string' && req.body.question.trim().length > 0
      ? req.body.question.trim()
      : `اشرح لي الوكيل #${agent.number} (${agent.name_ar}) وكيف أستخدمه عملياً على سهم ${stock.symbol}؟`;

  const execution = executeAgentAnalysis({
    agent,
    stock,
    facts: db.state.facts,
    config: db.state.config,
    profile: bundle?.profile,
    traderState: bundle?.traderState,
    as_of: new Date().toISOString(),
  });

  const history = Array.isArray(req.body?.history)
    ? req.body.history
        .filter((h: unknown): h is { role: 'user' | 'assistant'; text: string } => {
          return (
            Boolean(h) &&
            typeof h === 'object' &&
            ((h as { role?: string }).role === 'user' || (h as { role?: string }).role === 'assistant') &&
            typeof (h as { text?: unknown }).text === 'string'
          );
        })
        .slice(-6)
    : [];

  const copilot = await askAgentCopilotWithGemini({
    question,
    symbol: stock.symbol,
    stockNameAr: stock.name_ar,
    agentNumber: agent.number,
    agentNameAr: agent.name_ar,
    agentNameEn: agent.name_en,
    groupAr: agent.group_ar,
    tier: agent.tier,
    readsAr: agent.reads_ar,
    writesAr: agent.writes_ar,
    outputAr: agent.output_ar,
    summaryAr: execution.summary_ar,
    verdictAr: execution.verdict_ar,
    metrics: execution.metrics,
    stepsAr: execution.usage_guide.steps_ar,
    cautionAr: execution.usage_guide.caution_ar,
    history,
  });

  res.json({
    agent,
    symbol: stock.symbol,
    execution,
    ...copilot,
  });
});

app.get('/api/subscriptions', (req, res) => {
  const db = getDb();
  const traderId = getTraderIdFromReq(req);
  const bundle = db.getTraderBundle(traderId);
  res.json({
    plans: SUBSCRIPTION_PLANS,
    active_tier: bundle?.trader.subscription_tier ?? 'free',
    billing_cycle: bundle?.trader.billing_cycle ?? 'monthly',
    agent_counts_by_tier: {
      free: db.state.agentsCatalog.filter((a) => isAgentUnlockedForTier(a.tier, 'free')).length,
      plus: db.state.agentsCatalog.filter((a) => isAgentUnlockedForTier(a.tier, 'plus')).length,
      pro: db.state.agentsCatalog.filter((a) => isAgentUnlockedForTier(a.tier, 'pro')).length,
      b2b: db.state.agentsCatalog.length,
    },
    disclaimer_ar: SHORT_DISCLAIMER_AR,
  });
});

app.post('/api/subscription/select', (req, res) => {
  const db = getDb();
  const traderId = getTraderIdFromReq(req);
  const tier = String(req.body?.tier ?? 'free') as SubscriptionTierId;
  const billingCycle = (req.body?.billing_cycle === 'annual' ? 'annual' : 'monthly') as BillingCycle;
  if (!['free', 'plus', 'pro', 'b2b'].includes(tier)) {
    res.status(400).json({ error: 'باقة الاشتراك المختارة غير صالحة.' });
    return;
  }
  const updated = db.updateTraderSubscription(traderId, tier, billingCycle);
  if (!updated) {
    res.status(404).json({ error: 'حساب المستثمر غير موجود.' });
    return;
  }
  res.json({
    ok: true,
    trader: updated,
    active_tier: updated.subscription_tier,
    billing_cycle: updated.billing_cycle,
    unlocked_agents_count: db.state.agentsCatalog.filter((a) => isAgentUnlockedForTier(a.tier, tier)).length,
  });
});

// --- Live Market Feed Endpoints ---
app.get('/api/market/live-status', (_req, res) => {
  const db = getDb();
  res.json(db.state.liveFeedStatus);
});

app.post('/api/market/refresh', async (_req, res) => {
  const db = getDb();
  const status = await syncLiveMarketData(db);
  res.json({ ok: status.synced, live_feed_status: status });
});

// --- GitHub / Namecheap Deployable ZIP Bundle Download ---
app.get('/api/export-repo.zip', (_req, res) => {
  try {
    const built = buildRepoDeployZip();
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Cache-Control', 'no-store');
    res.download(built.path, BUNDLE_FILENAME);
  } catch (e) {
    res.status(500).json({
      error: e instanceof Error ? e.message : 'تعذر تجهيز حزمة الرفع المضغوطة.',
    });
  }
});

// --- Section 9: POST /api/onboarding ---
app.post('/api/onboarding', (req, res) => {
  const db = getDb();
  const body = req.body ?? {};
  const traderId = getTraderIdFromReq(req);

  const experience = body.experience ?? 'beginner';
  const portfolioSize = Math.max(1000, Number(body.portfolio_size_egp ?? 50_000));
  const maxAffordableLoss = Math.max(500, Number(body.max_affordable_loss_egp ?? portfolioSize * 0.1));
  const dailyLossInput = Number(body.daily_loss_limit_pct ?? 2.0);
  const weeklyLossInput = Number(body.weekly_loss_limit_pct ?? 5.0);

  // Enforce beginner loss caps from versioned config
  const dailyCap =
    experience === 'beginner'
      ? Math.min(dailyLossInput, db.state.config.daily_loss_cap_beginner_pct)
      : Math.min(dailyLossInput, 5.0);
  const weeklyCap =
    experience === 'beginner'
      ? Math.min(weeklyLossInput, db.state.config.weekly_loss_cap_beginner_pct)
      : Math.min(weeklyLossInput, 12.0);

  const singleCap =
    experience === 'beginner'
      ? db.state.config.single_stock_cap_beginner_pct
      : experience === 'advanced'
        ? db.state.config.single_stock_cap_advanced_pct
        : db.state.config.single_stock_cap_standard_pct;

  const sectorCap =
    experience === 'beginner'
      ? db.state.config.sector_cap_beginner_pct
      : experience === 'advanced'
        ? db.state.config.sector_cap_advanced_pct
        : db.state.config.sector_cap_standard_pct;

  let trader = db.state.traders.find((t) => t.id === traderId);
  if (!trader) {
    trader = {
      id: traderId,
      handle: body.handle || 'مستثمر_جديد',
      anonymous: body.anonymous ?? true,
      created_at: new Date().toISOString(),
      dialect: body.dialect || 'egyptian',
      numerals: body.numerals || 'western',
      low_bandwidth: Boolean(body.low_bandwidth),
      quiet_hours: { start: '23:00', end: '08:00' },
      daily_alert_budget: db.state.config.notification_budget_per_day,
      alerts_sent_today: 0,
      trusted_observer: null,
    };
    db.state.traders.push(trader);
  }

  let profile = db.state.riskProfiles.find((p) => p.trader_id === traderId);
  const nextProfile = {
    trader_id: traderId,
    experience,
    goal: body.goal ?? 'growth',
    horizon: body.horizon ?? 'months',
    loss_tolerance_pct: Number(body.loss_tolerance_pct ?? 10),
    portfolio_size_egp: portfolioSize,
    daily_loss_limit_pct: Number(dailyCap.toFixed(2)),
    weekly_loss_limit_pct: Number(weeklyCap.toFixed(2)),
    single_stock_cap_pct: singleCap,
    sector_cap_pct: sectorCap,
    money_not_to_risk_ack: Boolean(body.money_not_to_risk_ack),
    borrowed_money_flag: Boolean(body.borrowed_money_flag),
    max_affordable_loss_egp: maxAffordableLoss,
    preferred_sharia_only: Boolean(body.preferred_sharia_only),
  };

  if (profile) {
    Object.assign(profile, nextProfile);
  } else {
    profile = nextProfile;
    db.state.riskProfiles.push(profile);
  }

  let st = db.state.traderStates.find((s) => s.trader_id === traderId);
  if (!st) {
    st = {
      trader_id: traderId,
      as_of: new Date().toISOString(),
      mode: body.mode ?? 'manager',
      active_mode: body.mode === 'advisor' ? 'advisor' : 'manager',
      mood: body.mood ?? 'calm',
      tilt_score: 12,
      discipline_score: 0.72,
      loss_streak: 0,
      day_pnl_pct: 0,
      week_pnl_pct: 0,
      halted: false,
      halt_until: null,
      upgrade_eligible: false,
      license_level: 1,
    };
    db.state.traderStates.push(st);
  }

  db.appendAudit(traderId, 'onboarding_completed', `Trader:${traderId}`, {
    experience,
    borrowed_money_flag: profile.borrowed_money_flag,
    daily_loss_limit_pct: profile.daily_loss_limit_pct,
  });

  res.json({
    ok: true,
    trader,
    profile,
    traderState: st,
    charter: PUBLIC_SAFETY_CHARTER_10,
    disclaimer_ar: SHORT_DISCLAIMER_AR,
  });
});

// --- Section 9: GET /api/market/movers ---
app.get('/api/market/movers', (req, res) => {
  const db = getDb();
  const timeframe = String(req.query.timeframe ?? '1d');
  const sector = String(req.query.sector ?? 'all');
  const shariaOnly = req.query.sharia === 'true';
  const search = String(req.query.q ?? '').trim().toLowerCase();

  const key =
    timeframe === '1h'
      ? 'change_1h_pct'
      : timeframe === '1w'
        ? 'change_1w_pct'
        : timeframe === '1m'
          ? 'change_1m_pct'
          : 'change_1d_pct';

  let list = [...db.state.stocks];
  if (sector !== 'all') {
    list = list.filter((s) => s.sector_id === sector);
  }
  if (shariaOnly) {
    list = list.filter((s) => s.sharia_compliant);
  }
  if (search) {
    list = list.filter(
      (s) =>
        s.symbol.toLowerCase().includes(search) ||
        s.name_ar.toLowerCase().includes(search) ||
        s.name_en.toLowerCase().includes(search) ||
        s.sector_ar.toLowerCase().includes(search)
    );
  }

  const sortedByMove = [...list].sort((a, b) => b[key] - a[key]);
  const gainers = sortedByMove.slice(0, 8);
  const losers = [...list].sort((a, b) => a[key] - b[key]).slice(0, 8);
  const mostActive = [...list].sort((a, b) => b.volume_today - a.volume_today).slice(0, 8);

  // Sector heatmap aggregation
  const sectorMap = new Map<string, { sector_id: string; sector_ar: string; count: number; avgChange: number; totalAdv: number }>();
  for (const st of db.state.stocks) {
    const cur = sectorMap.get(st.sector_id) ?? {
      sector_id: st.sector_id,
      sector_ar: st.sector_ar,
      count: 0,
      avgChange: 0,
      totalAdv: 0,
    };
    cur.count += 1;
    cur.avgChange += st[key];
    cur.totalAdv += st.adv_30d;
    sectorMap.set(st.sector_id, cur);
  }
  const sectorHeatmap = Array.from(sectorMap.values()).map((s) => ({
    ...s,
    avgChange: Number((s.avgChange / Math.max(1, s.count)).toFixed(2)),
  }));

  const fg = calculateFearGreedIndex(db.state.stocks);
  const fearGreed = {
    score: fg.score,
    label_ar: fg.label_ar,
    factors_ar: [
      `نسبة الأسهم الصاعدة اليوم: ${fg.breadth_pct}%`,
      `متوسط مؤشر القوة النسبية RSI: ${fg.avg_rsi}`,
    ],
  };

  const hasLiveStocks = db.state.stocks.some((s) => !s.is_demo);
  res.json({
    timeframe,
    is_demo: !hasLiveStocks,
    live_feed_status: db.state.liveFeedStatus,
    data_notice: hasLiveStocks
      ? `بيانات سوق البورصة المصرية حية (${db.state.liveFeedStatus.live_symbols_count} سهماً محدثاً + ${db.state.stocks.length - db.state.liveFeedStatus.live_symbols_count} نماذج اختبار حماية)`
      : EGX_MARKET_PACK.data_notice,
    fear_greed: fearGreed,
    gainers,
    losers,
    most_active: mostActive,
    sector_heatmap: sectorHeatmap,
    stocks: list.map(({ bars: _bars, ...summary }) => summary),
    disclaimer_ar: SHORT_DISCLAIMER_AR,
  });
});

// --- Section 9: GET /api/stocks/:symbol & /quality ---
app.get('/api/stocks', (req, res) => {
  const db = getDb();
  const q = String(req.query.q ?? '').trim().toLowerCase();
  const items = db.state.stocks
    .filter((s) => !q || s.symbol.toLowerCase().includes(q) || s.name_ar.includes(q))
    .map(({ bars: _b, ...rest }) => rest);
  const hasLiveStocks = db.state.stocks.some((s) => !s.is_demo);
  res.json({ stocks: items, is_demo: !hasLiveStocks, live_feed_status: db.state.liveFeedStatus });
});

app.get('/api/stocks/:symbol', (req, res) => {
  const db = getDb();
  const symbol = req.params.symbol.toUpperCase();
  const stock = db.state.stocks.find((s) => s.symbol === symbol);
  if (!stock) {
    res.status(404).json({ error: `السهم ${symbol} غير موجود في قاعدة البيانات.` });
    return;
  }
  const asOf = new Date().toISOString();
  const quality = calculateStockQualityScore(stock, db.state.facts, asOf, db.state.config);
  const trap = calculateTrapScore(stock, 1500, db.state.config);
  const shariaRaw = calculateShariaAndPurification(stock, stock.price * 100 * (stock.dividend_yield_pct / 100), stock.price * 100, 'investment', 'AAOIFI');
  const sharia = {
    compliant: shariaRaw.compliant,
    non_halal_pct: shariaRaw.nonHalalRevenuePct,
    purification_per_share_egp: Number((shariaRaw.purificationEgp / 100).toFixed(3)),
    total_purification_egp: shariaRaw.purificationEgp,
    zakat_estimate_egp: shariaRaw.estimatedZakatEgp,
    note_ar: shariaRaw.scholarNoteAr,
  };
  const backtestRaw = runPointInTimeBacktest(stock.bars, asOf, db.state.config, 100_000);
  const backtest = { ...backtestRaw, note_ar: backtestRaw.disclaimer_ar };

  res.json({
    stock,
    quality,
    trap,
    sharia,
    backtest,
    is_blocked: db.state.killSwitches.blocked_symbols.includes(symbol),
    disclaimer_ar: SHORT_DISCLAIMER_AR,
  });
});

app.get('/api/stocks/:symbol/quality', (req, res) => {
  const db = getDb();
  const symbol = req.params.symbol.toUpperCase();
  const stock = db.state.stocks.find((s) => s.symbol === symbol);
  if (!stock) {
    res.status(404).json({ error: `السهم ${symbol} غير موجود.` });
    return;
  }
  const asOf = typeof req.query.as_of === 'string' ? req.query.as_of : new Date().toISOString();
  const quality = calculateStockQualityScore(stock, db.state.facts, asOf, db.state.config);
  const trap = calculateTrapScore(stock, 1500, db.state.config);
  res.json({ symbol, as_of: asOf, quality, trap, is_demo: stock.is_demo });
});

app.post('/api/stocks/:symbol/disclosure-extract', async (req, res) => {
  const symbol = req.params.symbol.toUpperCase();
  const text = String(req.body?.text ?? '').trim();
  if (text.length < 15) {
    res.status(400).json({ error: 'من فضلك أدخل نص إفصاح واضح لا يقل عن 15 حرفاً.' });
    return;
  }
  const extracted = await extractDisclosureEvents({ symbol, disclosureText: text });
  if (extracted.requires_human_review) {
    const db = getDb();
    db.state.reviewQueue.unshift({
      id: `rev_${Date.now().toString(36)}`,
      created_at: new Date().toISOString(),
      kind: 'disclosure_disagreement',
      subject: `Stock:${symbol}`,
      summary_ar: extracted.summary_ar,
      payload: { symbol, event_type: extracted.event_type, used_ai: extracted.used_ai },
      status: 'pending',
    });
    db.save();
  }
  res.json(extracted);
});

// --- Section 9: POST /api/advice, GET /api/advice/:id, GET /api/advice/:id/why ---
app.post('/api/advice', async (req, res) => {
  const db = getDb();
  const traderId = getTraderIdFromReq(req);
  const symbol = String(req.body?.symbol ?? 'COMI').toUpperCase();
  const requestedSizePct = req.body?.requested_size_pct ? Number(req.body.requested_size_pct) : undefined;
  const asOf = typeof req.body?.as_of === 'string' ? req.body.as_of : new Date().toISOString();

  const bundle = db.getTraderBundle(traderId);
  if (!bundle || !bundle.profile || !bundle.traderState) {
    res.status(404).json({ error: 'ملف المتداول غير موجود.' });
    return;
  }

  const stock = db.state.stocks.find((s) => s.symbol === symbol);
  if (!stock) {
    res.status(404).json({ error: `السهم ${symbol} غير مسجل.` });
    return;
  }

  const sourcesMap = new Map<string, Source>(db.state.sources.map((s) => [s.id, s]));
  const agentWeights: Record<string, number> = {};
  for (const ag of db.state.agentsCatalog) {
    agentWeights[ag.id] = Math.max(0.4, Math.min(1.5, ag.calibration_hit_rate + 0.35));
  }

  // Market stress calculation from top 10 stocks
  const top10 = db.state.stocks.slice(0, 10);
  const avgDrop = top10.reduce((s, x) => s + x.change_1d_pct, 0) / Math.max(1, top10.length);
  const haltedCount = db.state.stocks.filter((s) => s.quality === 'halted').length;

  const advice = await runAdvicePipeline({
    trader_id: traderId,
    symbol,
    as_of: asOf,
    stock,
    facts: db.state.facts,
    sources: sourcesMap,
    edges: db.state.edges,
    profile: bundle.profile,
    traderState: bundle.traderState,
    positions: bundle.positions,
    config: db.state.config,
    killSwitches: db.state.killSwitches,
    agentWeights,
    prevSealHash: db.getLastSealHash(),
    marketIndexDropPct: avgDrop,
    haltedTopStocksCount: haltedCount,
    requestedSizePct,
    optionalComposeFn: composeCompanionWithGemini,
  });

  db.recordAdvice(advice);
  res.json({ advice, disclaimer_ar: SHORT_DISCLAIMER_AR });
});

app.get('/api/advice/:id', (req, res) => {
  const db = getDb();
  const advice = db.state.advices.find((a) => a.id === req.params.id);
  if (!advice) {
    res.status(404).json({ error: 'النصيحة المطلوبة غير موجودة.' });
    return;
  }
  const stock = advice.symbol ? db.state.stocks.find((s) => s.symbol === advice.symbol) : undefined;
  res.json({ advice, stock_name_ar: stock?.name_ar ?? advice.symbol, disclaimer_ar: SHORT_DISCLAIMER_AR });
});

app.get('/api/advice/:id/why', (req, res) => {
  const db = getDb();
  const advice = db.state.advices.find((a) => a.id === req.params.id);
  if (!advice) {
    res.status(404).json({ error: 'النصيحة غير موجودة.' });
    return;
  }
  const rawLvl = Number(req.query.level ?? 1);
  const level: 1 | 2 | 3 = rawLvl === 3 ? 3 : rawLvl === 2 ? 2 : 1;
  const sourcesMap = new Map<string, Source>(db.state.sources.map((s) => [s.id, s]));
  res.json(getWhyChain(advice, level, sourcesMap));
});

app.post('/api/advice/:id/dismiss', (req, res) => {
  const db = getDb();
  const advice = db.state.advices.find((a) => a.id === req.params.id);
  if (!advice) {
    res.status(404).json({ error: 'النصيحة غير موجودة.' });
    return;
  }
  advice.status = 'dismissed';
  db.save();
  res.json({ ok: true, advice });
});

// --- Section 9: POST /api/plans & POST /api/trades/:id/close ---
app.post('/api/plans', (req, res) => {
  const db = getDb();
  const body = req.body ?? {};
  const traderId = getTraderIdFromReq(req);
  const symbol = String(body.symbol ?? '').toUpperCase();
  const reason = String(body.reason ?? '').trim();
  const entry = Number(body.entry);
  const stop = Number(body.stop);
  const sizePct = Number(body.size_pct ?? 5);
  const targets = Array.isArray(body.targets) ? body.targets.map(Number) : [Number(body.target1 ?? entry * 1.08)];

  if (!symbol || !reason || Number.isNaN(entry) || Number.isNaN(stop) || stop <= 0 || stop >= entry) {
    res.status(400).json({
      error: 'عقد الصفقة غير مكتمل: يجب تحديد سبب الدخول ووقف خسارة حقيقي أقل من سعر الدخول.',
    });
    return;
  }

  const created = db.createPlanAndOptionalPosition({
    trader_id: traderId,
    symbol,
    reason,
    entry,
    size_pct: sizePct,
    stop,
    targets,
    worst_case: String(body.worst_case ?? `خسارة محددة عند تفعيل وقف الخسارة (${stop})`),
    mood: body.mood ?? 'calm',
    advice_id: body.advice_id,
    openPaperFill: Boolean(body.open_paper_fill),
  });

  res.json({ ok: true, ...created, disclaimer_ar: SHORT_DISCLAIMER_AR });
});

app.post('/api/trades/:id/close', (req, res) => {
  const db = getDb();
  const traderId = getTraderIdFromReq(req);
  const body = req.body ?? {};
  const exitPrice = Number(body.exit_price);
  if (Number.isNaN(exitPrice) || exitPrice <= 0) {
    res.status(400).json({ error: 'سعر الإغلاق يجب أن يكون رقماً موجباً.' });
    return;
  }
  const result = db.closeTrade({
    trader_id: traderId,
    position_id: req.params.id !== 'manual' ? req.params.id : body.position_id,
    symbol: String(body.symbol ?? 'COMI').toUpperCase(),
    exit_price: exitPrice,
    deviation_tags: Array.isArray(body.deviation_tags) ? body.deviation_tags : ['none'],
    cause: body.cause ?? 'execution',
    journal_completed: Boolean(body.journal_completed ?? true),
  });
  if (!result) {
    res.status(404).json({ error: 'تعذر العثور على سجل المتداول.' });
    return;
  }
  res.json({ ok: true, ...result });
});

// --- Section 9: GET /api/portfolio/risk & POST /api/portfolio/statement ---
app.get('/api/portfolio/risk', (req, res) => {
  const db = getDb();
  const traderId = getTraderIdFromReq(req);
  const bundle = db.getTraderBundle(traderId);
  if (!bundle || !bundle.profile || !bundle.traderState) {
    res.status(404).json({ error: 'المحفظة غير موجودة.' });
    return;
  }
  const metrics = calculatePortfolioRiskMetrics(
    bundle.positions,
    bundle.profile,
    db.state.stocks,
    db.state.config
  );
  const netRealizedEgp = bundle.trades.reduce((s, t) => s + t.net_pnl_egp, 0);
  const totalRuleBreakCostEgp = bundle.trades.reduce((s, t) => s + t.rule_break_cost_egp, 0);

  // Brief alerts (respecting daily alert budget)
  const remainingAlerts = Math.max(0, bundle.trader.daily_alert_budget - bundle.trader.alerts_sent_today);
  const recentAdvices = db.state.advices.filter((a) => a.trader_id === traderId).slice(0, 6);

  res.json({
    trader: bundle.trader,
    profile: bundle.profile,
    traderState: bundle.traderState,
    positions: bundle.positions,
    plans: bundle.plans,
    trades: bundle.trades,
    recentAdvices,
    metrics,
    net_realized_egp: Math.round(netRealizedEgp),
    rule_break_cost_egp: Math.round(totalRuleBreakCostEgp),
    remaining_alert_budget: remainingAlerts,
    benchmarks: db.state.benchmarks,
    live_feed_status: db.state.liveFeedStatus,
    disclaimer_ar: SHORT_DISCLAIMER_AR,
  });
});

app.post('/api/portfolio/statement', (req, res) => {
  const db = getDb();
  const traderId = getTraderIdFromReq(req);
  const rawText = String(req.body?.csv_or_text ?? '').trim();
  const consented = Boolean(req.body?.consent_acknowledged);
  const autoDeleteRaw = Boolean(req.body?.auto_delete_raw ?? true);

  if (!consented) {
    res.status(400).json({ error: 'يجب تأكيد موافقة استيراد الكشف أولاً (بدون كلمات مرور).' });
    return;
  }
  if (!rawText) {
    res.status(400).json({ error: 'محتوى الكشف فارغ.' });
    return;
  }

  // Deterministic CSV/Text parser: lines of "SYMBOL,QTY,AVG_PRICE"
  const lines = rawText.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  const parsedPositions: Position[] = [];
  const skippedLines: string[] = [];

  for (const line of lines) {
    if (line.toLowerCase().startsWith('symbol') || line.startsWith('السهم')) continue;
    const parts = line.split(/[,;\t|]+/).map((p) => p.trim());
    if (parts.length < 3) {
      skippedLines.push(line);
      continue;
    }
    const sym = parts[0].toUpperCase();
    const qty = Number(parts[1]);
    const avg = Number(parts[2]);
    const stock = db.state.stocks.find((s) => s.symbol === sym);
    if (!stock || Number.isNaN(qty) || qty <= 0 || Number.isNaN(avg) || avg <= 0) {
      skippedLines.push(line);
      continue;
    }
    const pos: Position = {
      id: `pos_imp_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 5)}`,
      trader_id: traderId,
      symbol: stock.symbol,
      stock_name_ar: stock.name_ar,
      sector_id: stock.sector_id,
      owner_group_id: stock.owner_group_id,
      qty,
      avg_price: avg,
      current_price: stock.price,
      opened_at: new Date().toISOString(),
      closed_at: null,
      plan_id: null,
    };
    parsedPositions.push(pos);
    db.state.positions.unshift(pos);
  }

  db.appendAudit(traderId, 'statement_imported', `Trader:${traderId}`, {
    imported_count: parsedPositions.length,
    raw_file_deleted: autoDeleteRaw,
  });

  res.json({
    ok: true,
    imported_count: parsedPositions.length,
    skipped_count: skippedLines.length,
    raw_deleted: autoDeleteRaw,
    positions: parsedPositions,
    note_ar: autoDeleteRaw
      ? 'تم استيراد المراكز بنجاح وحذف النص الخام فوراً طبقاً لإعداد الخصوصية.'
      : 'تم استيراد المراكز بنجاح.',
  });
});

// --- Section 9: GET /api/track-record ---
app.get('/api/track-record', (_req, res) => {
  const db = getDb();
  const sealCheck = db.verifySealChain();
  const outcomes = db.state.outcomes;
  const total = outcomes.length;
  const wins = outcomes.filter((o) => o.result === 'win').length;
  const losses = outcomes.filter((o) => o.result === 'loss').length;
  const abstains = outcomes.filter((o) => o.result === 'abstained_correctly').length;

  // Aggregate Brier calibration curve by bucket
  const buckets = new Map<number, { bucket: number; n: number; hitSum: number }>();
  for (const row of db.state.calibrations) {
    const cur = buckets.get(row.bucket) ?? { bucket: row.bucket, n: 0, hitSum: 0 };
    cur.n += row.n;
    cur.hitSum += row.hit_rate * row.n;
    buckets.set(row.bucket, cur);
  }
  const calibrationCurve = Array.from(buckets.values())
    .sort((a, b) => a.bucket - b.bucket)
    .map((b) => ({
      bucket_label: `${b.bucket * 10}–${b.bucket * 10 + 10}%`,
      predicted_mid: b.bucket * 10 + 5,
      actual_hit_pct: Math.round((b.hitSum / Math.max(1, b.n)) * 100),
      sample_size: b.n,
    }));

  res.json({
    seal_verification: sealCheck,
    summary: {
      total_outcomes: total,
      wins,
      losses,
      abstained_correctly: abstains,
      win_rate_pct: total - abstains > 0 ? Math.round((wins / (total - abstains)) * 100) : 0,
    },
    calibration_curve: calibrationCurve,
    advices: db.state.advices,
    outcomes,
    charter: PUBLIC_SAFETY_CHARTER_10,
    disclaimer_ar: SHORT_DISCLAIMER_AR,
  });
});

// --- Section 9: Settings, Mode Switching, Panic Guard, Export & DELETE /api/me ---
app.post('/api/settings', (req, res) => {
  const db = getDb();
  const traderId = getTraderIdFromReq(req);
  const bundle = db.getTraderBundle(traderId);
  if (!bundle || !bundle.profile || !bundle.traderState) {
    res.status(404).json({ error: 'المتداول غير موجود.' });
    return;
  }
  const body = req.body ?? {};
  if (body.dialect) bundle.trader.dialect = body.dialect;
  if (body.numerals) bundle.trader.numerals = body.numerals;
  if (typeof body.low_bandwidth === 'boolean') bundle.trader.low_bandwidth = body.low_bandwidth;
  if (body.quiet_hours) bundle.trader.quiet_hours = body.quiet_hours;
  if (typeof body.daily_alert_budget === 'number') {
    bundle.trader.daily_alert_budget = Math.max(1, Math.min(10, body.daily_alert_budget));
  }
  if (body.trusted_observer !== undefined) {
    bundle.trader.trusted_observer = body.trusted_observer;
  }
  if (typeof body.daily_loss_limit_pct === 'number') {
    const cap = bundle.profile.experience === 'beginner' ? db.state.config.daily_loss_cap_beginner_pct : 5;
    bundle.profile.daily_loss_limit_pct = Math.min(cap, Math.max(0.5, body.daily_loss_limit_pct));
  }
  if (typeof body.weekly_loss_limit_pct === 'number') {
    const cap = bundle.profile.experience === 'beginner' ? db.state.config.weekly_loss_cap_beginner_pct : 12;
    bundle.profile.weekly_loss_limit_pct = Math.min(cap, Math.max(1, body.weekly_loss_limit_pct));
  }
  if (body.mode) {
    const m = body.mode as TraderMode;
    bundle.traderState.mode = m;
    if (m === 'manager' || m === 'advisor') {
      bundle.traderState.active_mode = m;
    }
  }
  if (body.active_mode) {
    bundle.traderState.active_mode = body.active_mode as ActiveMode;
  }
  if (body.mood) {
    bundle.traderState.mood = body.mood;
  }
  db.save();
  res.json({ ok: true, trader: bundle.trader, profile: bundle.profile, traderState: bundle.traderState });
});

app.get('/api/me/export', (req, res) => {
  const db = getDb();
  const traderId = getTraderIdFromReq(req);
  const bundle = db.getTraderBundle(traderId);
  if (!bundle) {
    res.status(404).json({ error: 'لا توجد بيانات لهذا الحساب.' });
    return;
  }
  res.json({ exported_at: new Date().toISOString(), ...bundle });
});

app.delete('/api/me', (req, res) => {
  const db = getDb();
  const traderId = getTraderIdFromReq(req);
  const result = db.deleteTraderCascade(traderId);
  if (!result.deleted) {
    res.status(404).json({ error: 'لم يتم العثور على الحساب المطلوب حذفه.' });
    return;
  }
  res.json({
    ok: true,
    message_ar: 'تم حذف حسابك وجميع مراكزك وخططك ونصائحك الشخصية وما اشتُق منها نهائياً.',
    ...result,
  });
});

app.post('/api/panic-guard', (req, res) => {
  const db = getDb();
  const traderId = getTraderIdFromReq(req);
  const action = req.body?.action === 'proceeded' ? 'proceeded' : 'cooled_off';
  const bundle = db.getTraderBundle(traderId);
  const note_ar =
    action === 'cooled_off'
      ? 'اختار التريث والمراجعة بهدوء بدلاً من قرار بيع فوري تحت الضغط.'
      : 'اختار استكمال مراجعة أوامر الخروج بعد رؤية تحذير التكلفة والمقارنة.';

  db.state.panicEvents.unshift({
    id: `pnc_${Date.now().toString(36)}`,
    trader_id: traderId,
    at: new Date().toISOString(),
    action,
    note_ar,
  });
  if (action === 'cooled_off' && bundle?.traderState) {
    bundle.traderState.mood = 'calm';
  }
  db.save();
  res.json({ ok: true, action, note_ar });
});

// --- Domain Endpoints: Brokers, Academy, Fraud, Backtest, Sharia ---
app.get('/api/brokers', (_req, res) => {
  const db = getDb();
  res.json({
    brokers: db.state.brokers,
    fees_note_ar: EGX_MARKET_PACK.fees_to_verify.broker_commission_range_note_ar,
    disclaimer_ar: SHORT_DISCLAIMER_AR,
  });
});

app.post('/api/brokers/fee-calculate', (req, res) => {
  const db = getDb();
  const ticketEgp = Math.max(100, Number(req.body?.ticket_egp ?? 10_000));
  const tradesPerMonth = Math.max(1, Number(req.body?.trades_per_month ?? 4));
  const rows = db.state.brokers.map((b) => {
    const comm = b.fees.find((f) => f.fee_type === 'commission');
    const minOrder = b.fees.find((f) => f.fee_type === 'min_per_order');
    if (comm?.status === 'verified' && comm.value !== null) {
      const calc = db.computeOrderCostsSummary(ticketEgp, 1, comm.value / 100, minOrder?.value ?? 2);
      return {
        broker_id: b.id,
        name_ar: b.name_ar,
        verified: true,
        per_order_total_egp: calc.total_cost_egp,
        annual_cost_egp: Number((calc.total_cost_egp * tradesPerMonth * 12).toFixed(2)),
      };
    }
    return {
      broker_id: b.id,
      name_ar: b.name_ar,
      verified: false,
      per_order_total_egp: null,
      annual_cost_egp: null,
      note_ar: 'الرسوم الرسمية قيد الجمع والتأكيد (غير مفترضة)',
    };
  });
  res.json({ ticket_egp: ticketEgp, trades_per_month: tradesPerMonth, rows });
});

app.get('/api/academy', (_req, res) => {
  const db = getDb();
  res.json({
    lessons: db.state.academyLessons,
    glossary: db.state.glossary,
    charter: PUBLIC_SAFETY_CHARTER_10,
  });
});

app.post('/api/academy/explain', async (req, res) => {
  const db = getDb();
  const term = String(req.body?.term_ar ?? '').trim();
  const item = db.state.glossary.find((g) => g.term_ar === term);
  const resExp = await explainTermWithGemini(term, item?.simple_ar ?? 'مصطلح مالي يُستخدم لقياس المخاطرة والعائد في البورصة.');
  res.json({ term_ar: term, ...resExp, disclaimer_ar: SHORT_DISCLAIMER_AR });
});

app.post('/api/fraud-check', (req, res) => {
  const text = String(req.body?.message ?? '').trim();
  if (text.length < 5) {
    res.status(400).json({ error: 'أدخل نص الرسالة المشبوهة لفحصها.' });
    return;
  }
  const result = checkFraudMessage(text);
  res.json({
    risk_level: result.risk_level,
    score: result.score,
    flags_ar: result.flags_ar,
    recommendation_ar: result.assessment_ar,
  });
});

app.post('/api/backtest', (req, res) => {
  const db = getDb();
  const symbol = String(req.body?.symbol ?? 'COMI').toUpperCase();
  const asOf = String(req.body?.as_of ?? new Date().toISOString());
  const portfolio = Math.max(5000, Number(req.body?.portfolio_egp ?? 100_000));
  const stock = db.state.stocks.find((s) => s.symbol === symbol);
  if (!stock) {
    res.status(404).json({ error: 'السهم غير موجود.' });
    return;
  }
  const result = runPointInTimeBacktest(stock.bars, asOf, db.state.config, portfolio);
  res.json({ ...result, symbol, as_of: asOf, note_ar: result.disclaimer_ar, disclaimer_ar: SHORT_DISCLAIMER_AR });
});

app.post('/api/sharia-calc', (req, res) => {
  const db = getDb();
  const symbol = String(req.body?.symbol ?? 'TMGH').toUpperCase();
  const qty = Math.max(1, Number(req.body?.qty ?? 100));
  const stock = db.state.stocks.find((s) => s.symbol === symbol);
  if (!stock) {
    res.status(404).json({ error: 'السهم غير موجود.' });
    return;
  }
  const shariaRaw = calculateShariaAndPurification(
    stock,
    stock.price * qty * (stock.dividend_yield_pct / 100),
    stock.price * qty,
    'investment',
    'AAOIFI'
  );
  res.json({
    symbol,
    compliant: shariaRaw.compliant,
    non_halal_pct: shariaRaw.nonHalalRevenuePct,
    total_purification_egp: shariaRaw.purificationEgp,
    zakat_estimate_egp: shariaRaw.estimatedZakatEgp,
    note_ar: shariaRaw.scholarNoteAr,
  });
});

// --- ADMIN GOVERNANCE API ---
app.get('/api/admin/status', (_req, res) => {
  const db = getDb();
  res.json(db.getAdminAuthStatus());
});

app.post('/api/admin/bootstrap', (req, res) => {
  const db = getDb();
  const result = db.bootstrapAdminPasscode(String(req.body?.passcode ?? ''));
  if (!result.ok) {
    res.status(400).json({ error: result.error });
    return;
  }
  res.json({ ok: true, token: result.token });
});

app.post('/api/admin/login', (req, res) => {
  const db = getDb();
  const result = db.loginAdmin(String(req.body?.passcode ?? ''));
  if (!result.ok) {
    res.status(401).json({ error: result.error });
    return;
  }
  res.json({ ok: true, token: result.token });
});

app.post('/api/admin/sync-live', requireAdminAuth, async (req, res) => {
  const db = getDb();
  const actor = (req as Request & { adminActor?: string }).adminActor ?? 'admin';
  const status = await syncLiveMarketData(db);
  db.appendAudit(actor, 'manual_live_feed_sync', 'MarketFeed', {
    live_symbols: status.live_symbols_count,
    usd_egp: status.usd_egp,
  });
  res.json({ ok: status.synced, live_feed_status: status });
});

app.get('/api/admin/overview', requireAdminAuth, (_req, res) => {
  const db = getDb();
  const seal = db.verifySealChain();
  res.json({
    kpis: {
      total_stocks: db.state.stocks.length,
      total_facts: db.state.facts.length,
      total_edges: db.state.edges.length,
      total_advices: db.state.advices.length,
      total_outcomes: db.state.outcomes.length,
      total_agents: db.state.agentsCatalog.length,
      enabled_agents: db.state.agentsCatalog.filter((a) => a.enabled).length,
      pending_reviews: db.state.reviewQueue.filter((r) => r.status === 'pending').length,
      verified_broker_fees: db.state.brokers.flatMap((b) => b.fees).filter((f) => f.status === 'verified').length,
      total_broker_fees: db.state.brokers.flatMap((b) => b.fees).length,
      seal_chain_valid: seal.valid,
    },
    live_feed_status: db.state.liveFeedStatus,
    config: db.state.config,
    kill_switches: db.state.killSwitches,
    agents: db.state.agentsCatalog,
    review_queue: db.state.reviewQueue,
    brokers: db.state.brokers,
    audit_logs: db.state.auditLogs.slice(0, 60),
    calibrations: db.state.calibrations,
  });
});

app.post('/api/admin/kill-switch', requireAdminAuth, (req, res) => {
  const db = getDb();
  const actor = (req as Request & { adminActor?: string }).adminActor ?? 'admin';
  const body = req.body ?? {};
  if (typeof body.global_pause_advice === 'boolean') {
    db.state.killSwitches.global_pause_advice = body.global_pause_advice;
  }
  if (typeof body.crisis_mode_manual === 'boolean') {
    db.state.killSwitches.crisis_mode_manual = body.crisis_mode_manual;
  }
  if (Array.isArray(body.disabled_agents)) {
    db.state.killSwitches.disabled_agents = body.disabled_agents.map(String);
    for (const ag of db.state.agentsCatalog) {
      ag.enabled = !db.state.killSwitches.disabled_agents.includes(ag.id);
    }
  }
  if (Array.isArray(body.blocked_symbols)) {
    db.state.killSwitches.blocked_symbols = body.blocked_symbols.map((s: unknown) => String(s).toUpperCase());
  }
  db.appendAudit(actor, 'update_kill_switches', 'KillSwitches', { ...db.state.killSwitches });
  res.json({ ok: true, kill_switches: db.state.killSwitches, agents: db.state.agentsCatalog });
});

app.post('/api/admin/config', requireAdminAuth, (req, res) => {
  const db = getDb();
  const actor = (req as Request & { adminActor?: string }).adminActor ?? 'admin';
  const patch = req.body ?? {};
  const allowedNumericKeys: Array<keyof typeof db.state.config> = [
    'risk_per_trade_beginner_pct',
    'risk_per_trade_standard_pct',
    'risk_per_trade_advanced_pct',
    'single_stock_cap_beginner_pct',
    'single_stock_cap_standard_pct',
    'single_stock_cap_advanced_pct',
    'daily_loss_limit_default_pct',
    'weekly_loss_limit_default_pct',
    'cool_off_hours',
    'liquidity_max_adv_pct',
    'liquidity_max_exit_days',
    'liquidity_block_exit_days',
    'age_max_intraday_seconds',
    'abstain_min_confidence',
    'abstain_min_agreement',
    'tilt_threshold',
    'crisis_index_drop_pct',
    'notification_budget_per_day',
    'trap_red_threshold',
  ];

  const changed: Record<string, unknown> = {};
  for (const k of allowedNumericKeys) {
    if (patch[k] !== undefined && !Number.isNaN(Number(patch[k]))) {
      (db.state.config as unknown as Record<string, unknown>)[k] = Number(patch[k]);
      changed[k] = Number(patch[k]);
    }
  }
  if (patch.licence_path === 'PATH_A' || patch.licence_path === 'PATH_B' || patch.licence_path === 'PATH_C') {
    db.state.config.licence_path = patch.licence_path;
    changed.licence_path = patch.licence_path;
  }

  db.state.config.version += 1;
  db.state.config.updated_at = new Date().toISOString();
  db.state.config.updated_by = actor;
  db.appendAudit(actor, 'update_versioned_config', `Config:v${db.state.config.version}`, changed);
  res.json({ ok: true, config: db.state.config });
});

app.get('/api/admin/ontology/query', requireAdminAuth, (req, res) => {
  const db = getDb();
  const asOf = typeof req.query.as_of === 'string' && req.query.as_of ? req.query.as_of : new Date().toISOString();
  const entityId = typeof req.query.entity_id === 'string' && req.query.entity_id ? req.query.entity_id : undefined;
  const predicate = typeof req.query.predicate === 'string' && req.query.predicate ? req.query.predicate : undefined;

  const facts = queryFactsAsOf(db.state.facts, asOf, entityId, predicate);
  const edges = db.state.edges.filter((e) => {
    if (Date.parse(e.known_at) > Date.parse(asOf)) return false;
    if (entityId && e.src !== entityId && e.dst !== entityId) return false;
    return true;
  });
  res.json({
    as_of: asOf,
    entity_id: entityId ?? 'ALL',
    fact_count: facts.length,
    facts: facts.slice(0, 80),
    edges: edges.slice(0, 60),
    entities: db.state.entities.slice(0, 60),
  });
});

app.post('/api/admin/facts', requireAdminAuth, (req, res) => {
  const db = getDb();
  const actor = (req as Request & { adminActor?: string }).adminActor ?? 'admin';
  const body = req.body ?? {};
  if (!body.entity_id || !body.predicate || body.value === undefined) {
    res.status(400).json({ error: 'الحقول الأساسية للحقيقة غير مكتملة.' });
    return;
  }
  const fact = db.appendFact({
    entity_id: String(body.entity_id),
    predicate: String(body.predicate),
    value: body.value,
    kind: body.kind ?? 'observed',
    source_id: body.source_id ?? 'src_demo_feed',
    quality: body.quality ?? 'valid',
    supersedes: body.supersedes ?? null,
  });
  db.appendAudit(actor, 'append_bitemporal_fact', fact.entity_id, { fact_id: fact.id, predicate: fact.predicate });
  res.json({ ok: true, fact });
});

app.post('/api/admin/compliance-test', requireAdminAuth, (req, res) => {
  const text = String(req.body?.text_ar ?? '');
  const numbersRaw = req.body?.allowed_numbers ?? [];
  const numbersMap: Record<string, { fact_id: string; label_ar: string; value: number; source_name: string; valid_from: string; known_at: string; display_licence: 'displayable' }> = {};
  if (Array.isArray(numbersRaw)) {
    numbersRaw.forEach((n, idx) => {
      const val = Number(n);
      if (!Number.isNaN(val)) {
        numbersMap[`n_${idx}`] = {
          fact_id: 'tester',
          label_ar: 'مرجع اختباري',
          value: val,
          source_name: 'اختبار المشرف',
          valid_from: new Date().toISOString(),
          known_at: new Date().toISOString(),
          display_licence: 'displayable',
        };
      }
    });
  }
  const result = checkComplianceCopy(text, numbersMap, {
    maxSentences: 3,
    requireDisclaimer: true,
    disclaimerText: SHORT_DISCLAIMER_AR,
  });
  res.json(result);
});

app.post('/api/admin/review-queue/:id', requireAdminAuth, (req, res) => {
  const db = getDb();
  const actor = (req as Request & { adminActor?: string }).adminActor ?? 'admin';
  const item = db.state.reviewQueue.find((r) => r.id === req.params.id);
  if (!item) {
    res.status(404).json({ error: 'عنصر المراجعة غير موجود.' });
    return;
  }
  const decision = req.body?.status === 'approved' ? 'approved' : 'rejected';
  item.status = decision;
  item.reviewed_by = actor;
  item.reviewed_at = new Date().toISOString();
  db.appendAudit(actor, `review_queue_${decision}`, item.subject, { item_id: item.id });
  res.json({ ok: true, item });
});

app.post('/api/admin/brokers/:id/fee', requireAdminAuth, (req, res) => {
  const db = getDb();
  const actor = (req as Request & { adminActor?: string }).adminActor ?? 'admin';
  const updated = db.updateBrokerFee(req.params.id, String(req.body?.fee_id ?? ''), req.body ?? {}, actor);
  if (!updated) {
    res.status(404).json({ error: 'الوسيط أو بند الرسوم غير موجود.' });
    return;
  }
  res.json({ ok: true, broker: updated });
});

async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (req, res, next) => {
      if (req.path.startsWith('/api/') || req.path.endsWith('.zip')) {
        next();
        return;
      }
      res.sendFile(path.join(distDir, 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Borsagy (borsagy.si) server listening on http://localhost:${PORT}`);
    // Non-blocking live market sync on server boot so EGX quotes, USD/EGP, and Gold are immediately fresh
    syncLiveMarketData(getDb()).catch((err) => {
      console.warn('Initial live market sync warning:', err);
    });
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
