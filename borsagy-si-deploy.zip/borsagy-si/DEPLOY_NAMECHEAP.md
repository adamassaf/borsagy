# دليل استضافة منصة بورصجي على Namecheap — النطاق `borsagy.si`

هذا الدليل يوضح خطوات رفع وتشغيل منصة **بورصجي (`borsagy.si`)** على استضافة **Namecheap** (سواء عبر **cPanel Node.js App** أو **Namecheap VPS / Ubuntu + Nginx**)، وكذلك رفع الكود إلى **GitHub**.

---

## ١. المحتويات المرفقة في الحزمة (`.zip`)
تحتوي الحزمة على كامل الشيفرة النظيفة للمنصة (الواجهة الأمامية React 19 + الخادم Express + محرك الأنطولوجيا و84 وكيلاً + باقات الاشتراك + التغذية الحية للأسعار والعملات):
- `src/` — الواجهة الأمامية ومحرك الحوكمة والحساب الحتمي
- `server/` و `server.ts` — خادم Express والتغذية الحية لأسهم البورصة المصرية والدولار والذهب وقاعدة JSON الآمنة
- `package.json` — سكريبتات البناء (`npm run build`) والتشغيل (`npm start`)
- `.env.example` — مرجع متغيرات البيئة المطلوبة دون أي مفاتيح سرية

---

## ٢. متغيرات البيئة المطلوبة (Environment Variables)
في لوحة تحكم Namecheap أو ملف `.env` على الخادم (لا ترفع ملف `.env` أبداً لـ Git):

```env
NODE_ENV=production
PORT=3000
APP_URL=https://borsagy.si
CORS_ALLOWED_ORIGINS=https://borsagy.si,https://www.borsagy.si
GEMINI_API_KEY="YOUR_GEMINI_API_KEY"
ADMIN_PASSCODE="STRONG_MIN_8_CHAR_PASSCODE"
# اختياري لتحسين التغذية الاحتياطية لأسهم EGX:
TWELVE_DATA_API_KEY=""
```

> **ملاحظة:** يقوم Namecheap أحياناً بتعيين `PORT` تلقائياً عبر Passenger/cPanel، وقد تم تجهيز `server.ts` ليقرأ `process.env.PORT` ويفعل `app.set('trust proxy', 1)` تلقائياً.

---

## ٣. التشغيل على Namecheap cPanel (Setup Node.js App)
1. فك ضغط ملف `borsagy-si-deploy.zip` داخل مجلد التطبيق مثل `/home/YOUR_USER/borsagy-si`.
2. من **cPanel → Setup Node.js App**:
   - **Node.js Version**: اختر `20.x` أو `22.x`.
   - **Application Mode**: `Production`.
   - **Application Root**: `borsagy-si`.
   - **Application URL**: `borsagy.si` (مع تفعيل SSL / AutoSSL من cPanel).
   - **Application Startup File**: `dist-server/server.js`.
3. أضف متغيرات البيئة المذكورة أعلاه داخل قسم **Environment Variables**.
4. افتح Terminal في cPanel أو عبر SSH نفّذ:
   ```bash
   cd ~/borsagy-si
   npm ci
   npm run build
   ```
5. من لوحة Setup Node.js App اضغط **Restart**.

---

## ٤. التشغيل على Namecheap VPS (Ubuntu + PM2 + Nginx SSL)
```bash
unzip borsagy-si-deploy.zip -d /var/www/
cd /var/www/borsagy-si
npm ci
npm run build
pm2 start dist-server/server.js --name borsagy-si
pm2 save
```
إعداد Nginx المقترح للنطاق `borsagy.si`:
```nginx
server {
    listen 80;
    server_name borsagy.si www.borsagy.si;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```
ثم فعّل شهادة SSL مجاناً عبر: `certbot --nginx -d borsagy.si -d www.borsagy.si`.

---

## ٥. ملاحظة تنظيمية ولغوية هامة للنطاق `borsagy.si`
- حسب وثيقة البناء والتنفيذ (القسم ٢٦): يرمز النطاق `.si` في العلامة البصرية إلى الرؤية المستقبلية، بينما يجب وصف قدرات المنصة الحالية بوضوح وصدق بأنها تعتمد على **"الذكاء الاصطناعي المتقدم" (Advanced AI)** مع إبقاء عبارة الذكاء الفائق في سياق البحث والتطوير المستقبلي فقط.
- يُوصى أيضاً بحجز النطاقات البديلة (`borsagy.com` و `borsagy.com.eg`) وتوجيهها للنطاق الرئيسي لتجنب التباس الامتداد `.si` (نطاق سلوفينيا الرسمي).
